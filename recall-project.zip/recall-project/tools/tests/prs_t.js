// Papers: Your papers / Done list, Progress › Papers results (range, custom dates, start fresh, leave out, change date). node prs_t.js W H tag [light]
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2] || 1400, +process.argv[3] || 900, process.argv[4] || 'd']; const LIGHT = process.argv[5] === 'light';
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8791);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const mob = W < 700;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, colorScheme: LIGHT ? 'light' : 'dark', hasTouch: mob, isMobile: mob }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/ERR_|Failed to load|supabase/.test(m.text())) errs.push('console ' + m.text()); });
  await p.route(/supabase\.co|cdn\.jsdelivr|fonts\.|thsconline|githubusercontent/, r => r.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
  await p.goto('http://127.0.0.1:8791/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), shot = async n => p.screenshot({ path: `/tmp/prs_${TAG}_${n}.png` });
  await E(async () => {
    const D = (y, m, d) => new Date(y, m - 1, d, 19, 30).getTime(), P = {};
    const add = (c, sec, school, year, done, got, of) => { const id = 'pp' + Math.random().toString(36).slice(2, 8); P[id] = { id, key: null, c, sec, school, year, sol: true, src: 'up', at: done ? done - 3 * 864e5 : Date.now() - 864e5, st: done ? 'done' : of ? 'marking' : 'new', q: {}, ...(done ? { done } : {}), ...(got !== null && of ? { score: { got, of } } : {}), ...(of && !done ? { qs: [{ key: 'q1', marks: 2 }, { key: 'q2', marks: 3 }], q: { q1: { r: 'ok' } } } : {}) }; };
    add('adv', 'trial', 'James Ruse', 2024, D(2026, 3, 14), 61, 100); add('adv', 'trial', 'North Sydney Boys', 2023, D(2026, 5, 2), 70, 100);
    add('adv', 'hsc', 'NSW HSC', 2022, D(2026, 7, 20), 78, 100); add('adv', 'trial', 'Baulkham Hills', 2024, D(2026, 9, 9), 84, 100);
    add('adv', 'hsc', 'NSW HSC', 2024, D(2026, 11, 12), 88, 100); add('x1', 'trial', 'Sydney Boys', 2023, D(2026, 4, 1), 39, 70);
    add('x1', 'trial', 'Normanhurst Boys', 2024, D(2026, 8, 30), 52, 70); add('x1', 'hsc', 'NSW HSC', 2023, D(2026, 11, 3), 58, 70);
    add('x2', 'trial', 'James Ruse', 2022, D(2026, 6, 10), 48, 100); add('x2', 'hy', 'Sydney Grammar', 2025, D(2026, 10, 18), 66, 100);
    add('phy', 'hsc', 'NSW HSC', 2021, D(2026, 2, 22), 72, 100); add('phy', 'trial', 'Hornsby Girls', 2024, D(2026, 10, 1), 81, 100);
    add('adv', 'trial', 'Cherrybrook Tech', 2024, null, null, 1); add('adv', 'trial', 'Sydney Tech', 2023, null, null, 0);
    add('eco', 'trial', 'Ruse', 2024, D(2026, 9, 20), null, 0);
    S.settings = { ...S.settings, papers: { ...(S.settings.papers || {}), ...P } }; await saveSettings();
  });
  await E(() => { pp.s = 'maths'; pp.c = { maths: 'adv' }; go('papers'); }); await p.waitForTimeout(500);
  console.log('switch:', await E(() => [...document.querySelectorAll('.h7ppshow button')].map(x => x.textContent.trim() + (x.getAttribute('aria-pressed') === 'true' ? '*' : ''))));
  await p.click('.h7ppshow [data-v="mine"]'); await p.waitForTimeout(300);
  console.log('mine groups:', await E(() => [...document.querySelectorAll('.h7ppgh')].map(x => x.textContent.trim().replace(/\s+/g, ' '))), await E(() => [...document.querySelectorAll('.h7ppr')].slice(0, 3).map(x => x.textContent.trim().replace(/\s+/g, ' '))));
  await shot('mine');
  await p.click('.h7ppshow [data-v="done"]'); await p.waitForTimeout(300);
  console.log('done:', await E(() => $('.h7ppsum')?.textContent), await E(() => [...document.querySelectorAll('.h7ppgh')].map(x => x.textContent.trim().replace(/\s+/g, ' '))));
  await p.click('.h7pptabs [data-act="pp-mall"]'); await p.waitForTimeout(300);
  console.log('done all maths:', await E(() => $('.h7ppsum')?.textContent), await E(() => document.querySelectorAll('.h7ppr').length), await E(() => $('.h7ppr small')?.textContent));
  await shot('done');
  await p.click('.h7ppsum [data-act="prs-open"]'); await p.waitForTimeout(500);
  console.log('ppres:', await E(() => [view.name, prs.s, prs.c, $('.hrsbig')?.textContent.trim().replace(/\s+/g, ' '), document.querySelectorAll('.prsdot').length, document.querySelectorAll('.prsl li').length]));
  await shot('res_maths');
  await p.click('[data-act="prs-subj"][data-v=""]'); await p.waitForTimeout(300);
  console.log('all subj:', await E(() => [document.querySelectorAll('.prsdot').length, document.querySelectorAll('.prsl li').length, [...document.querySelectorAll('.prsleg span')].map(x => x.textContent), $('.hrsfacts')?.textContent.replace(/\s+/g, ' ')]));
  await shot('res_all');
  await p.click('[data-act="prs-range"][data-v="3m"]'); await p.waitForTimeout(300);
  console.log('3m:', await E(() => [document.querySelectorAll('.prsdot').length, $('#prsf').value, $('#prst').value]));
  await p.fill('#prsf', '2026-05-01'); await p.dispatchEvent('#prsf', 'change'); await p.waitForTimeout(200);
  await p.fill('#prst', '2026-08-31'); await p.dispatchEvent('#prst', 'change'); await p.waitForTimeout(300);
  console.log('custom:', await E(() => [prs.range, prs.from, prs.to, document.querySelectorAll('.prsdot').length, [...document.querySelectorAll('.prsl .htm')].map(x => x.textContent)]));
  await p.click('[data-act="prs-range"][data-v="all"]'); await p.waitForTimeout(300);
  // leave one out via the row menu
  await p.$eval('.prsl li:first-child .hx', e => { e.scrollIntoView({ block: 'center' }); e.click(); }); await p.waitForTimeout(200); await shot('menu');
  await p.click('#menu [data-act="prs-off"]'); await p.waitForTimeout(300);
  console.log('left out:', await E(() => [document.querySelectorAll('.prsl li').length, $('[data-act="prs-showoff"]')?.textContent]));
  await E(() => appUndo()); await p.waitForTimeout(300);
  console.log('after undo:', await E(() => [document.querySelectorAll('.prsl li').length, !!$('[data-act="prs-showoff"]')]));
  // change a date
  await p.$eval('.prsl li:nth-child(2) .hx', e => { e.scrollIntoView({ block: 'center' }); e.click(); }); await p.click('#menu [data-act="prs-date"]'); await p.waitForTimeout(200);
  await p.fill('#prsdd', '2026-01-05'); await p.click('[data-act="prs-datesave"]'); await p.waitForTimeout(300);
  console.log('date moved:', await E(() => [...document.querySelectorAll('.prsl .htm')].slice(-2).map(x => x.textContent)));
  // start fresh
  await p.click('[data-act="prs-fresh"]'); await p.waitForTimeout(200); await p.click('[data-act="prs-freshgo"]'); await p.waitForTimeout(300);
  console.log('fresh:', await E(() => [!!S.settings.ppResFrom, document.querySelectorAll('.prsl li').length, $('.prsfoot')?.textContent.trim().replace(/\s+/g, ' '), $('.prsempty, .hrsnone')?.textContent]));
  await shot('fresh');
  await p.click('[data-act="prs-old"]'); await p.waitForTimeout(200); console.log('older too:', await E(() => document.querySelectorAll('.prsl li').length));
  await p.click('[data-act="prs-unfresh"]'); await p.waitForTimeout(300); console.log('unfresh:', await E(() => [S.settings.ppResFrom, document.querySelectorAll('.prsl li').length]));
  await p.click('.prsdot >> nth=0', { force: true }).catch(e => console.log('dot click', e.message.slice(0, 80))); await p.waitForTimeout(400); console.log('dot ->', await E(() => view.name));
  await E(() => go('stats')); await p.waitForTimeout(300); console.log('progress tabs:', await E(() => [...document.querySelectorAll('.hrsswitch [role=tab]')].map(x => x.textContent)));
  console.log('h-scroll:', await E(() => document.documentElement.scrollWidth > innerWidth + 1), 'errors:', errs.length ? errs : 'none');
  await b.close(); srv.close();
})();
