// a part's card: the question's opening (table + graph) and the part, solution if found
module.exports = async (p, E, shot) => {
  await E(() => { const node = Object.values(S.nodes).find(n => !kids(n.id).length); ppm.node = node.id; });
  const i = await E(l => ppm.items.findIndex(it => it.label === l), process.env.PICK);
  await E(i => ppmPick(i), i); await p.waitForTimeout(500);
  await p.click('[data-act="pp-res"][data-v="bad"]'); await p.waitForTimeout(200);
  await p.click('#ppwhy'); await p.keyboard.type('used the wrong radius');
  await p.click('.ppsave'); await p.waitForTimeout(4000);
  const c = await E(() => { const pp = ppmP(), q = Object.values(pp.q || {})[0], c = q && S.cards[q.card]; return c ? { label: c.label, src: c.source, q: (c.qImgs || [c.qImg]).filter(Boolean).length, sol: (c.solImgs || []).length, why: c.mistake } : null; });
  console.log('card', JSON.stringify(c));
};
