// scratchpad: page in the theme's card colour, inks that read on it, redraws when the theme changes, saving fills with the page colour
module.exports = async (p, E, shot) => {
  await E(() => { ppm = null; const id = Object.keys(S.cards)[0]; startStudy(null, true, null, [id]); }); await p.waitForTimeout(800);
  await E(() => padToggle(true)); await p.waitForTimeout(600);
  const draw = async () => { const r = await (await p.$('#pad')).boundingBox(); for (let i = 0; i < 5; i++){ await p.click(`#padwrap [data-pad="c${i}"]`).catch(() => {}); const y = r.y + 50 + i * 40; await p.mouse.move(r.x + 40, y); await p.mouse.down(); await p.mouse.move(r.x + 300, y + 10, { steps: 8 }); await p.mouse.up(); } };
  await draw();
  const st = () => E(() => ({ bg: getComputedStyle($('#pad')).backgroundColor, inks: PAD_COLORS().join(' '), dark: padDark(), sw: [...document.querySelectorAll('#padwrap .padc')].map(b => b.style.getPropertyValue('--c')).join(' '), strokes: pad.strokes.length }));
  console.log('theme 1', JSON.stringify(await st())); await shot('pad1');
  for (const id of ['applelight', 'harness', 'nord']){
    await E(id => themePick(id), id); await p.waitForTimeout(900);
    console.log(id, JSON.stringify(await st())); await shot('pad_' + id);
  }
};
