module.exports = async (p, E, shot, ctx) => {
  await E(() => { const id = Object.keys(S.cards)[0]; startStudy(null, true, null, [id]); }); await p.waitForTimeout(800);
  await E(() => padToggle(true)); await p.waitForTimeout(400); await E(() => { padAction('more'); padAction('more'); padAction('full'); }); await p.waitForTimeout(500);
  const r = await (await p.$('#pad')).boundingBox();
  await E(([x, y]) => { const cv = $('#pad'); const o = { pointerId: 9, pointerType: 'pen', clientX: x, clientY: y, bubbles: true, isPrimary: true, pressure: .5 }; cv.dispatchEvent(new PointerEvent('pointerdown', o)); cv.dispatchEvent(new PointerEvent('pointermove', { ...o, clientX: x + 60 })); cv.dispatchEvent(new PointerEvent('pointerup', { ...o, clientX: x + 60 })); }, [r.x + 100, r.y + 100]);
  console.log('pen', await E(() => [pad.penSeen, $('#pad').className, pad.strokes.length, getComputedStyle($('#pad')).touchAction]));
  await p.waitForTimeout(400);
  const cdp = await ctx.newCDPSession(p); const T = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((q, i) => ({ x: q[0], y: q[1], id: i })) });
  const x = r.x + 200, y = r.y + 400;
  await T('touchStart', [[x, y]]); for (let i = 1; i <= 12; i++) { await T('touchMove', [[x, y - i * 25]]); await p.waitForTimeout(16); } await T('touchEnd', []); await p.waitForTimeout(600);
  console.log('finger after pen', await E(() => [$('#padscroll').scrollTop, pad.strokes.length]));
  await E(() => padAction('full')); await p.waitForTimeout(400);
  console.log('after exit', await E(() => [$('#pad').className, scrollY]));
};
