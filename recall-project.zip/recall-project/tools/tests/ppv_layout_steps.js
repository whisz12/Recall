// marking layout: card only when picked, minimise/close/drag, typed marks, mark popover, divider, Paper/Both/Solutions
module.exports = async (p, E, shot) => {
  const sol = [...require('fs').readFileSync('/home/claude/papers/p01sol.pdf')];
  const pid = await E(() => ppm.pid);
  await E(async ([pid, sol]) => { const f = new File([new Uint8Array(sol)], 'Premiere X2 Solutions.pdf', { type: 'application/pdf' }); const q = await ppSolStore(ppPapers()[pid], f); await ppSavePaper(q, 'add solutions'); ppm = null; go('papers'); setTimeout(() => go('ppmark', pid), 50); }, [pid, sol]);
  await p.waitForFunction(() => ppm?.items?.length > 0 && !ppm.busy, null, { timeout: 120000 });
  await E(() => ppViewSet('both')); await p.waitForTimeout(800);
  const st = () => E(() => { const pn = $('#pppanel'), r = pn.getBoundingClientRect(), cs = getComputedStyle(pn); return { panel: cs.display !== 'none', card: pn.classList.contains('card'), min: pn.classList.contains('min'), x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), paperW: Math.round($('#ppscroll').getBoundingClientRect().width), solW: Math.round($('#ppsolscroll').getBoundingClientRect().width), view: ppView(), stageW: Math.round($('#ppstage').getBoundingClientRect().width) }; });
  const log = async n => console.log(JSON.stringify([n, await st()]));
  await log('both, nothing picked'); await shot('a_none');
  const i = await E(() => ppm.items.findIndex(it => it.label === 'Q12(b)(ii)')); await p.click(`#pprail [data-i="${i}"]`); await p.waitForTimeout(900);
  await log('picked'); await shot('b_picked');
  // Part → marks box focused, type 1 Enter
  await p.keyboard.press('2'); await p.waitForTimeout(200); console.log('focus after Part', await E(() => document.activeElement?.id));
  await p.keyboard.type('1'); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  console.log('typed got', await E(() => JSON.stringify({ got: ppm.got, res: ppm.res, val: $('#ppgot').value })));
  await p.click('#ppof'); await p.keyboard.type('4'); await p.keyboard.press('Tab'); await p.waitForTimeout(300);
  console.log('typed of', await E(() => JSON.stringify({ of: ppm.of, got: ppm.got })));
  // minimise, drag, close
  await p.click('[data-act="pp-card-min"]'); await p.waitForTimeout(300); await log('minimised'); await shot('c_min');
  const hd = await (await p.$('#pppanel .pphd h2')).boundingBox(); await p.mouse.move(hd.x + 10, hd.y + 10); await p.mouse.down(); await p.mouse.move(hd.x - 500, hd.y + 400, { steps: 10 }); await p.mouse.up(); await p.waitForTimeout(200);
  await log('dragged'); console.log('saved pos', await E(() => JSON.stringify(ls.get('md-pp-cardpos'))));
  await p.click('[data-act="pp-card-min"]'); await p.waitForTimeout(300); await log('expanded');
  await p.dblclick('#pppanel .pphd .ppnote'); await p.waitForTimeout(200); await log('dblclick back');
  await p.click('[data-act="pp-card-x"]'); await p.waitForTimeout(300); await log('closed');
  // divider
  const d = await (await p.$('#ppsplitter')).boundingBox(); await p.mouse.move(d.x + 4, d.y + 300); await p.mouse.down(); await p.mouse.move(d.x - 250, d.y + 300, { steps: 10 }); await p.mouse.up(); await p.waitForTimeout(600);
  await log('divider dragged left'); console.log('splitw', await E(() => ls.get('md-pp-splitw')));
  await shot('d_divider');
  // solutions only, then S cycles back to paper
  await p.click('#ppzview [data-v="sol"]'); await p.waitForTimeout(700); await log('solutions only'); await shot('e_solonly');
  await E(() => document.activeElement?.blur()); await p.keyboard.press('s'); await p.waitForTimeout(500); await log('S → paper');
  await p.keyboard.press('s'); await p.waitForTimeout(500); await log('S → both');
  // your mark popover from the score
  await p.click('[data-act="pp-mark"]'); await p.waitForTimeout(400);
  console.log('mark pop', await E(() => JSON.stringify({ pop: !!$('#tpop.ppmkpop'), focus: document.activeElement?.id })));
  await p.keyboard.type('77'); await p.keyboard.press('Tab'); await p.keyboard.type('100'); await p.keyboard.press('Enter'); await p.waitForTimeout(500);
  console.log('mark saved', await E(() => JSON.stringify(ppmP().score))); await shot('f_markpop');
  await p.mouse.click(600, 600); await p.waitForTimeout(200); console.log('pop closed', await E(() => !$('#tpop')));
  // keys popover, H hides only the list
  await p.click('[data-act="pp-keys"]'); await p.waitForTimeout(300); console.log('keys pop', await E(() => !!$('#tpop.ppkeyspop'))); await shot('g_keys'); await p.keyboard.press('Escape');
  await E(() => document.activeElement?.blur()); await p.keyboard.press('h'); await p.waitForTimeout(400); await p.click(`#pppages .ppbox >> nth=3`).catch(() => {}); await p.waitForTimeout(500); await log('H then pick on page'); await shot('h_nolist');
  await p.keyboard.press('h');
};
