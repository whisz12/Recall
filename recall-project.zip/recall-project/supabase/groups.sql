-- Recall study groups, live study status and notifications.
-- Run once in the Supabase dashboard: SQL Editor -> New query -> paste all of this -> Run.
-- Safe to run again: everything is "if not exists" / "create or replace".
-- Replace __PUSH_SECRET__ (two places) with the secret from recall-push-secrets.txt before running.

-- ---------- tables ----------
create table if not exists public.profiles (
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  name text not null check (char_length(name) between 1 and 40),
  updated_at timestamptz not null default now()
);

create table if not exists public.study_groups (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  code text not null unique,
  owner uuid not null default auth.uid() references auth.users on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.group_members (
  group_id uuid not null references public.study_groups on delete cascade,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
create index if not exists group_members_user on public.group_members (user_id);

-- what each person is doing right now (one row per person)
create table if not exists public.study_status (
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  state text not null default 'idle' check (state in ('idle', 'studying', 'paused')),
  subject text check (char_length(subject) <= 80),
  since timestamptz,            -- when the current run started
  today_secs int not null default 0 check (today_secs between 0 and 86400),  -- before the current run
  day date,
  left_at timestamptz,          -- set when the timer paused because they left Recall
  room uuid,
  updated_at timestamptz not null default now()
);

-- study time per person per day, for rankings
create table if not exists public.study_days (
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  day date not null,
  secs int not null default 0 check (secs between 0 and 86400),
  subjects jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, day)
);

-- a group session: someone starts a shared block and the others can join
create table if not exists public.group_rooms (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.study_groups on delete cascade,
  started_by uuid not null default auth.uid() references auth.users on delete cascade,
  title text check (char_length(title) <= 60),
  starts_at timestamptz not null default now(),
  minutes int not null check (minutes between 5 and 300),
  ended_at timestamptz
);
create index if not exists group_rooms_group on public.group_rooms (group_id, starts_at desc);

-- web push subscriptions (iPhone / iPad / browser); only their owner can see them
create table if not exists public.push_subs (
  endpoint text primary key check (endpoint like 'https://%'),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  sub jsonb not null,
  tz text not null default 'Australia/Sydney',
  on_start boolean not null default true,     -- a group member starts studying
  on_room boolean not null default true,      -- a group session starts
  remind_hour int check (remind_hour between 0 and 23),  -- daily nudge if you haven't studied yet
  last_reminded date,
  created_at timestamptz not null default now()
);

-- ---------- private bits (not reachable through the API) ----------
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create table if not exists private.app_secrets (k text primary key, v text not null);
insert into private.app_secrets (k, v) values ('push', '__PUSH_SECRET__') on conflict (k) do update set v = excluded.v;
create table if not exists private.push_log (sender uuid, group_id uuid, kind text, at timestamptz default now());
create index if not exists push_log_i on private.push_log (sender, group_id, kind, at desc);

-- ---------- helpers ----------
create or replace function public.my_group_ids() returns setof uuid
language sql stable security definer set search_path = public as $$
  select group_id from public.group_members where user_id = auth.uid()
$$;

create or replace function public.shares_group(other uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select other = auth.uid() or exists (
    select 1 from public.group_members a join public.group_members b on a.group_id = b.group_id
    where a.user_id = auth.uid() and b.user_id = other)
$$;

-- ---------- row level security ----------
alter table public.profiles enable row level security;
alter table public.study_groups enable row level security;
alter table public.group_members enable row level security;
alter table public.study_status enable row level security;
alter table public.study_days enable row level security;
alter table public.group_rooms enable row level security;
alter table public.push_subs enable row level security;

drop policy if exists "see group mates" on public.profiles;
create policy "see group mates" on public.profiles for select to authenticated using (public.shares_group(user_id));
drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "my groups" on public.study_groups;
create policy "my groups" on public.study_groups for select to authenticated using (id in (select public.my_group_ids()));
drop policy if exists "owner renames" on public.study_groups;
create policy "owner renames" on public.study_groups for update to authenticated using (owner = auth.uid()) with check (owner = auth.uid());

drop policy if exists "see members" on public.group_members;
create policy "see members" on public.group_members for select to authenticated using (group_id in (select public.my_group_ids()));
drop policy if exists "leave or remove" on public.group_members;
create policy "leave or remove" on public.group_members for delete to authenticated
  using (user_id = auth.uid() or exists (select 1 from public.study_groups g where g.id = group_id and g.owner = auth.uid()));

drop policy if exists "see mates status" on public.study_status;
create policy "see mates status" on public.study_status for select to authenticated using (public.shares_group(user_id));
drop policy if exists "own status" on public.study_status;
create policy "own status" on public.study_status for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "see mates days" on public.study_days;
create policy "see mates days" on public.study_days for select to authenticated using (public.shares_group(user_id));
drop policy if exists "own days" on public.study_days;
create policy "own days" on public.study_days for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "group rooms" on public.group_rooms;
create policy "group rooms" on public.group_rooms for select to authenticated using (group_id in (select public.my_group_ids()));
drop policy if exists "start rooms" on public.group_rooms;
create policy "start rooms" on public.group_rooms for insert to authenticated with check (started_by = auth.uid() and group_id in (select public.my_group_ids()));
drop policy if exists "end rooms" on public.group_rooms;
create policy "end rooms" on public.group_rooms for update to authenticated using (group_id in (select public.my_group_ids())) with check (group_id in (select public.my_group_ids()));

drop policy if exists "own push" on public.push_subs;
create policy "own push" on public.push_subs for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------- making, joining and leaving groups ----------
create or replace function public.create_group(p_name text) returns public.study_groups
language plpgsql security definer set search_path = public as $$
declare g public.study_groups; c text; abc text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; i int;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if (select count(*) from public.group_members where user_id = auth.uid()) >= 20 then raise exception 'You can be in up to 20 groups'; end if;
  loop
    c := ''; for i in 1..6 loop c := c || substr(abc, 1 + floor(random() * length(abc))::int, 1); end loop;
    exit when not exists (select 1 from public.study_groups where code = c);
  end loop;
  insert into public.study_groups (name, code, owner) values (left(trim(p_name), 60), c, auth.uid()) returning * into g;
  insert into public.group_members (group_id, user_id) values (g.id, auth.uid());
  return g;
end $$;

create or replace function public.join_group(p_code text) returns public.study_groups
language plpgsql security definer set search_path = public as $$
declare g public.study_groups;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into g from public.study_groups where code = upper(regexp_replace(p_code, '[^A-Za-z0-9]', '', 'g'));
  if g.id is null then raise exception 'No group has that code'; end if;
  if exists (select 1 from public.group_members where group_id = g.id and user_id = auth.uid()) then return g; end if;
  if (select count(*) from public.group_members where group_id = g.id) >= 50 then raise exception 'That group is full (50 people)'; end if;
  if (select count(*) from public.group_members where user_id = auth.uid()) >= 20 then raise exception 'You can be in up to 20 groups'; end if;
  insert into public.group_members (group_id, user_id) values (g.id, auth.uid());
  return g;
end $$;

create or replace function public.leave_group(p_group uuid) returns void
language plpgsql security definer set search_path = public as $$
declare nxt uuid;
begin
  delete from public.group_members where group_id = p_group and user_id = auth.uid();
  if exists (select 1 from public.study_groups where id = p_group and owner = auth.uid()) then
    select user_id into nxt from public.group_members where group_id = p_group order by joined_at limit 1;
    if nxt is null then delete from public.study_groups where id = p_group;
    else update public.study_groups set owner = nxt where id = p_group; end if;
  end if;
end $$;

revoke execute on function public.create_group(text), public.join_group(text), public.leave_group(uuid) from public, anon;
grant execute on function public.create_group(text), public.join_group(text), public.leave_group(uuid) to authenticated;

-- ---------- for the "notify" edge function only (guarded by the push secret) ----------
-- who to tell when p_sender starts studying / starts a session in p_group; at most one of each kind per 20 minutes
create or replace function public.push_targets(p_secret text, p_sender uuid, p_group uuid, p_kind text)
returns table (endpoint text, sub jsonb, sender_name text, group_name text)
language plpgsql security definer set search_path = public as $$
begin
  if p_secret is distinct from (select v from private.app_secrets where k = 'push') then raise exception 'no'; end if;
  if not exists (select 1 from public.group_members where group_id = p_group and user_id = p_sender) then return; end if;
  if exists (select 1 from private.push_log l where l.sender = p_sender and l.group_id = p_group and l.kind = p_kind and l.at > now() - interval '20 minutes') then return; end if;
  insert into private.push_log (sender, group_id, kind) values (p_sender, p_group, p_kind);
  delete from private.push_log where at < now() - interval '2 days';
  return query
    select s.endpoint, s.sub, coalesce((select name from public.profiles where user_id = p_sender), 'Someone'), g.name
    from public.push_subs s join public.group_members m on m.user_id = s.user_id and m.group_id = p_group
    join public.study_groups g on g.id = p_group
    where s.user_id <> p_sender and ((p_kind = 'start' and s.on_start) or (p_kind = 'room' and s.on_room));
end $$;

-- daily nudges due this hour for people who haven't studied today (marks them as sent)
create or replace function public.due_reminders(p_secret text)
returns table (endpoint text, sub jsonb)
language plpgsql security definer set search_path = public as $$
begin
  if p_secret is distinct from (select v from private.app_secrets where k = 'push') then raise exception 'no'; end if;
  return query
    with due as (
      select s.endpoint, (now() at time zone s.tz)::date as today from public.push_subs s
      where s.remind_hour = extract(hour from now() at time zone s.tz)
        and (s.last_reminded is null or s.last_reminded < (now() at time zone s.tz)::date)
        and not exists (select 1 from public.study_days d where d.user_id = s.user_id and d.day = (now() at time zone s.tz)::date and d.secs >= 60)
    )
    update public.push_subs p set last_reminded = due.today from due where p.endpoint = due.endpoint
    returning p.endpoint, p.sub;
end $$;

create or replace function public.drop_push(p_secret text, p_endpoint text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_secret is distinct from (select v from private.app_secrets where k = 'push') then raise exception 'no'; end if;
  delete from public.push_subs where endpoint = p_endpoint;
end $$;

-- ---------- live updates ----------
do $$ begin
  begin alter publication supabase_realtime add table public.study_status; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.group_rooms; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.group_members; exception when duplicate_object then null; end;
end $$;

-- ---------- optional: daily study reminders (needs the pg_cron and pg_net extensions) ----------
-- Calls the notify function at the top of every hour; each person's own reminder hour decides who gets one.
create extension if not exists pg_cron;
create extension if not exists pg_net;
select cron.unschedule('recall-remind') where exists (select 1 from cron.job where jobname = 'recall-remind');
select cron.schedule('recall-remind', '0 * * * *', $cron$
  select net.http_post(
    url := 'https://gdpgwwzuyqqphjxbtrql.supabase.co/functions/v1/notify',
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-recall-cron', '__PUSH_SECRET__'),
    body := '{"kind":"cron"}'::jsonb)
$cron$);
