// screenshot the marking screen of a real paper: a few pages with their boxes, picked parts, and the found list
module.exports = async (p, E, shot) => {
  await p.waitForTimeout(800);
  console.log(JSON.stringify(await E(() => ({ n: ppm.items.length, cut: ppm.cutP, labels: ppm.items.map(it => it.label + (it.stem ? '+s' : '') + (it.sol ? '✓' : '')).join(' ') }))));
  const pick = (process.env.PICK || '').split(',').filter(Boolean);
  for (const lab of pick){
    const i = await E(l => ppm.items.findIndex(it => it.label === l), lab); if (i < 0){ console.log('no', lab); continue; }
    await E(i => ppmPick(i), i); await p.waitForTimeout(900); await shot('pick_' + lab.replace(/[^\w]/g, ''));
  }
};
