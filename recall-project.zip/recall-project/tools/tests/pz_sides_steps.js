// NESA one-click papers with a mocked desktop.nesaGet (structure copied from NESA's real pages, 10 Nov 2026)
const fs = require('fs');
module.exports = async (p, E, shot) => {
  const exam = [...fs.readFileSync(__dirname + '/paper.pdf')], mg = [...fs.readFileSync(__dirname + '/NSB 2023 Physics Trial Solutions.pdf')];
  await E(({ exam, mg }) => {
    const B = 'https://www.nsw.gov.au/education-and-training/nesa/curriculum/hsc-exam-papers/', F = '/sites/default/files/noindex/2025-05/';
    const page = links => `<html><body><nav><a href="/x/2001">nav 2001</a></nav><main>${links.map(([t, h]) => `<p><a href="${h}">${t}</a></p>`).join('')}</main></body></html>`;
    const P = {
      'mathematics-advanced': page([['Mathematics HSC exam papers archive', '/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-archive'], ...[2026, 2025, 2024, 2023, 2022, 2021, 2020].map(y => [`Mathematics Advanced ${y} HSC exam pack`, `/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-advanced/${y}`])]),
      'mathematics-advanced/2024': page([['Mathematics Advanced HSC exam 2024 (PDF 2.14MB)', F + '2024-hsc-maths-adv.pdf'], ['Mathematics Advanced HSC marking guidelines 2024 (PDF 707.9KB)', F + '2024-hsc-maths-adv-mg.pdf'], ['Mathematics Advanced HSC marking feedback 2024 – Section II (PDF 340KB)', F + '2024-hsc-mathematics-adv-marking-feedback.pdf'], ['2026', B + 'mathematics-advanced/2026']]),
      'mathematics-advanced/2023': page([['Mathematics Advanced HSC exam 2023 (PDF 2MB)', F + '2023-hsc-maths-adv.pdf'], ['Mathematics Advanced HSC marking guidelines 2023 (PDF 700KB)', F + '2023-hsc-maths-adv-mg.pdf']]),
      'mathematics-advanced/2026': page([['Mathematics Advanced HSC exam paper 2026 (PDF 1.37MB)', '/sites/default/files/noindex/2026-10/2026-hsc-maths-advanced.pdf']]),
      'mathematics-archive': page([...[2019, 2018, 2017, 2016, 2015].map(y => [`Mathematics ${y} HSC exam pack (archive)`, `/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-archive/${y}`])]),
      'mathematics-archive/2019': page([['Mathematics HSC exam 2019 (PDF 1.62MB)', F + '2019-hsc-mathematics.pdf'], ['Mathematics HSC marking guidelines 2019 (PDF 982KB)', F + '2019-hsc-maths-mg.pdf']]),
      'english-advanced': page([['English Advanced HSC exam papers archive', B + 'english-advanced-archive'], ['English Advanced 2024 HSC exam pack', B + 'english-advanced/2024']]),
      'english-advanced/2024': page([['English Advanced HSC exam 2024 – Paper 1 (PDF 1.27MB)', '/sites/default/files/noindex/2025-07/2024-hsc-english-adv-paper-1-cc.pdf'], ['English Advanced HSC exam 2024 – Paper 2 (PDF 166KB)', F + '2024-hsc-english-adv-paper-2.pdf'], ['English Advanced HSC marking guidelines 2024 – Paper 1 (PDF 251KB)', F + '2024-hsc-english-adv-paper-1-mg.pdf'], ['English Advanced HSC marking guidelines 2024 – Paper 2 (PDF 203KB)', F + '2024-hsc-english-adv-paper-2-mg.pdf']]),
    };
    window.__nesa = []; window.__nesaFail = null;
    window.desktop.nesaGet = async url => {
      window.__nesa.push(url.replace(B, '~/').replace('https://www.nsw.gov.au', ''));
      if (window.__nesaFail && url.includes(window.__nesaFail)) throw new Error("Error invoking remote method 'nesa-get': Error: NESA replied 503");
      if (/\.pdf$/.test(url)) return { url, name: url.split('/').pop(), bytes: new Uint8Array(/-mg\.pdf$/.test(url) ? mg : exam) };
      const k = url.replace(B, '').replace(/\/$/, ''); if (!P[k]) throw new Error("Error invoking remote method 'nesa-get': Error: NESA replied 404");
      return { url, html: P[k] };
    };
    undoMute = true; S.settings = { ...S.settings, ppSubj: { ...(S.settings.ppSubj || {}), maths: true, english: true } }; undoMute = false;
    pp.s = 'maths'; pp.c = { ...(pp.c || {}), maths: 'adv' }; go('papers');
  }, { exam, mg });

  await p.waitForTimeout(700);
  await p.click('[data-act="pp-open"][data-k="n:adv:2024"]');
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(600);

  const st = () => E(() => ({ sides: ppSides, cls: $('#ppm').classList.contains('nosides'), rail: getComputedStyle($('#pprail')).display, panel: getComputedStyle($('#pppanel')).display, stageW: $('#ppstage').clientWidth, pageW: $('#pppages .pppage')?.clientWidth, pressed: $('#ppzsides').getAttribute('aria-pressed') }));
  console.log(JSON.stringify(['start', await st()]));
  await p.click('#ppzsides'); await p.waitForTimeout(700);
  console.log(JSON.stringify(['hidden', await st()]));
  await shot('hidden');
  await p.click('#ppzsplit'); await p.waitForTimeout(700); await shot('hiddensplit');
  console.log(JSON.stringify(['hidden+split', await E(() => ({ lw: $('#ppscroll').clientWidth, rw: $('#ppsolscroll').clientWidth }))]));
  await p.click('#ppzsplit'); await p.waitForTimeout(300);
  // stays hidden after leaving and coming back
  await E(() => go('papers')); await p.waitForTimeout(400); await E(() => go('ppmark', Object.values(ppPapers()).find(x => x.key === 'n:adv:2024').id)); await p.waitForTimeout(900);
  console.log(JSON.stringify(['reopen', await st()]));
  await E(() => document.activeElement?.blur()); await p.keyboard.press('h'); await p.waitForTimeout(500);
  console.log(JSON.stringify(['H', await st()]));
  // typing h in the why box doesn't toggle
  await E(() => ppmPick(2)); await p.waitForTimeout(200); await p.keyboard.press('3'); await p.waitForTimeout(300);
  await p.click('#ppwhy'); await p.keyboard.type('hh'); await p.waitForTimeout(200);
  console.log(JSON.stringify(['typing', await E(() => ({ sides: ppSides, why: $('#ppwhy').value }))]));
};
