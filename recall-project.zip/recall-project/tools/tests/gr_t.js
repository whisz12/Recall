const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]];
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8773);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ua = W > 700 ? 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: true, deviceScaleFactor: 2, userAgent: ua }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message + ' @ ' + (e.stack||'').split('\n').slice(1,3).join(' ')));
  const V = path.resolve(__dirname, '../../app/app/vendor') + '/';
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)|supabase\.co/, route => { const u = route.request().url(); if (u.includes('supabase.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(V + 'supabase.js') }); route.fulfill({ status: 200, body: '' }); });
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
  await p.addInitScript(fs.readFileSync(path.join(__dirname, 'grfake.js'), 'utf8'));
  await p.goto('http://127.0.0.1:8773/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), shot = async n => { await p.waitForTimeout(250); await p.screenshot({ path: `/tmp/gr_${TAG}_${n}.png` }); };
  await E(() => { document.querySelector('#layer').innerHTML = ''; });
  // signed out
  await E(() => go('group')); await shot('0signedout');
  console.log('signed out:', await E(() => document.querySelector('.grempty h1')?.textContent));
  // signed in with the fake service
  await E(() => { const uid = 'aaaaaaaa-0000-4000-8000-000000000001'; cloud.sb = __grFake(uid); cloud.user = { id: uid, email: 'jeremy.l@example.com' }; gr.loaded = false; renderGroup(); });
  await p.waitForTimeout(400); await shot('1name');
  console.log('name step:', await E(() => document.querySelector('.grempty h1')?.textContent), 'prefill:', await E(() => document.querySelector('#grname')?.value));
  await p.click('[data-act="gr-name"]'); await p.waitForTimeout(400);
  console.log('after name:', await E(() => document.querySelector('.grempty h1')?.textContent)); await shot('2start');
  await p.fill('#grjoin', 'zzz zzz'); await p.click('[data-act="gr-join"]'); await p.waitForTimeout(300); console.log('bad join toast:', await E(() => document.querySelector('#toast')?.textContent));
  await p.fill('#grnew', 'Ext 2 grind'); await p.press('#grnew', 'Enter'); await p.waitForTimeout(600);
  console.log('group page:', await E(() => [document.querySelector('.grtabs .stab[aria-selected="true"]')?.textContent, document.querySelector('.grppl h2')?.textContent, document.querySelector('.grcodebox b')?.textContent]));
  await shot('3group');
  // start studying
  await p.click('[data-act="gr-go"]'); await p.waitForTimeout(1300);
  console.log('studying:', await E(() => [focus.state, focus.subj, document.querySelector('.grclock span').textContent, __db.study_status.find(s => s.user_id.startsWith('aaaa'))?.state]));
  await shot('4studying');
  // leave the app -> pause
  await E(() => { Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); });
  console.log('after leaving:', await E(() => [focus.state, focus.by, __db.study_status.find(s => s.user_id.startsWith('aaaa'))?.state, !!__db.study_status.find(s => s.user_id.startsWith('aaaa'))?.left_at]));
  await E(() => { focus.leftAt -= 3 * 60e3; Object.defineProperty(document, 'hidden', { value: false, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); });
  await p.waitForTimeout(300); await shot('5back');
  console.log('back dialog:', await E(() => document.querySelector('.grback p')?.textContent));
  await p.click('[data-act="gr-resume"]'); await p.waitForTimeout(500);
  console.log('resumed:', await E(() => focus.state));
  // group session
  await p.click('[data-act="gr-room-new"]'); await p.waitForTimeout(200); await p.click('[data-act="gr-mins"][data-v="25"]'); await p.fill('#grrtitle', '2022 Ext 2 paper'); await shot('6roomdlg');
  await p.click('[data-act="gr-room-go"]'); await p.waitForTimeout(700);
  console.log('room:', await E(() => [document.querySelector('.grroom h2')?.textContent, document.querySelector('.grrleft')?.textContent, focus.room === __db.group_rooms[0]?.id]));
  await E(() => gr.rank = 'week'); await E(() => renderGroup()); await shot('7room');
  console.log('rank week:', await E(() => [...document.querySelectorAll('.grrank li')].map(l => l.textContent.replace(/\s+/g, ' ').trim())));
  // pill elsewhere + card study auto start
  await E(() => go('decks')); await shot('8pill');
  console.log('pill:', await E(() => document.querySelector('#fpill')?.textContent));
  await E(() => { fStop(); }); await E(() => startStudy(kids(kids(null)[1].id)[0].id)); await p.waitForTimeout(300);
  console.log('auto start from cards:', await E(() => [focus.state, focus.subj]));
  console.log('hscroll:', await E(() => document.documentElement.scrollWidth > innerWidth + 1));
  await E(() => { study = null; go('group'); }); await shot('9final');
  console.log(TAG, 'errors:', errs); await b.close(); srv.close();
})();
