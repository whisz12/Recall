#!/usr/bin/env python3
"""Adds the Memorise tab (mm.js, mm.css) and the rubric guide (mg.js, mg.css) to src/mistake-deck.html. Run once on a source without them."""
import sys
B = '/home/claude/mmbuild/'
path = sys.argv[1]; s = open(path, encoding='utf-8').read()
if 'Memorise (24 Nov 2026)' in s: sys.exit('already integrated')
def sub(old, new, n=1):
    global s
    c = s.count(old)
    if c != n: sys.exit(f'anchor x{c}: {old[:80]!r}')
    s = s.replace(old, new)
css = open(B + 'mm.css').read() + '\n' + open(B + 'mg.css').read()
i = s.index('</style>'); s = s[:i] + css + s[i:]
# sidebar / phone bar item, after Mistakes
mk = s.index('<button data-nav="mistakes">'); e = s.index('</button>', mk) + len('</button>')
s = s[:e] + '\n    <button data-nav="memo"><svg class="ni" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 5.5h13M3.5 10h13M3.5 14.5h7.5"/><path d="M15 12.5l1.6 1.6L19 11.4"/></svg><span>Memorise</span></button>' + s[e:]
sub('<button data-nav="mistakes">Mistakes</button><button data-nav="stats">Progress</button>', '<button data-nav="mistakes">Mistakes</button><button data-nav="memo">Memorise</button><button data-nav="stats">Progress</button>')
sub("{ x: r.right - 170, y: r.top - 202 }); return; }", "{ x: r.right - 170, y: r.top - 234 }); return; }")
sub("$('.navmore')?.setAttribute('aria-current', String(['browse', 'papers', 'ppmark', 'mistakes', 'stats', 'exam', 'themes'].includes(view.name)));",
    "$('.navmore')?.setAttribute('aria-current', String(['browse', 'papers', 'ppmark', 'mistakes', 'memo', 'stats', 'exam', 'themes'].includes(view.name)));")
sub("  renderSideSubjects(); h7NavCounts();\n", "  renderSideSubjects(); h7NavCounts(); try { mmRenderHook(); } catch {}\n")
sub("  else if (view.name === 'mistakes') renderMistakes();\n", "  else if (view.name === 'mistakes') renderMistakes();\n  else if (view.name === 'memo') renderMemo();\n")
sub("  else if (view.name === 'mistakes'){ title = '<b>Mistakes</b>", "  else if (view.name === 'memo'){ const r = mmAppbar(); title = r.title; act = r.act; }\n  else if (view.name === 'mistakes'){ title = '<b>Mistakes</b>")
sub("put2('nav [data-nav=\"decks\"]', toStudy(counts(null))); try { put2('nav [data-nav=\"todo\"]', todoTasks(todoList(null, 'today')).length); } catch {}",
    "put2('nav [data-nav=\"decks\"]', toStudy(counts(null))); try { put2('nav [data-nav=\"todo\"]', todoTasks(todoList(null, 'today')).length); } catch {} try { put2('nav [data-nav=\"memo\"]', mmDueAll()); } catch {}")
# Back button / ⌘[ / Alt+←: step back inside Memorise first
sub("function histGo(dir){\n", "function histGo(dir){\n  if (dir < 0 && view.name === 'memo' && typeof mmBack === 'function' && mmBack()) return;\n")
sub("function navBack(){\n", "function navBack(){\n  if (view.name === 'memo' && typeof mmBack === 'function' && mmBack()) return;\n")
sub("    case 'hist-back': return navH.back.length", "    case 'hist-back': if (view.name === 'memo' && mmBack()) return; return navH.back.length")
sub("if (b) b.disabled = !(navH.back.length || view.name === 'study'", "if (b) b.disabled = !(navH.back.length || (view.name === 'memo' && mmCanBack()) || view.name === 'study'")
js = open(B + 'mg.js').read() + '\n' + open(B + 'mm.js').read()
anchor = "initStore().finally(() => {"
i = s.rindex(anchor); s = s[:i] + js + '\n' + s[i:]
open(path, 'w', encoding='utf-8').write(s); print('integrated', len(s))
