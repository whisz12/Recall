# CLAUDE.md: how Recall should look and behave

Read this with `HANDOVER.md` before touching the UI. HANDOVER explains how to build and ship. This file explains the design rules, the things never to do, and how to critique a screen before shipping it.

The test for every change: **does this help someone revise a mistake faster, or is it decoration?** If it's decoration, leave it out.

---

## 1. Never do these (they make an app look AI-generated)

These are the common "vibe-coded" tells, collected from design critics and slop catalogues. If a change adds one of them, rethink it.

**Colour and effects**
- Purple-to-blue (or indigo) gradients, gradient text, gradient hero headings.
- Glows: radial halos behind content, neon borders, glowing accents on dark mode, logo glows.
- Glassmorphism (blur + translucency) used for decoration rather than to show a floating layer.
- Grain or noise textures over gradients.
- Low-contrast dark mode, where grey text sits on grey panels.
- Rainbow colour: every block gets its own tint, side stripe or icon colour.
- Status dots that mean nothing, or pulse when nothing is changing.
- The same colour meaning several things (red for a subject *and* "Again" *and* delete).

**Type**
- Inter, Space Grotesk, Instrument Serif or Poppins as a reflex choice; Space Grotesk plus Instrument Serif together.
- Serif italics for "accent" words.
- Tiny uppercase letter-spaced labels everywhere (`TUESDAY, NOVEMBER 3`, `MY MISTAKE`, `+ ADD CARD`).
- Monospace for buttons, nav or labels. Mono is only for code and keyboard hints.
- A kicker or badge above a heading that repeats the heading ("HOW DID IT GO?" over "How well did you know it?").
- Emojis in headings, nav or as icons.
- Em dashes everywhere in copy, and generic buzzword copy.
- Dozens of one-off font sizes (11.5px, 12.5px, 13.5px…). Use the scale in §3.

**Layout and components**
- Cards inside cards inside cards.
- Coloured left-border (side-tab) cards.
- Three icon boxes in a row; an icon tile stacked above every title.
- Identical card grids that give every item the same weight.
- Huge corner radii and pill-shaped everything.
- Hairline border *and* a wide shadow on the same card.
- Empty template scaffolding: grids of "0 cards" tiles.
- Untouched shadcn/Tailwind defaults; Lucide icons on everything.
- Inconsistent spacing.

**Motion**
- Sections fading or sliding in as you scroll.
- A beam or glow that follows the cursor.
- Hover effects that make buttons fade.
- Bounce or elastic easing on routine actions.
- Blinking cursors, marquees, pulsing dots, anything that moves when nothing changed.

---

## 2. General design principles (apply to any screen)

1. **One job per screen, one primary action.** Only one filled accent button per view (Study all, Show answer, Add). Everything else is secondary or a plain link.
2. **Hierarchy comes from size, weight and contrast, not colour or boxes.** Make the content the user came for the biggest thing (the question, not the deck name). Recede navigation and meta.
3. **Group with space and hairlines before borders and cards.** A card is only for something independently actionable or draggable (a subject window). Never nest them.
4. **Colour is a budget.** Neutral by default. Colour only where it carries meaning, used the same way everywhere (Apple HIG: never use one colour for several meanings).
5. **Recognition over recall.** Show counts, due numbers, shortcuts (`kbd`) and current state, so nobody has to remember them.
6. **Design the empty, loading, error and success states.** An empty deck is one muted line ("No cards yet"), not a grid of zero tiles. Every action gives feedback within ~400 ms.
7. **Follow platform conventions** (Apple HIG for Mac and iPad):
   - Sentence-case labels.
   - 13 pt-ish UI text.
   - Sidebar rows with symbols.
   - Don't put key actions at the bottom of a sidebar.
   - Show at most two levels of hierarchy in a sidebar.
8. **Consistency:**
   - The same thing looks and behaves the same everywhere.
   - One separator (` › `) for paths.
   - One name per concept.
9. **Accessibility:**
   - Text contrast at least 4.5:1, or 3:1 for large text.
   - Never use colour alone to carry meaning.
   - Visible focus rings.
   - 44 px touch targets on iPad and iPhone.
   - Support Reduce Motion.
10. **Copy:**
    - Plain, specific and short. Say what happens: "Show answer", "Back in 10m".
    - No happy talk, no hype, no em dashes.

---

## 3. The Recall design system

The design layer is the block headed `Recall design system` at the **end** of the `<style>` in `src/mistake-deck.html`. It overrides the older layers above it. Put new styles there, using the tokens below, rather than adding new one-off values.

### Type
- **Font:** the system font everywhere (`FONT_DEF` = `system`): San Francisco on Mac/iPad, Segoe UI on Windows. The logo keeps its serif R.
- **Scale (px):** 11 · 12 · 13 · 14 · 15 · 16 · 17 · 20 · 24 · 30. Nothing in between.
  - 12: meta and labels
  - 13: UI and sidebar
  - 14: body
  - 17: flashcard text and answer sections
  - 22: page titles
- **Weights:** 400, 500, 600 (700 only for rare emphasis).
- **Case and spacing:** sentence case always. No uppercase transforms, no positive letter-spacing. Headings get −0.01em.
- **Numbers:** `font-variant-numeric: tabular-nums` on every count.

### Colour roles
| Role | Use | Never |
|---|---|---|
| Neutrals (`--bg`, `--surface`, `--surface-2`, `--hover`, `--border`, `--border-2`, `--fg`, `--fg-2`, `--fg-3`) | Everything by default | |
| Attention colour (`--accent` for text, `--accent-btn` for fills; gold in Graphite, matches the logo cursor) | The one primary button, focus ring, progress fill, due counts on tabs, topics and bubbles | Decoration, borders on cards, selection fills, subtopic chips |
| Complement (`--accent-2`) | The second main colour of a theme: current sidebar icon, small quiet highlights | Buttons, progress, anything that must grab attention |
| Ratings (`--again`, `--hard`, `--good`, `--easy`) | Rating buttons, rating filters, the "back in…" flash | Subjects, headings |
| Sections (`--mistake`, `--solution`, `--ex-t`) | The small heading + dot of My mistake / Correct solution / Explanation | Box backgrounds |
| Subject colour (`--sc`) | One 7–8 px dot next to the subject name | Buttons, tiles, bars, hover tints |
| Selected state | Neutral fill `rgba(var(--ovr),.08)`; segmented controls invert (fg background) | Gold tints |

Accent used as small text is mixed toward `--fg` so it stays readable on Light.

### Dark mode contrast (low contrast is the most common vibe-coded tell)
Grey text on grey panels with barely-visible borders reads as unfinished. Separate layers by lightness, and keep text bright.

- **Background:** a dark grey, never pure black. Dark theme: `#141414`.
- **Layers:** elevated surfaces are clearly lighter than the background, by about 1.15:1 or more.
  - Panels and grouped lists: `#232323`.
  - Controls and filled chips: `#2c2c2c`–`#333333`.
  - Hover: about a 12% white overlay.
  - Shadows barely show in the dark, so depth comes from these lighter layers, not shadows.
- **Text:**
  - Primary `#f2f2f2` (about 16:1 on the background).
  - Secondary `#c4c4c4` (10:1).
  - Tertiary or meta `#9c9c9c` (6.7:1 on the background, 5.1:1 on `#2c2c2c`).
  - Nothing that carries information goes below 4.5:1 on the surface it sits on. Check text on panels and controls, not just on the background.
- **Separators** inside a surface: `#333333`, inset from the left like Apple's grouped lists. Outlines on controls: `#444444`.
- **Accents** are slightly desaturated and bright enough to pass 4.5:1 as text. Saturated colour only on the single primary button.
- **Prefer elevation and grouping over hairline tables.** Full-width rows with column rules look like a spreadsheet or Google Doc. Use rounded grouped lists (12 px radius, inset separators, count capsules) and tiles, as in Apple's Reminders and Settings.

### Themes
**The rule: every theme is two main colours that complement each other, plus one colour that captures attention.**
- Main 1 is the page family (`bg` → `surface` → `surface-2`, each a visible step apart).
- Main 2 is its complement (`acc2`, also the text colour family).
- The attention colour (`accent`/`btn`) is used only for the primary button, progress and what's due. If it shows up anywhere else, it stops working.
- Each theme in `THEMES` carries `pal: [main, complement, attention]`, shown as three dots on its card.

**Custom themes:** people pick three colours (page, text, attention) and a name; `makeTheme()` derives the surfaces, borders and secondary text and `ensureContrast()` pushes anything under 4.5:1. They appear under "Yours" and can be edited or deleted. **Patterns** (None, Graph paper, Contour, Dots) are per theme and must stay faint enough that text on them still passes contrast; they show on the page sheet, never inside cards.

There are twelve themes: four dark, four light, and four Bold (Ink `#000`/white/yellow, Klein `#0a1a86`/white/yellow, Swiss white/black/red, Riso paper/black/fluoro pink). The Bold ones are for people who want the app to pop:

| Theme | id | Main | Complement | Attention |
|---|---|---|---|---|
| Graphite (Recall, default dark) | `harness` | `#232323` | bone `#d9d4c7` | gold `#e8b84a` |
| Blue neutral (Apple) | `appledark` | `#2c2c2e` | slate `#a2b4cc` | blue `#0071e3` |
| Nord | `nord` | `#2e3440` | frost `#88c0d0` | aurora `#ebcb8b` |
| Catppuccin Mocha | `mocha` | `#1e1e2e` | lavender `#b4befe` | peach `#fab387` |
| Blue neutral (Apple, default light) | `applelight` | `#f5f5f7` | slate `#6e7d91` | blue `#0071e3` |
| Solarized | `solarized` | `#fdf6e3` | base02 `#073642` | orange `#cb4b16` |
| Cloud Dancer (Pantone 2026) | `cloud` | `#f0eee9` | espresso `#2b2420` | Mocha Mousse `#a47864` |
| Catppuccin Latte | `latte` | `#eff1f5` | mauve `#8839ef` | peach `#fe640b` |

- **Appearance:** Match system, Always dark or Always light (`theme.mode`, with `theme.dark` and `theme.light` remembering one pick each).
- **Accent swatches** (`theme.acc`) replace only the attention colour.
- **Fonts:** the system font is used for everyone. There is no font picker.
- **Checks:** before adding a theme, check every text token against the surface it sits on (≥ 4.5:1). Check the button label against the button too. `readable()` darkens or lightens an accent that is too faint to be text.
- **Old ids:** `THEME_ALIAS` maps old ids: `paper` → `applelight`, `sepia` → `solarized`, `contrast` → `harness`.

### Shape, space, depth
- **Radii:**
  - 6 px: controls, chips, inputs
  - 10 px: panels, subject windows
  - 12 px: dialogs
  - 4 px: small tags
  - Full pills only for transient badges (the rating flash).
- **Spacing:** 4 px grid: 4, 8, 12, 16, 24, 32.
- **Borders:** 1 px hairlines. No shadows on in-flow elements; shadows only on things that float (menus, dialogs, toasts, a window being dragged).

### Components
- **Buttons:**
  - 30 px high (26 sm, 36 big), 6 px radius, 13 px/500.
  - The primary is the gold fill with dark text.
  - Keyboard hints go in `<kbd>` inside the button.
- **Layers (Frame A):** chrome (sidebar + toolbar, `--side-solid`) → the page as a raised sheet (12 px radius, 1 px border, 8 px from the window edge) → cards → controls. Each layer is a visible step in lightness. Don't put cards straight on the chrome.
- **Window chrome (desktop and iPad landscape):**
  - The sidebar toggle and back/forward (`.navcl`) sit beside the traffic lights.
  - The **page toolbar** (`#appbar`, 52 px, `renderAppbar()`) shows the page title or breadcrumb on the left and this page's actions on the right.
    - The search field sits in the middle of the toolbar (hidden on Browse, which has its own).
    - **Decks:** "Study all N".
    - **Themes:** Match system / Always dark / Always light.
    - **Study:** back one step, edit, timer, scratchpad, shuffle, then "3 of 20", with a progress line along its bottom edge.
  - There is no bottom bar during study on desktop.
- **Sidebar order:** brand → Add card (with `A` hint) → Decks / Browse / Stats / Themes → Subjects (each with a mastery ring and due count; clicking one opens it on Decks) → the Today card → sync status at the bottom. Recent decks live on the Decks page, not here.
- **Decks (home), one subject at a time:**
  - **Subject tabs** (`.stab`) are pills on a segmented track, with the subject dot and due count. The indicator slides between them in the subject colour.
  - **Title row:** the subject name (24 px), "N cards · N reviewed · N due today", a progress bar in the subject colour, and "Study Physics".
  - **Topic cards** (`.tcard`) sit in two balanced columns, on `--surface`.
    - **Big bubbles** (`.bbub`, question types) are filled, bold and 38 px tall.
    - **Subtopics** (`.schip`) are outlined, 500 weight and 30 px tall. Both use bright text.
    - An empty bubble is dashed.
  - **Topics with no cards** collapse into one dashed line.
  - After that comes a dashed "New topic in Physics" button.
  - **The bottom half** has two grouped lists (12 px radius, inset separators): **Pick up where you left off** (`md-recent`) and **You keep forgetting** (cards with Again presses, with "Practise N").
- **Add / edit card** is a full-window builder (`.builder`).
  - **Top bar:** back, "New card in …", Draft saved, Cancel, Add card ⌘↵.
  - **Left:** the fields, including Marks (Auto / 1–5+) and Time limit (Auto from marks / Set own).
  - **Right:** a live Front/Back preview of the card as it will be studied.
  - New-card drafts are kept in `md-draft`. There is no sticky bottom footer.
- **New subject / topic / subtopic** (`topicDialog`) is a plain form, with no `::` syntax.
  - **Fields:** Name, Inside, question types as toggles plus Custom (topics only), and subtopics typed as chips with Enter.
  - A "How it will look" preview shows the result.
- **Empty states:** never a dashed box saying "nothing here yet" or "add something here". If a section is empty, leave it out; if the user adds something, it appears.
- **To-do:** a grouped list (12 px radius) under the topic cards. Ticking is the one celebratory moment in the app: pop, check draw, ring and dot burst in the subject colour, strike-through, fold away (about 0.9 s, off under reduced motion).
- **Themes page:** a list on the left (Dark, Light, Bold, Yours, then "New theme from these colours"), each row with its three-colour palette. On the right: a live mini preview of the app, the custom editor when one is open, then Pattern, Accent, Recolour card images, and Subject colours / Background image / Fine-tune folded away.
- **Browse:** three panes. Rows show a thumbnail of the question image (or its first words), the label, the last rating as a pill, two lines of the question and the deck. The selected card shows on the right with Move / Edit / Practise and its rating history.
- **Deck page:** a header in the subject colour with that subject's line art, the counts and Study; then question types, subtopics with mastery bars, and "Got wrong lately".
- **Study:**
  - The breadcrumb (last part bold) is small; the question is the hero.
  - Tools (Timer, Scratchpad, Shuffle) live in the page toolbar on desktop, and stay as quiet text buttons on phones.
  - **Timer:** Off / Stopwatch / Time limit.
    - **Time limit** is "From the marks" (1.8 min a mark; "(4 marks)" is detected) or "Same for every card".
    - **When time runs out:** show overtime, or show the answer.
    - Settings apply to all subjects or one. `T` pauses.
    - **Display:** large digits on the right of the question line, with a 3 px bar under it that drains. It turns amber in the last minute and red "+0:32 over 7:12" past the limit. After the reveal it reads "Took 6:40 of 7:12".
  - Answer sections have no boxes: a coloured dot + heading, then the text.
  - Rating buttons are neutral with a coloured label, interval and number key.
  - The bottom bar holds Back / Edit · "Card 3 of 20 · 2 done" · Exit.
- **Stats:**
  - One plain-language finding at the top (a slipping subject, the streak, or today).
  - Four KPIs with sparklines, then a year heatmap.
  - Scope tabs: All shows mastery by subject; a subject shows a donut, 12 weeks of reviews and its topics.
  - "Fix these first" (forgotten cards and leeches, grouped) and the slowest cards.
  - Bars are neutral, with the current period in the attention colour.

### Motion (short, purposeful, never on scroll)
- **Easing:** `--ease` = `cubic-bezier(.2,.7,.2,1)`. No bounce.
- **Durations:** 120 ms for micro feedback, 180–260 ms for things entering. Nothing longer except the answer reveal (about 600 ms, and it never blocks input).
- **Signature moments:**
  - **Answer reveal ("Focus"):** the question dims and shrinks slightly, and the answer sharpens out of a blur into place. No sweep line.
  - **Rating:** the pressed button depresses. The card lifts away (130 ms), the next card rises in, and a small pill above the bottom bar confirms "Good · back in 10m". Input is locked during the 130 ms, so a double press can't rate twice.
  - **Page change:** content rises 4 px (200 ms). Expanding a subject or topic unfolds its children (200 ms).
  - **Progress bars** animate their width.
  - **Switching subject tabs:** the underline slides, counts tick up, and the topic cards rise in sequence (40 ms apart).
  - **Applying a theme:** the new palette spreads out in a circle from the card you clicked (View Transitions, 560 ms).
  - **Builder:** it slides up 12 px as it opens, and the preview follows typing.
- Everything is turned off under `prefers-reduced-motion`. Never put information only in an animation.

---

## 4. How to critique a screen before shipping

Use this every time a screen changes. Take screenshots with Playwright (see HANDOVER §8) at 1440×900, 1180×820 (iPad) and 390×844 (iPhone), and look at them.

1. **5-second test.** What is this screen for, what is the one thing to press, and what draws the eye first? If the answer to the last question isn't the content or the primary action, the hierarchy is wrong.
2. **Slop scan.** Go down §1. Any glow, gradient, uppercase mono label, nested card, rainbow tint, zero-tile grid or decorative motion?
3. **Heuristics (Nielsen).**
   - Is system status visible?
   - Are labels in the user's language?
   - Can the user undo or go back?
   - Are things consistent?
   - Are errors prevented?
   - Is recognition favoured over recall?
   - Are there shortcuts for experts?
   - Is the design minimal?
   - Are errors helpful?
4. **Colour audit.** List every coloured element. Each one must map to a row in the colour-roles table. Check contrast in both Dark and Light.
5. **Type audit.** Only sizes from the scale, only 400/500/600, sentence case, tabular numbers.
6. **States.** Empty deck, empty subject, no cards due, first card, last card (done screen), long names (truncate, don't wrap counts), offline/sync.
7. **Devices.**
   - No horizontal scroll on the phone.
   - Touch targets are big enough.
   - Hover-only controls are visible on touch.
   - Nothing is hidden behind the iPad safe area.
8. **Run `sweep.js`** in the three modes (HANDOVER §8). Expected noise: "invisible control: icon soft" (gear icons that appear on hover) and menu items caught mid fade-in.

**How to write feedback:**
- Use the form: *what's wrong* + *which principle* + *why it matters to the user* + *the fix*.
  - Good: "The Study buttons are tinted in each subject's colour, so Maths's red one reads as Delete (one colour, two meanings). Make them neutral; keep colour for the subject dot."
  - Bad: "looks off".
- Lead with the most impactful issue.
- Say what works, too.

---

## 5. References
- Apple Human Interface Guidelines: Typography, Color, Sidebars, Motion (developer.apple.com/design/human-interface-guidelines)
- Linear, "How we redesigned the Linear UI" and "Behind the latest design refresh": fewer colours, dimmer chrome, content first
- Refactoring UI: hierarchy through weight and contrast, spacing over lines, fewer borders
- Nielsen's 10 usability heuristics; Laws of UX (lawsofux.com)
- The Fountain Institute, "7 signs a UI has been vibe coded"; impeccable.style, "The visible tells of AI design"; 925 Studios, "AI slop design tells"
