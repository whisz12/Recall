// NESA one-click papers with a mocked desktop.nesaGet (structure copied from NESA's real pages, 10 Nov 2026)
const fs = require('fs');
module.exports = async (p, E, shot) => {
  const exam = [...fs.readFileSync(__dirname + '/paper.pdf')], mg = [...fs.readFileSync(__dirname + '/NSB 2023 Physics Trial Solutions.pdf')];
  await E(({ exam, mg }) => {
    const B = 'https://www.nsw.gov.au/education-and-training/nesa/curriculum/hsc-exam-papers/', F = '/sites/default/files/noindex/2025-05/';
    const page = links => `<html><body><nav><a href="/x/2001">nav 2001</a></nav><main>${links.map(([t, h]) => `<p><a href="${h}">${t}</a></p>`).join('')}</main></body></html>`;
    const P = {
      'mathematics-advanced': page([['Mathematics HSC exam papers archive', '/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-archive'], ...[2026, 2025, 2024, 2023, 2022, 2021, 2020].map(y => [`Mathematics Advanced ${y} HSC exam pack`, `/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-advanced/${y}`])]),
      'mathematics-advanced/2024': page([['Mathematics Advanced HSC exam 2024 (PDF 2.14MB)', F + '2024-hsc-maths-adv.pdf'], ['Mathematics Advanced HSC marking guidelines 2024 (PDF 707.9KB)', F + '2024-hsc-maths-adv-mg.pdf'], ['Mathematics Advanced HSC marking feedback 2024 – Section II (PDF 340KB)', F + '2024-hsc-mathematics-adv-marking-feedback.pdf'], ['2026', B + 'mathematics-advanced/2026']]),
      'mathematics-advanced/2023': page([['Mathematics Advanced HSC exam 2023 (PDF 2MB)', F + '2023-hsc-maths-adv.pdf'], ['Mathematics Advanced HSC marking guidelines 2023 (PDF 700KB)', F + '2023-hsc-maths-adv-mg.pdf']]),
      'mathematics-advanced/2026': page([['Mathematics Advanced HSC exam paper 2026 (PDF 1.37MB)', '/sites/default/files/noindex/2026-10/2026-hsc-maths-advanced.pdf']]),
      'mathematics-archive': page([...[2019, 2018, 2017, 2016, 2015].map(y => [`Mathematics ${y} HSC exam pack (archive)`, `/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-archive/${y}`])]),
      'mathematics-archive/2019': page([['Mathematics HSC exam 2019 (PDF 1.62MB)', F + '2019-hsc-mathematics.pdf'], ['Mathematics HSC marking guidelines 2019 (PDF 982KB)', F + '2019-hsc-maths-mg.pdf']]),
      'english-advanced': page([['English Advanced HSC exam papers archive', B + 'english-advanced-archive'], ['English Advanced 2024 HSC exam pack', B + 'english-advanced/2024']]),
      'english-advanced/2024': page([['English Advanced HSC exam 2024 – Paper 1 (PDF 1.27MB)', '/sites/default/files/noindex/2025-07/2024-hsc-english-adv-paper-1-cc.pdf'], ['English Advanced HSC exam 2024 – Paper 2 (PDF 166KB)', F + '2024-hsc-english-adv-paper-2.pdf'], ['English Advanced HSC marking guidelines 2024 – Paper 1 (PDF 251KB)', F + '2024-hsc-english-adv-paper-1-mg.pdf'], ['English Advanced HSC marking guidelines 2024 – Paper 2 (PDF 203KB)', F + '2024-hsc-english-adv-paper-2-mg.pdf']]),
    };
    window.__nesa = []; window.__nesaFail = null;
    window.desktop.nesaGet = async url => {
      window.__nesa.push(url.replace(B, '~/').replace('https://www.nsw.gov.au', ''));
      if (window.__nesaFail && url.includes(window.__nesaFail)) throw new Error("Error invoking remote method 'nesa-get': Error: NESA replied 503");
      if (/\.pdf$/.test(url)) return { url, name: url.split('/').pop(), bytes: new Uint8Array(/-mg\.pdf$/.test(url) ? mg : exam) };
      const k = url.replace(B, '').replace(/\/$/, ''); if (!P[k]) throw new Error("Error invoking remote method 'nesa-get': Error: NESA replied 404");
      return { url, html: P[k] };
    };
    undoMute = true; S.settings = { ...S.settings, ppSubj: { ...(S.settings.ppSubj || {}), maths: true, english: true } }; undoMute = false;
    pp.s = 'maths'; pp.c = { ...(pp.c || {}), maths: 'adv' }; go('papers');
  }, { exam, mg });
  await p.waitForTimeout(900);
  const yrs = await E(() => [...document.querySelectorAll('.ppyr')].map(b => b.dataset.k).filter(k => /^n:/.test(k)).slice(0, 4));
  console.log(JSON.stringify(['hsc years shown', yrs, 'requests', await E(() => window.__nesa)]));
  await shot('list');

  // 2024: one click gets the exam and the marking guidelines
  await p.click('[data-act="pp-open"][data-k="n:adv:2024"]');
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(800);
  console.log(JSON.stringify(['2024', await E(() => { const pa = Object.values(ppPapers()).find(x => x.key === 'n:adv:2024'); return { view: view.name, solSep: pa?.solSep, solName: pa?.solName, name: pa?.name, solFrom: ppm?.solFrom, locked: ppm?.locked, req: window.__nesa.slice(-3) }; })]));
  await shot('mark2024');

  // 2019: an archive year (old Mathematics course)
  await E(() => { window.__nesa = []; go('papers'); }); await p.waitForTimeout(500);
  await E(() => { pp.y = ''; renderPapers(); });
  const has19 = await E(() => !!document.querySelector('[data-k="n:adv:2019"]'));
  if (has19) { await p.click('[data-act="pp-open"][data-k="n:adv:2019"]'); await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(500); }
  console.log(JSON.stringify(['2019', has19, await E(() => ({ view: view.name, req: window.__nesa, solSep: Object.values(ppPapers()).find(x => x.key === 'n:adv:2019')?.solSep }))]));

  // English Paper 2 picks Paper 2 files
  await E(() => { window.__nesa = []; ppNesaGet('en2', 2024).then(r => window.__en2 = [r.exam.name, r.mg?.name]); }); await p.waitForTimeout(600);
  console.log(JSON.stringify(['en2', await E(() => window.__en2), 'en1', await E(async () => { const r = await ppNesaGet('en1', 2024); return [r.exam.name, r.mg?.name]; })]));

  // failure: falls back to the Open on NESA dialog with the reason
  await E(() => { window.__nesaFail = '2022'; go('papers'); }); await p.waitForTimeout(500);
  await p.click('[data-act="pp-open"][data-k="n:adv:2022"]'); await p.waitForTimeout(900);
  console.log(JSON.stringify(['fail', await E(() => ({ warn: document.querySelector('.ppwarn')?.textContent, open: document.querySelector('.ppget a.btn')?.getAttribute('href') }))]));
  await shot('fail');
  await E(() => closeDialog());

  // a NESA paper added by hand before 1.29 (no solutions) gets its marking guidelines when opened
  await E(async () => { window.__nesaFail = null; window.__nesa = []; const f = new File([new Uint8Array(await (await ppPdfOf(Object.values(ppPapers()).find(x => x.key === 'n:adv:2024'))).buf)], '2023 exam.pdf', { type: 'application/pdf' }); const it = ppItemOf('n:adv:2023'); await ppAddPdf(it, f, { open: false }); });
  await E(() => go('ppmark', Object.values(ppPapers()).find(x => x.key === 'n:adv:2023').id));
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(600);
  console.log(JSON.stringify(['backfill', await E(() => { const pa = Object.values(ppPapers()).find(x => x.key === 'n:adv:2023'); return { solSep: pa.solSep, solFrom: ppm?.solFrom, req: window.__nesa }; })]));
  // the web app (no nesaGet) keeps the old dialog
  await E(() => { delete window.desktop.nesaGet; go('papers'); }); await p.waitForTimeout(400);
  await p.click('[data-act="pp-open"][data-k="n:adv:2021"]'); await p.waitForTimeout(500);
  console.log(JSON.stringify(['old app', await E(() => [...document.querySelectorAll('.ppget .body > p.hint')].map(x=>x.textContent).join(' | '))]));
  await shot('oldapp');
};
