module.exports = async (p, E, shot) => {
  const M = !!process.env.MOBILE, log = (...a) => console.log(...a);
  const toastTxt = () => E(() => { const t = $('#toast'); return t.hidden ? null : t.innerText.replace(/\n/g, ' '); });
  // ---- skip until tomorrow (due study) ----
  const subj = await E(() => kids(null)[0].id);
  const due0 = await E(id => toStudy(counts(id)), subj);
  await E(id => startStudy(id), subj); await p.waitForTimeout(700);
  const a = await E(() => study.cur); await shot('study');
  const sk = M ? '#answerbar [data-act="study-skip"]' : '#appbar [data-act="study-skip"]';
  await p.click(sk); await p.waitForTimeout(500);
  log('skip', await E(id => ({ moved: study.cur !== id, snz: S.cards[id].snz > Date.now(), inQueue: study.queue.includes(id) }), a), 'due', due0, '->', await E(id => toStudy(counts(id)), subj), '| toast', await toastTxt());
  await shot('skiptoast');
  await p.click('#toast .toastundo'); await p.waitForTimeout(500);
  log('undo button', await E(id => ({ cur: study.cur === id, snz: S.cards[id].snz || 0 }), a), 'due', await E(id => toStudy(counts(id)), subj), '| toast', await toastTxt());
  if (!M){ await p.keyboard.press('s'); await p.waitForTimeout(400); log('S key', await E(id => S.cards[id].snz > Date.now(), a)); }
  else { await p.click(sk); await p.waitForTimeout(400); }
  // a new session leaves it out; practise keeps it
  await E(id => startStudy(id), subj); await p.waitForTimeout(400);
  log('new session has it', await E(id => study.queue.includes(id) || study.cur === id, a));
  await E(id => startStudy(id, true), subj); await p.waitForTimeout(400);
  const b = await E(() => study.cur), left = await E(() => study.queue.length);
  log('practise has it', await E(id => study.queue.includes(id) || study.cur === id, a));
  await p.click(sk); await p.waitForTimeout(400); log('practise skip', await E(id => ({ moved: study.cur !== id, snz: S.cards[id].snz || 0, left: study.queue.length }), b), 'was', left, '|', await toastTxt());
  await p.click('#toast .toastundo'); await p.waitForTimeout(400); log('practise undo', await E(id => study.cur === id, b));
  // delete + Undo button
  await p.click(M ? '#answerbar [data-act="study-del"]' : '#appbar [data-act="study-del"]'); await p.waitForTimeout(250); await p.click('#layer [data-act="do-del-card"]'); await p.waitForTimeout(500);
  log('deleted', await E(id => !S.cards[id], b), '|', await toastTxt()); await p.click('#toast .toastundo'); await p.waitForTimeout(500); log('undo delete', await E(id => !!S.cards[id] && study.cur === id, b));
  // ---- shortcut sheet ----
  if (!M){ await p.keyboard.press('?'); await p.waitForTimeout(300); log('keys dialog', await E(() => $('#layer .keysdlg')?.innerText.split('\n').length)); await shot('keys'); await p.keyboard.press('Escape'); await p.waitForTimeout(200); }
  // ---- decks footer ----
  await E(() => go('decks')); await p.waitForTimeout(500);
  log('footer', await E(() => [...document.querySelectorAll('.hfoot .link')].filter(b => getComputedStyle(b).display !== 'none').map(b => b.innerText).join(' | ')));
  await shot('decks');
  // ---- phone bar ----
  if (M){
    log('nav', await E(() => { const n = $('.toolbar nav'), r = n.getBoundingClientRect(); return [getComputedStyle(n).position, Math.round(r.top), Math.round(r.height), innerHeight, [...n.children].filter(b => getComputedStyle(b).display !== 'none').map(b => b.innerText.trim() + (b.getAttribute('aria-current') === 'true' ? '*' : '')).join(' ')]; }));
    await p.click('.navmore'); await p.waitForTimeout(250); await shot('more'); log('more menu', await E(() => { const m = $('#menu'), r = m.getBoundingClientRect(); return [m.innerText.replace(/\n/g, ' / '), Math.round(r.top), Math.round(r.bottom)]; }));
    await p.click('#menu [data-nav="stats"]'); await p.waitForTimeout(500); log('went', await E(() => [view.name, !!$('#menu'), $('.navmore').getAttribute('aria-current')])); await shot('stats');
    await p.click('.toolbar nav [data-nav="todo"]'); await p.waitForTimeout(400);
  } else await E(() => go('todo'));
  // ---- to-do tabs ----
  await E(() => { S.settings = { ...S.settings, todos: [{ id: 'a1', t: 'Task one', s: null, done: 0, at: 1, l: 'today' }, { id: 'a2', t: 'Task two', s: null, done: 0, at: 2, l: 'today' }] }; todoTab = 'today'; go('todo'); }); await p.waitForTimeout(500);
  const tabs = () => E(() => [...document.querySelectorAll('#tdo .tdtabs button[data-own]')].map(b => b.innerText.replace(/\n/g, ' ') + (b.getAttribute('aria-selected') === 'true' ? '*' : '')).join(' | '));
  log('tabs', await tabs());
  await p.click('[data-act="todo-tab"][data-v="today"]'); await p.waitForTimeout(200); log('tab menu', await E(() => $('#menu').innerText.replace(/\n/g, ' / ')));
  await p.click('#menu [data-act="todo-tabshift"]'); await p.waitForTimeout(250); log('move right', await tabs(), JSON.stringify(await E(() => S.settings.todoOrder)));
  if (!M){
    const bx = async k => { const r = await p.locator(`[data-act="todo-tab"][data-v="${k}"]`).boundingBox(); return [r.x + r.width / 2, r.y + r.height / 2, r]; };
    let [x, y] = await bx('later'), [x2] = await bx('doing');
    await p.mouse.move(x, y); await p.mouse.down(); await p.mouse.move(x - 30, y, { steps: 4 }); await p.mouse.move(x2 - 60, y, { steps: 12 }); await shot('tabdrag'); await p.mouse.up(); await p.waitForTimeout(300);
    log('dragged Later first', await tabs(), '| still on', await E(() => todoTab), '| menu', await E(() => !!$('#menu')));
    await p.keyboard.press('Meta+z'); await p.waitForTimeout(300); log('undo', await tabs());
    // drag a task onto the Homework tab
    const r = await p.locator('[data-tid="a1"] .tdt').boundingBox(); [x, y] = await bx('hw');
    await p.mouse.move(r.x + 40, r.y + r.height / 2); await p.mouse.down(); await p.mouse.move(r.x + 60, r.y - 10, { steps: 4 }); await p.mouse.move(x, y, { steps: 14 }); await shot('taskdrag');
    log('hover', await E(() => $('#tdo .tdtabs .tddrop')?.dataset.v)); await p.mouse.up(); await p.waitForTimeout(400);
    log('dropped', await E(() => todoAll().map(x => x.id + ':' + x.l).join(' ')), '|', await tabs(), '|', await toastTxt());
    await p.click('#toast .toastundo'); await p.waitForTimeout(300); log('undo', await E(() => todoAll().map(x => x.id + ':' + x.l).join(' ')));
    // plain reorder inside the list still works
    const r1 = await p.locator('[data-tid="a1"] .tdt').boundingBox(), r2 = await p.locator('[data-tid="a2"] .tdt').boundingBox();
    await p.mouse.move(r1.x + 40, r1.y + r1.height / 2); await p.mouse.down(); await p.mouse.move(r1.x + 40, r2.y + r2.height, { steps: 10 }); await p.mouse.up(); await p.waitForTimeout(300);
    log('reorder', await E(() => [...document.querySelectorAll('#tdo .tdl > .tdr')].map(r => r.dataset.tid).join(' ')));
  }
  await shot('todo');
};
