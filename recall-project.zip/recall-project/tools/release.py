# One build for every device: the iPad/web page, the desktop page, and the update files GitHub serves to the Mac/Windows apps
import os as _o
ROOT = _o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))
import os, re, subprocess, time, json, shutil
S = ROOT + '/tools/'
MIN_SHELL = '1.27.0'   # raise this when the Mac/Windows app itself (main.js / preload.js / bundled libraries) changes in a way the page depends on
ver = time.strftime('%Y%m%d%H%M%S')
subprocess.run(['python3', S + 'todesk.py'], check=True)
subprocess.run(['python3', S + 'build_web.py'], check=True, env={**os.environ, 'RECALL_VER': ver})
d = ROOT + '/app/app/index.html'; h = open(d).read()
h = re.sub(r'^<!-- recall-build:\d+ min-shell:[\d.]+ -->\n', '', h, flags=re.M)
i = h.index('\n') + 1 if h.lower().startswith('<!doctype') else 0
h = h[:i] + f'<!-- recall-build:{ver} min-shell:{MIN_SHELL} -->\n' + h[i:]
if not h.rstrip().endswith('</html>'): h = h.rstrip() + '\n</html>\n'
open(d, 'w').write(h)
shutil.copy(d, ROOT + '/web/desktop.html')
json.dump({'build': ver, 'minShell': MIN_SHELL}, open(ROOT + '/web/version.json', 'w'))
print('release', ver, 'minShell', MIN_SHELL)
