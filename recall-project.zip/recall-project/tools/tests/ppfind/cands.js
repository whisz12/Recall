const fs = require('fs'); const [id, maxp] = process.argv.slice(2);
const R = JSON.parse(fs.readFileSync(`json/${id}.json`));
const rx = /^(question\s*\d|q\s*\d|\d{1,2}\s*[.)]|\d{1,2}\s+[A-Z(]|\(?[a-h]\s*\)|\(?(i|ii|iii|iv|v|vi|vii)\s*\)|section|part\b|end of|marking|solution|answer)/i;
for (const p of R.pages){ if (maxp && p.n > +maxp) break; const out = p.lines.filter(l => rx.test(l.text)); if (!out.length) continue; console.log(`-- p${p.n} m${p.margin.toFixed(0)} w${p.w.toFixed(0)}`); for (const l of out) console.log(`  ${l.x.toFixed(0).padStart(4)} ${l.y.toFixed(0).padStart(4)} r${l.r.toFixed(0)} | ${l.text.slice(0, 90)}`); }
