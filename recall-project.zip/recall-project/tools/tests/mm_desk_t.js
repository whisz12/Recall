const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/errimg|ERR_|supabase|net::|Failed to load/.test(m.text())) errs.push(m.text()); });
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(lib => { const db = JSON.parse(lib); window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.27.0', build: '1', updated: false }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async () => true, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, lib);
  await p.goto('file://' + path.resolve(__dirname, '../../app/app/index.html')); await p.waitForTimeout(1500);
  const bart = fs.readFileSync('' + require('path').join(__dirname, '../memorise/bart.txt') + '', 'utf8');
  await p.evaluate(bart => { if (dialogOpen()) closeDialog(); }, bart);
  await p.click('nav [data-nav="memo"]'); await p.waitForTimeout(200); await p.screenshot({ path: path.join(__dirname, 'mm_shots/') + 'e-empty.png' });
  await p.click('.mmempty [data-act="mm-new"]'); await p.fill('#mmdt', 'Bart'); await p.fill('#mmdx', bart); await p.click('[data-act="mm-save"]'); await p.waitForTimeout(200);
  const speak = await p.evaluate(() => $('[data-act="mm-mode"][data-v="speak"]').getAttribute('aria-disabled'));
  await p.click('[data-act="mm-sec"][data-v="1"]'); await p.click('[data-act="mm-mode"][data-v="choice"]'); await p.click('[data-act="mm-start"]');
  for (let i = 0; i < 400; i++){ const d = await p.evaluate(() => !mm.run || mm.run.done); if (d) break; const j = await p.evaluate(() => mm.run.ok); await p.keyboard.press(String(j + 1)); }
  const res = await p.evaluate(() => ({ acc: mm.run?.acc, saved: mmAll().length, hist: mmAll()[0].hist.length }));
  await p.screenshot({ path: path.join(__dirname, 'mm_shots/') + 'e-desktop.png' });
  await p.click('[data-act="mm-home"]'); await p.click('[data-act="mm-tab"][data-v="guide"]'); await p.click('[data-act="mg-sec"][data-v="booklet"]');
  const [dl] = await Promise.all([p.waitForEvent('download', { timeout: 5000 }).catch(() => null), p.click('#bDl')]);
  console.log(JSON.stringify({ speakDisabled: speak, res, booklet: dl ? await dl.suggestedFilename() : null, errs }));
  await b.close();
})();
