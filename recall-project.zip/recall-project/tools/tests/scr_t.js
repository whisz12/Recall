const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]];
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8775);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ua = W > 700 ? 'Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: true, isMobile: true, deviceScaleFactor: 2, userAgent: ua }); const p = await ctx.newPage();
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)|supabase\.co/, route => route.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
  await p.goto('http://127.0.0.1:8775/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a);
  await E(() => { document.querySelector('#layer').innerHTML = ''; go('decks'); });
  const diag = () => E(() => { const se = document.scrollingElement, pg = document.querySelector('.page'), cs = x => x && getComputedStyle(x);
    const st = document.querySelector('.stabs'), r = st?.getBoundingClientRect();
    return { htmlCls: document.documentElement.className, bodyCls: document.body.className, pageCls: pg?.className, scrollY, sh: se.scrollHeight, ch: se.clientHeight, htmlOv: cs(document.documentElement).overflowY, bodyOv: cs(document.body).overflowY, bodyPos: cs(document.body).position, pageOv: cs(pg)?.overflowY, pageH: pg?.scrollHeight + '/' + pg?.clientHeight, pageTop: pg?.scrollTop, tabsTop: r && Math.round(r.top), appbarBottom: Math.round(document.querySelector('.appbar')?.getBoundingClientRect().bottom || 0), atTop: document.elementFromPoint(innerWidth / 2, 120)?.className };
  });
  console.log('start', JSON.stringify(await diag()));
  // scroll down with a finger, then tap another subject tab
  await p.mouse.wheel(0, 900); await p.waitForTimeout(400);
  console.log('scrolled', JSON.stringify(await diag()));
  await E(() => { const t = [...document.querySelectorAll('.stab[data-act="subj-tab"]')].find(x => x.getAttribute('aria-selected') !== 'true'); t?.scrollIntoView({ block: 'nearest' }); });
  await p.tap('.stab[data-act="subj-tab"]:not([aria-selected="true"])'); await p.waitForTimeout(800);
  console.log('after tab', JSON.stringify(await diag()));
  await p.screenshot({ path: `/tmp/scr_${TAG}.png` });
  // can we scroll up and down?
  const cdp = await ctx.newCDPSession(p);
  await cdp.send('Input.synthesizeScrollGesture', { x: W / 2, y: H / 2, yDistance: -600, gestureSourceType: 'touch' }); await p.waitForTimeout(500);
  console.log('after finger scroll down', JSON.stringify(await diag()));
  await cdp.send('Input.synthesizeScrollGesture', { x: W / 2, y: H / 2, yDistance: 1200, gestureSourceType: 'touch' }); await p.waitForTimeout(500);
  console.log('after finger scroll up', JSON.stringify(await diag()));
  await b.close(); srv.close();
})();
