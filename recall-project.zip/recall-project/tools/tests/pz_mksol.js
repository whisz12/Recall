const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage();
  let h = '<style>body{font:14px Times;margin:0} .pg{page-break-after:always;padding:60px 70px;height:950px;box-sizing:border-box} h1{font-size:20px} .q{margin:0 0 30px}</style>';
  h += '<div class="pg"><h1>Solutions</h1><p>North Sydney Boys High School 2023 Trial HSC Physics: marking guidelines and worked solutions.</p>';
  for (let n = 1; n <= 15; n++){ if (n === 6 || n === 11) h += '</div><div class="pg">'; h += `<div class="q"><b>Question ${n}</b> (${(n % 4) + 2} marks)<br>Time of flight t = ${(1 + n / 10).toFixed(2)} s. Range R = ${(10 + n * 1.7).toFixed(1)} m. Final velocity v = ${(20 + n).toFixed(1)} m s<sup>-1</sup> at ${30 + n}° below the horizontal.<br>1 mark for correct substitution, 1 mark for the answer with units.</div>`; }
  h += '</div>';
  await p.setContent(h); await p.pdf({ path: 'NSB 2023 Physics Trial Solutions.pdf', format: 'A4' }); await b.close(); console.log('ok');
})();
