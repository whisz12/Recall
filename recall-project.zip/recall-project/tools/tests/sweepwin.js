const { chromium } = require('playwright'); const fs = require('fs');
const MOBILE = !!process.env.MOBILE;
const W = +process.argv[2] || 1400, H = +process.argv[3] || 900, TAG = process.argv[4] || 'd';
const T0 = Date.now();
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext(MOBILE ? { viewport: { width: W, height: H }, hasTouch: true, isMobile: true, deviceScaleFactor: 2, userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1' } : { viewport: { width: W, height: H } }); const p = await ctx.newPage(); p.setDefaultTimeout(4000);
  const errs = []; let step = 'boot';
  p.on('pageerror', e => errs.push(`[${step}] ${e.message}`));
  p.on('console', m => { if (m.type() === 'error' && !/errimg|ERR_|supabase|net::|Failed to load resource/.test(m.text())) errs.push(`[${step}] console: ${m.text()}`); });
  p.on('dialog', d => { errs.push(`[${step}] native dialog: ${d.message()}`); d.dismiss(); });
  const lib = fs.readFileSync(require('path').join(__dirname, 'lib20.json'), 'utf8');
  if (process.env.WEB){
    const http = require('http'), path = require('path'); const root = require('path').resolve(__dirname, '../../web');
    global.srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.json') ? 'application/json' : 'application/octet-stream' }); fs.createReadStream(f).pipe(r); }).listen(8770);
    const V = require('path').resolve(__dirname, '../../app/app/vendor') + '/';
    await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)/, route => { const u = route.request().url(); const m = u.includes('supabase') ? V + 'supabase.js' : u.includes('fflate') ? V + 'fflate.js' : u.includes('fzstd') ? V + 'fzstd.js' : u.includes('sql-asm') ? V + 'sql-asm.js' : null; if (m && fs.existsSync(m)) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(m) }); route.fulfill({ status: 200, contentType: u.endsWith('.css') || u.includes('css') ? 'text/css' : 'text/javascript', body: '' }); });
    await p.addInitScript(([lib, key]) => { if (!localStorage.getItem(key)) localStorage.setItem(key, lib); }, [lib, process.env.LKEY]);
    await p.goto('http://127.0.0.1:8770/'); await p.waitForTimeout(1800);
  } else {
  await p.addInitScript(lib => { const db = JSON.parse(lib); window.desktop = { platform: 'win32', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.27.0', build: '20261102003633', updated: false }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async () => true, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, lib);
  await p.goto('file://' + require('path').resolve(__dirname, '../../app/app/index.html')); await p.waitForTimeout(1300);
  }
  const E = (f, a) => p.evaluate(f, a);
  const issues = [];
  const check = async label => {
    step = label; console.error('> ' + label + ' ' + ((Date.now() - T0) / 1000).toFixed(1));
    const r = await E(() => {
      const out = [];
      if (document.documentElement.scrollWidth > innerWidth + 1) out.push('horizontal scroll ' + document.documentElement.scrollWidth + '>' + innerWidth);
      const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      for (const el of document.querySelectorAll('button, a, input, select, textarea')) {
        if (!vis(el)) continue; const cs = getComputedStyle(el);
        if (cs.visibility === 'hidden') continue;
        let o = 1, n = el; while (n && n !== document) { o *= +getComputedStyle(n).opacity; n = n.parentElement; }
        if (o < 0.05 && !el.matches('.recx, .wresize, [hidden], input[type=file], input[type=color]')) out.push('invisible control: ' + (el.textContent.trim().slice(0, 30) || el.className || el.tagName));
        const r = el.getBoundingClientRect();
        if (r.right > innerWidth + 2 && !el.closest('.tabwrap, .hexams, .padbar, .lhpills, .subjgrid, .stabs')) out.push('off-screen right: ' + (el.textContent.trim().slice(0, 30) || el.className));
      }
      for (const el of document.querySelectorAll('.qa, .panel, .dialog, .subj, .menu, #answerbar')) { if (vis(el) && el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX !== 'auto' && getComputedStyle(el).overflowX !== 'scroll') out.push('content overflow in ' + el.className.split(' ')[0]); }
      return [...new Set(out)];
    });
    if (r.length) issues.push(`${label}: ${r.join(' | ')}`);
  };
  const shot = async n => p.screenshot({ path: `sw_${TAG}_${n}.png` });
  const esc = async () => { await p.keyboard.press('Escape'); await p.waitForTimeout(80); await E(() => { closeMenu(); if (dialogOpen()) closeDialog(); }); };
  const nodes = await E(() => { const subj = kids(null)[0], topic = kids(subj.id)[0], sub = kids(topic.id)[0]; const virt = Object.keys(S.nodes).length && (typesOf(topic.id)[0] ? topic.id + '::' + typesOf(topic.id)[0].k : null); return { subj: subj.id, topic: topic.id, sub: sub?.id, virt }; });
  // home
  await E(() => go('decks')); await p.waitForTimeout(300); await check('home'); await shot('home');
  await p.click('.h7home .h7hero', { button: 'right' }); await check('home menu'); await esc();
  for (const t of await p.$$eval('.stab[data-id]', bs => bs.map(b => b.dataset.id))) { await p.click(`.stab[data-id="${t}"]`); await p.waitForTimeout(200); await check('tab ' + t); }
  await shot('tabs');
  step = 'new topic'; await p.click('.h7home [data-act="add-child"]'); await p.waitForTimeout(200); await p.fill('#tdname', 'Sweep topic'); await p.fill('#tdsubin', 'Sub one'); await p.keyboard.press('Enter'); await p.click('[data-act="td-custom"]'); await p.keyboard.type('Essays'); await p.keyboard.press('Enter'); await check('new topic form'); await p.click('#tdgo'); await p.waitForTimeout(250); await check('topic created');
  step = 'todo'; await E(() => go('todo')); await p.waitForTimeout(400); await check('todo page'); await p.fill('#tdoin', 'Sweep task'); await p.keyboard.press('Enter'); await p.click('.tdr .tdck'); await p.waitForTimeout(1100); await check('todo ticked'); await E(() => { todoAllSubj = true; todoRefresh(); });  await check('todo all + done'); await shot('todo'); await E(() => go('decks')); await p.waitForTimeout(400);
  await E(() => { ls.set('md-decks', 'spot'); render(); }); await p.waitForTimeout(300); await check('spotlight'); await shot('spot'); await E(() => { ls.set('md-decks', 'minimal'); render(); });
  step = 'countdown'; await p.click('[data-act="cd-edit"]'); await p.fill('#cdname', 'HSC Trials'); await p.fill('.cdedrow .cdxn', 'Maths'); await p.fill('.cdedrow .cdxd', '2026-12-01'); await p.click('[data-act="cd-addexam"]'); await check('countdown form'); await p.click('[data-act="cd-save"]'); await p.waitForTimeout(300); await check('countdown on home'); await shot('countdown');
  console.log('topic made:', await E(() => { const n = Object.values(S.nodes).find(n => n.name === 'Sweep topic'); return n ? { types: (n.types || []).map(t => t.name), kids: kids(n.id).map(k => k.name) } : null; }));
  for (const id of [nodes.subj, nodes.topic, nodes.sub, nodes.virt].filter(Boolean)) {
    await E(id => gearMenu(id, { x: 400, y: 300 }), id); await check('gear ' + id);
    const acts = await p.$$eval('#menu button', bs => bs.map(b => b.dataset.act).filter(Boolean));
    for (const a of acts) {
      if (/^(practise|browse-here|add-here|import-here|exam-set)$/.test(a)) continue;
      await E(id => gearMenu(id, { x: 400, y: 300 }), id);
      step = `gear ${id} → ${a}`; await p.click(`#menu [data-act="${a}"]`).catch(e => errs.push(step + ' click failed'));
      await p.waitForTimeout(150); await check(step); await esc();
    }
  }
  // overview pages
  for (const id of [nodes.subj, nodes.topic, nodes.sub, nodes.virt].filter(Boolean)) { await E(id => go('overview', id), id); await p.waitForTimeout(200); await check('overview ' + id); }
  await shot('overview');
  // browse
  await E(() => go('browse')); await p.waitForTimeout(300); await check('browse'); await shot('browse');
  for (const v of ['due', 'todo', 'done', 'leech', 'all']) { await p.selectOption('#bstatus', v); await p.waitForTimeout(80); } await p.keyboard.press('ArrowDown'); await p.keyboard.press('ArrowDown');
  await check('browse filters');
  await p.fill('#bsearch', 'integr'); await p.waitForTimeout(250); await check('browse search'); await p.fill('#bsearch', ''); await p.waitForTimeout(200);
  console.log('browse state:', await E(() => ({ q: browse.q, node: browse.node, st: browse.status, r: browse.rate, rows: document.querySelectorAll('#brrows .brow').length, ids: browse.ids.length }))); await E(() => { browse.status = 'all'; browse.rate = 0; render(); }); await p.waitForTimeout(200);
  await p.click('#brrows .brow:nth-child(3)', { button: 'right' }); await check('card menu'); await esc();
  for (const a of ['cm-move', 'cm-also', 'cm-reset', 'cm-delete']) { await p.click('#brrows .brow:nth-child(3)', { button: 'right' }); step = 'card menu ' + a; await p.click(`#menu [data-act="${a}"]`).catch(() => errs.push(step + ' click failed')); await p.waitForTimeout(150); await check(step); await esc(); }
  await p.dblclick('#brrows .brow:nth-child(2)'); await p.waitForTimeout(250); await check('editor'); await shot('editor');
  await p.keyboard.press('ArrowDown'); await p.waitForTimeout(150); await check('editor next');
  await esc();
  // stats / themes
  await E(() => go('stats')); await p.waitForTimeout(300); await check('stats'); await shot('stats');
  for (const id of await p.$$eval('.h7sttabs [data-act="stat-scope"]', bs => bs.map(b => b.dataset.id))) { await p.click(`.h7sttabs [data-id="${id}"]`); await p.waitForTimeout(150); await check('stats scope ' + id); }
  await E(() => go('themes')); await p.click('[data-act="th-new"]'); await p.waitForTimeout(800); await check('custom theme'); for (const pt of ['graph', 'book', 'stars', 'none']) { await p.click(`[data-act="th-pattern"][data-p="${pt}"]`); await p.waitForTimeout(700); } await p.click('[data-act="th-cdone"]').catch(() => {}); await check('patterns');
  await E(() => go('themes')); await p.waitForTimeout(400); await check('themes'); await shot('themes');
  for (const t of await p.$$eval('[data-act="th-pick"]', bs => bs.map(b => b.dataset.th))) { await p.click(`[data-act="th-pick"][data-th="${t}"]`).catch(() => {}); await p.waitForTimeout(120); }
  for (const m of ['dark', 'light', 'system']) { await p.click(`[data-act="th-mode"][data-m="${m}"]`).catch(() => {}); await p.waitForTimeout(150); await check('mode ' + m); }
  await p.click('[data-act="th-acc"][data-c="#30d158"]').catch(() => {}); await p.click('[data-act="th-acc"][data-c=""]').catch(() => {});
  await check('themes cycled');
  for (const l of ['classic', 'harness']) { await p.click(`[data-act="th-layout"][data-layout="${l}"]`).catch(() => {}); await p.waitForTimeout(150); await E(() => go('decks')); await p.waitForTimeout(150); await check('layout ' + l + ' home'); await E(() => go('themes')); await p.waitForTimeout(150); }
  await E(() => updCheck(true)); await p.waitForTimeout(200);
  // study both layouts
  for (const l of ['harness', 'classic']) {
    await E(l => { saveTheme({ ...themeSettings(), layout: l }); }, l);
    await E(id => startStudy(id, true), nodes.topic); await p.waitForTimeout(300); await check(`study ${l}`); await shot('study_' + l);
    await E(() => { const b = document.querySelector('[data-act="timer-menu"]'); b?.click(); }); await p.waitForTimeout(150); await check(`study ${l} timer menu`);
    await p.click('#tpop [data-v="limit"]').catch(() => {}); await p.waitForTimeout(100); await p.click('#tpop [data-act="tmr-step"][data-d="30"]').catch(() => {}); await p.waitForTimeout(100); await check(`study ${l} timer limit`); await shot('timer_' + l);
    await p.keyboard.press('Escape'); await p.keyboard.press('t'); await p.waitForTimeout(300); await check(`study ${l} paused`); await p.keyboard.press('t');
    await p.keyboard.press('p'); await p.waitForTimeout(200); await check(`study ${l} pad`);
    await p.click('[data-pad="full"]'); await p.waitForTimeout(250); await check(`study ${l} pad full`);
    await p.keyboard.press('Space'); await p.waitForTimeout(250); await check(`study ${l} full shown`);
    await p.keyboard.press('Escape'); await p.waitForTimeout(150);
    await p.keyboard.press('p'); await p.waitForTimeout(150);
    await p.keyboard.press('3'); await p.waitForTimeout(250); await check(`study ${l} rated`);
    await p.keyboard.press('z'); await p.waitForTimeout(200); await check(`study ${l} back`);
    await p.keyboard.press('Space'); await p.waitForTimeout(200); await p.keyboard.press('1'); await p.waitForTimeout(200);
    await E(() => { appUndo(); }); await p.waitForTimeout(200); await check(`study ${l} undo`);
    await p.keyboard.press('Escape'); await p.waitForTimeout(200);
  }
  await E(() => saveTheme({ ...themeSettings(), layout: 'harness' }));
  // misc dialogs
  for (const a of ['options', 'new-deck', 'export-all', 'cloud', 'reset-all']) { step = 'dialog ' + a; await E(() => go('decks')); await p.waitForTimeout(120); await E(a => { const b = document.createElement('button'); b.dataset.act = a; document.body.appendChild(b); b.click(); b.remove(); }, a); await p.waitForTimeout(200); await check(step); await esc(); }
  await E(() => editor(null)); await p.waitForTimeout(200); await check('add card dialog'); await esc();
  // sidebar search
  await E(() => go('decks')); await p.click('#sidesq').catch(() => {}); await p.keyboard.type('vector'); await p.waitForTimeout(250); await check('sidebar search'); await p.keyboard.press('Escape');
  // undo / redo storm
  for (let i = 0; i < 6; i++) await E(() => appUndo()); for (let i = 0; i < 6; i++) await E(() => appRedo()); await p.waitForTimeout(200); await check('undo/redo');
  await E(() => toggleSidebar(true)); await p.waitForTimeout(150); await check('sidebar hidden'); await E(() => toggleSidebar(false));
  console.log(JSON.stringify({ W, errors: [...new Set(errs)], issues }, null, 1));
  await b.close(); global.srv?.close();
})().catch(e => { console.error('SCRIPT', e.message); process.exit(1); });
