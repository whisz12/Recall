const fs = require('fs');
module.exports = async (p, E, shot) => {
  const log = (...a) => console.log(...a), rd = n => [...fs.readFileSync(__dirname + '/' + n)];
  const [pp, sa, sb] = ['scan_paper.pdf', 'scan_a.pdf', 'scan_b.pdf'].map(rd);
  await E(() => go('papers')); await p.waitForTimeout(400);
  const pid = await E(async ([pp, sa]) => { await ppAddPdf({ src: 'up', c: ppCourseCur(), sec: 'trial', school: 'Scan High', year: 2024 }, new File([new Uint8Array(pp)], 'S.pdf', { type: 'application/pdf' }), { open: false, solFile: new File([new Uint8Array(sa)], 'scan_a.pdf', { type: 'application/pdf' }) }); return Object.values(ppPapers()).find(x => x.school === 'Scan High').id; }, [pp, sa]);
  const open = async () => { await E(pid => { ppm = null; go('ppmark', pid); }, pid); await p.waitForTimeout(800); await p.waitForFunction(() => ppm && !ppm.busy && ppm.R, null, { timeout: 120000 }).catch(e => console.log('timeout', e.message)); };
  const solText = () => E(() => ppm.R.pages.filter(x => x.sol).map(x => x.lines.map(l => l.text).join(' ')).join(' | ').slice(0, 120));
  await open(); log('dbg', JSON.stringify(await E(() => ({ items: ppm.items.length, tl: ppm.R.textLines, scan: ppScanPages(ppm.R).length, pages: ppm.R.pages.map(x => [x.n, x.sol, x.lines.length, (x.imgs || []).length]) })))); log('A', await solText(), '| cache', await E(async pid => { const c = JSON.parse((await ppGetPdf(ppOcrKey(pid))).buf); return Object.keys(c).join(',') + ' _sol=' + c._sol; }, pid));
  await E(async ([pid, sb]) => { const q = await ppSolStore(ppPapers()[pid], new File([new Uint8Array(sb)], 'scan_b.pdf', { type: 'application/pdf' })); await ppSavePaper(q); ppNesaTried?.clear?.(); }, [pid, sb]);
  await open(); log('B', await solText());
};
