// pictures: dropped on a past paper → picked question's solution (thumbnail, card gets it, remove); dropped on Decks → Add card with it
module.exports = async (p, E, shot) => {
  const mk = () => E(async () => { const c = document.createElement('canvas'); c.width = 400; c.height = 200; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 400, 200); x.fillStyle = '#000'; x.font = '30px sans-serif'; x.fillText('v = u + at', 40, 110); const b = await new Promise(r => c.toBlob(r, 'image/png')); window.__png = new File([b], 'Screenshot.png', { type: 'image/png' }); });
  await mk();
  const drop = (sel) => E(async sel => { const t = document.querySelector(sel), dt = new DataTransfer(); dt.items.add(window.__png); t.dispatchEvent(new DragEvent('dragenter', { dataTransfer: dt, bubbles: true })); t.dispatchEvent(new DragEvent('dragover', { dataTransfer: dt, bubbles: true, cancelable: true })); const cue = document.getElementById('dropcue')?.textContent || ''; const hi = document.getElementById('pppanel')?.classList.contains('drophi'); t.dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true })); return { cue, hi }; }, sel);
  // no question picked
  console.log('no pick', JSON.stringify(await drop('#pppanel')), await E(() => $('#toast').textContent));
  await p.waitForTimeout(300);
  await E(() => { const node = Object.values(S.nodes).find(n => !kids(n.id).length); ppm.node = node.id; ppmPick(2); }); await p.waitForTimeout(300);
  console.log('drop panel', JSON.stringify(await drop('#pppanel'))); await p.waitForTimeout(1200);
  console.log('after', await E(() => JSON.stringify({ simg: Object.entries(ppmP().simg || {}).map(([k, v]) => k + ':' + v.length), thumbs: document.querySelectorAll('.ppsimg').length, toast: $('#toast').textContent, cueGone: !$('#dropcue'), hiGone: !$('#pppanel').classList.contains('drophi') })));
  await p.keyboard.press('3'); await p.waitForTimeout(300);
  console.log('thumbs after wrong', await E(() => document.querySelectorAll('.ppsimg').length));
  // drop on the paper itself goes to the same place
  await drop('#ppscroll'); await p.waitForTimeout(1200);
  await shot('panel');
  await p.click('#ppwhy'); await p.keyboard.type('sign error');
  await p.click('.ppsave'); await p.waitForTimeout(3000);
  console.log('card', await E(() => { const pp = ppmP(), key = ppm.items[2].key, c = S.cards[pp.q[key].card]; return JSON.stringify({ sol: (c.solImgs || []).length, why: c.mistake }); }));
  // remove one: card loses it too
  await E(() => ppmPick(2)); await p.waitForTimeout(300); await p.click('.ppsimg button'); await p.waitForTimeout(600);
  console.log('removed', await E(() => { const pp = ppmP(), key = ppm.items[2].key, c = S.cards[pp.q[key].card]; return JSON.stringify({ simg: pp.simg[key].length, sol: (c.solImgs || []).length }); }));
  // paste on the paper
  await E(() => { const dt = new DataTransfer(); dt.items.add(window.__png); const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }); document.body.dispatchEvent(ev); }); await p.waitForTimeout(1200);
  console.log('pasted', await E(() => ppmP().simg[ppm.items[2].key].length));
  // Decks: opens Add card with the picture
  await E(() => go('decks')); await p.waitForTimeout(600);
  console.log('decks drop', JSON.stringify(await drop('#root'))); await p.waitForTimeout(1200);
  console.log('editor', await E(() => JSON.stringify({ open: !!ed, isNew: ed?.isNew, q: ed?.card.qImgs?.length })));
  await shot('editor');
  // in the editor, dropping outside the boxes adds to the box you're on
  await drop('#root'); await p.waitForTimeout(1000); console.log('editor second', await E(() => ed?.card.qImgs?.length));
};
