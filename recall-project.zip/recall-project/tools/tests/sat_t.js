const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG, SAT] = [+process.argv[2], +process.argv[3], process.argv[4], process.argv[5]];
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8777);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ua = W > 700 ? 'Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: true, isMobile: true, deviceScaleFactor: 2, userAgent: ua }); const p = await ctx.newPage();
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)|supabase\.co/, route => route.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(([lib, sat]) => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib);
    // pretend to be the home-screen app with a status bar: env(safe-area-inset-top) = SAT
    Object.defineProperty(navigator, 'standalone', { value: true });
    document.addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `:root{--sat:${sat}px !important} html.iosapp{--sat:calc(${sat}px + 32px) !important}`; document.head.appendChild(s); });
  }, [lib, SAT]);
  await p.goto('http://127.0.0.1:8777/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a);
  await E(() => { document.querySelector('#layer').innerHTML = ''; S.settings = { ...S.settings }; });
  console.log('cls', await E(() => document.documentElement.className), 'sat', await E(() => getComputedStyle(document.documentElement).getPropertyValue('--sat')));
  for (const v of ['decks', 'papers', 'browse', 'todo']){
    await E(v => { go(v); scrollTo(0, 0); }, v); await p.waitForTimeout(500);
    console.log(v, JSON.stringify(await E(() => { const band = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sat')) || 0; const hdr = document.querySelector(document.body.classList.contains('desktop') ? '.appbar' : 'header.toolbar').getBoundingClientRect();
      const first = [...document.querySelectorAll('#root *')].find(x => { const r = x.getBoundingClientRect(); return r.height > 4 && r.width > 40 && x.children.length === 0 && x.textContent.trim(); });
      return { band, hdrTop: Math.round(hdr.top), hdrBottom: Math.round(hdr.bottom), firstText: first?.textContent.trim().slice(0, 30), firstTop: Math.round(first?.getBoundingClientRect().top) }; })));
    await p.screenshot({ path: `/tmp/sat_${TAG}_${v}.png` });
  }
  await b.close(); srv.close();
})();
