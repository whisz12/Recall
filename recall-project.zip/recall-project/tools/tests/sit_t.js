// Papers: right-click Sit it timed to change the times; Exam timer button on the Papers page. node sit_t.js
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8790);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const touch of [false, true]){
    const ctx = await b.newContext(touch ? { viewport: { width: 1180, height: 820 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 } : { viewport: { width: 1400, height: 900 }, deviceScaleFactor: 2 }); const p = await ctx.newPage();
    const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
    const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
    await p.goto('http://127.0.0.1:8790/'); await p.waitForTimeout(1800);
    const E = (f, a) => p.evaluate(f, a), T = touch ? 'ipad' : 'mac';
    await E(() => go('papers')); await p.waitForTimeout(800);
    console.log(T, 'toolbar:', await E(() => [...document.querySelectorAll('#abr .btn')].map(x => x.textContent.trim())));
    await p.click('text=2025 HSC'); await p.waitForTimeout(300);
    console.log(T, 'before:', await E(() => $('.ppsit p').textContent));
    if (touch){ const bx = await p.locator('.ppsit h2').boundingBox(); await E(([x, y]) => { const t = document.elementFromPoint(x, y); t.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: x, clientY: y, pointerType: 'touch', isPrimary: true })); window.__t = t; }, [bx.x + 10, bx.y + 5]); await p.waitForTimeout(650); await E(() => __t.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerType: 'touch' }))); }
    else await p.click('.ppsit h2', { button: 'right' });
    await p.waitForTimeout(200); console.log(T, 'dialog:', await E(() => [$('#ppsh')?.textContent, $('#ppsr')?.value, $('#ppsw')?.value]));
    if (!touch) await p.screenshot({ path: '/tmp/sit_dialog.png' });
    await p.fill('#ppsr', '7'); await p.fill('#ppsw', '120'); await p.click('[data-act="pp-sit-save"]'); await p.waitForTimeout(300);
    console.log(T, 'after:', await E(() => $('.ppsit p')?.textContent), await E(() => document.querySelector('#toast')?.textContent));
    await p.click('[data-act="sit-paper"]'); await p.waitForTimeout(400); console.log(T, 'started:', await E(() => [view.name, exS?.read, exS?.work]));
    await E(() => { exFinish(true); }); await p.waitForTimeout(300); await p.click('text=Done').catch(() => {});
    await E(() => go('papers')); await p.waitForTimeout(600); await p.click('#abr [data-nav="exam"]'); await p.waitForTimeout(300); console.log(T, 'Exam timer button ->', await E(() => [view.name, exOn()]));
    console.log(T, 'errors:', errs.length ? errs : 'none'); await ctx.close();
  }
  await b.close(); srv.close();
})();
