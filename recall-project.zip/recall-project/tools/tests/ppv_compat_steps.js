// a question marked whole before parts were split keeps its whole box and mark; unmarked ones split
module.exports = async (p, E) => {
  const pid = await E(() => ppm.pid);
  await E(pid => { const p0 = ppPapers()[pid]; S.settings = { ...S.settings, papers: { ...ppPapers(), [pid]: { ...p0, q: { '17': { r: 'part', got: 4, of: 8, card: null } } } } }; ppm = null; go('papers'); setTimeout(() => go('ppmark', pid), 50); }, pid);
  await p.waitForFunction(() => ppm?.items?.length > 0 && !ppm.busy, null, { timeout: 60000 });
  console.log(await E(() => ppm.items.filter(it => /Q1[678]/.test(it.label)).map(it => it.label + '[' + it.marks + ']').join(' ')));
  console.log('score', await E(() => JSON.stringify(ppScore(ppmP()))));
};
