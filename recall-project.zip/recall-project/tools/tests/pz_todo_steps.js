module.exports = async (p, E, shot) => {
  await E(() => { const t = Date.now(), maths = kids(null).find(n => n.name === 'Maths')?.id, phy = kids(null).find(n => n.name === 'Physics')?.id;
    const L = [['Complex Topic Test from Edwin, put hard questions in decks', maths, 45], ['5.1 Pro Ed', phy, 45], ['-', null], ['At School:', null], ['Vranesavic Questions + Physics Worksheets in Lochen class', maths], ['-', maths], ['Proofs 3 Booklet Hard questions - put in decks', maths], ['Physics module 6 notes', phy, 30]];
    S.settings = { ...S.settings, todos: L.map(([tx, s, m], i) => ({ id: 't' + i, t: tx, s, done: 0, at: t + i, l: 'today', ...(m ? { m } : {}) })) }; todoTab = 'today'; go('decks'); });
  await p.waitForTimeout(800); await E(() => document.querySelector('[data-act="todo-f"][data-v="all"]').click()); await p.waitForTimeout(200);
  const rows = () => E(() => [...document.querySelectorAll('#tdo .tdr')].map(r => (r.classList.contains('tdh') ? 'H:' : r.classList.contains('tdgap') ? '[gap]' : '') + (r.querySelector('.tdtx')?.textContent || '') + (r.querySelector('.tdhm') ? ' (' + r.querySelector('.tdhm').textContent + ')' : '')).join(' | ') + '  || cap: ' + $('.tdoc').innerText);
  // convert "-" (t2) to gap and "At School:" (t3) to heading via the menu
  await E(() => todoMoveMenu('t2', document.querySelector('[data-tid="t2"] .tdmove'))); await p.click('[data-act="todo-kind"][data-k="gap"]');
  await E(() => todoMoveMenu('t3', document.querySelector('[data-tid="t3"] .tdmove'))); await p.click('[data-act="todo-kind"][data-k="h"]');
  await E(() => todoMoveMenu('t5', document.querySelector('[data-tid="t5"] .tdmove'))); await p.click('[data-act="todo-kind"][data-k="gap"]');
  await p.waitForTimeout(300); console.log('converted', await rows());
  // heading mode add
  await p.click('[data-act="todo-hmode"]'); await p.waitForTimeout(150); await p.fill('#tdoin', 'After school at the library:'); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  console.log('after heading add', await rows(), await E(() => [todoNewKind, document.activeElement?.id, $('#tdoin').placeholder]));
  await p.fill('#tdoin', 'Ext 2 past paper'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  await p.click('[data-act="todo-gap"]'); await p.waitForTimeout(300);
  console.log('add task+gap', await rows());
  await p.evaluate(() => document.querySelector('#tdo').scrollIntoView()); await p.waitForTimeout(300);
  await (await p.$('#tdo')).screenshot({ path: 'pz_td_list.png' });
  // filter by Physics
  await E(() => { const phy = kids(null).find(n => n.name === 'Physics').id; document.querySelector(`[data-act="todo-f"][data-v="${phy}"]`).click(); }); await p.waitForTimeout(300);
  console.log('physics filter', await rows());
  await E(() => document.querySelector('[data-act="todo-f"][data-v="all"]').click());
  // drag the heading to the top
  const h = await p.$('.tdr.tdh'), top = await p.$('#tdo .tdr'); const hb = await h.boundingBox(), tb = await top.boundingBox();
  await p.mouse.move(hb.x + 200, hb.y + hb.height / 2); await p.mouse.down(); await p.mouse.move(hb.x + 200, hb.y - 20, { steps: 4 }); await p.mouse.move(hb.x + 200, tb.y + 4, { steps: 8 }); await p.mouse.up(); await p.waitForTimeout(400);
  console.log('dragged', await rows());
  // rename heading
  await p.click('.tdr.tdh .tdt'); await p.waitForTimeout(100); await p.fill('.tdedit', 'At school'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('renamed', await rows());
  // turn heading back into task, delete gap, undo
  await E(() => todoMoveMenu('t3', document.querySelector('[data-tid="t3"] .tdmove'))); console.log('heading menu', await E(() => $('#menu').innerText.replace(/\n/g, ' | ')));
  await p.keyboard.press('Escape');
  await E(() => document.querySelector('.tdr.tdgap .tddel').click()); await p.waitForTimeout(200); console.log('gap del', await E(() => $('#toast').innerText));
  await (await p.$('#tdo')).screenshot({ path: 'pz_td_list2.png' });
};
