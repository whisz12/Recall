// typed exam times + hiding the paper bar (10 Nov 2026)
module.exports = async (p, E, shot) => {
  const vis = s => E(s => { const el = document.querySelector(s); if (!el) return 'none'; const r = el.getBoundingClientRect(); return getComputedStyle(el).display !== 'none' && r.width > 0 ? `${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)}` : 'hidden'; }, s);
  const draft = () => E(() => [$('#pptmh')?.value, $('#pptmm')?.value, $('#pptmr')?.value, JSON.stringify(ppTmDraft), $('#tpop .pptmgo')?.disabled]);
  await p.click('#pptm'); await p.waitForTimeout(300); await shot('pop');
  console.log('pop', await E(() => $('#tpop').innerText.replace(/\n+/g, ' | ')), await draft());
  // type 2 h 37 min writing, 7 min reading
  await p.click('#pptmh'); await p.keyboard.type('2'); await p.click('#pptmm'); await p.keyboard.type('37'); await p.click('#pptmr'); await p.keyboard.type('7');
  console.log('typed', await draft());
  // keys typed into the fields must not reach the paper (t, f, h, . would)
  await p.click('#pptmm'); await p.keyboard.type('f'); console.log('typed f', await draft(), await E(() => [ppFull, ppSides, ppBar]));
  await p.click('#pptmm'); await p.keyboard.type('37');
  await p.click('[data-act="pp-tm-step"][data-d="5"]'); console.log('+5 snaps', await draft());
  await p.click('[data-act="pp-tm-step"][data-d="-5"]'); await p.click('[data-act="pp-tm-step"][data-d="-5"]'); console.log('-5 -5', await draft());
  await p.click('[data-act="pp-tm-rstep"][data-d="1"]'); console.log('read +1', await draft());
  // 90 minutes typed into the minutes box tidies to 1 h 30 on leaving it
  await p.click('#pptmh'); console.log('h focus', await draft(), await E(() => [document.activeElement.id, $('#pptmh').selectionStart, $('#pptmh').selectionEnd])); await p.keyboard.type('0'); console.log('h0', await draft()); await p.click('#pptmm'); console.log('m focus', await E(() => [document.activeElement.id, $('#pptmm').selectionStart, $('#pptmm').selectionEnd])); await p.keyboard.type('90'); console.log('m90', await draft()); await p.click('#pptmr'); console.log('90 min tidied', await draft());
  await p.click('#pptmh'); await p.keyboard.type('0'); await p.click('#pptmm'); await p.keyboard.type('0'); await p.click('#pptmr'); console.log('zero → start disabled', await draft());
  await p.click('#pptmm'); await p.keyboard.type('48'); await p.click('#pptmr'); await p.keyboard.type('3'); await p.keyboard.press('Enter'); await p.waitForTimeout(400);
  console.log('enter starts', await E(() => [!!$('#tpop'), JSON.stringify(Object.values(JSON.parse(localStorage.getItem('md-pp-tm'))).map(t => [t.dur / 60000, t.read / 60000])), $('#toast').innerText, localStorage.getItem('md-pp-tmdef')]));
  await p.waitForTimeout(1100); console.log('bar', await E(() => $('#pptm').innerText));
  // hide the bar
  console.log('before hide', await vis('#ppzbar'), await vis('#ppzshow'));
  await p.click('#ppzbar [data-act="pp-bar"]'); await p.waitForTimeout(300); await shot('nobar');
  console.log('hidden', await vis('#ppzbar'), await vis('#ppzshow'), await E(() => [localStorage.getItem('md-pp-bar'), $('#toast').innerText]));
  await p.keyboard.press('t'); await p.waitForTimeout(300); console.log('T pauses while hidden', await E(() => JSON.parse(localStorage.getItem('md-pp-tm'))[Object.keys(JSON.parse(localStorage.getItem('md-pp-tm')))[0]].pa > 0));
  await p.keyboard.press('t'); await p.waitForTimeout(200);
  // full screen while hidden
  await p.keyboard.press('f'); await p.waitForTimeout(500); await shot('nobar_full');
  console.log('full hidden', await vis('#ppzbar'), await vis('#ppzshow'));
  await p.keyboard.press('.'); await p.waitForTimeout(300); console.log('. shows', await vis('#ppzbar'), await vis('#ppzshow'));
  await p.keyboard.press('.'); await p.waitForTimeout(300); console.log('. hides', await vis('#ppzbar'), await vis('#ppzshow'));
  await p.keyboard.press('Escape'); await p.waitForTimeout(400);
  // remembered on the next paper open
  await E(() => { const id = view.node; go('papers'); setTimeout(() => go('ppmark', id), 200); }); await p.waitForTimeout(2500);
  console.log('reopen', await vis('#ppzbar'), await vis('#ppzshow'));
  await p.click('#ppzshow'); await p.waitForTimeout(300); console.log('handle shows', await vis('#ppzbar'), await vis('#ppzshow'), await E(() => localStorage.getItem('md-pp-bar')));
  await shot('back');
  // running timer popover still works
  await p.click('#pptm'); await p.waitForTimeout(300); console.log('running pop', await E(() => $('#tpop').innerText.replace(/\n+/g, ' | ')));
};
