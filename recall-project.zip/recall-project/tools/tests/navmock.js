// Mock-ups of where the back/forward buttons could go. node navmock.js
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  const L = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M10 3.5 5.5 8l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const R = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3.5 10.5 8 6 12.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const btns = cls => `<button class="ncb ${cls}" data-act="hist-back" title="Back">${L}</button><button class="ncb ${cls}" data-act="hist-fwd" title="Forward" disabled>${R}</button>`;
  const variants = {
    A: { css: 'body.desktop.sidebar-hidden .appbar{padding-left:190px !important}', apply: `$('#navcl').insertAdjacentHTML('beforeend', ${JSON.stringify(btns(''))});` },
    B: { css: `.mknav{display:flex;align-items:center;gap:2px;margin-right:10px;padding-right:12px;border-right:1px solid var(--border-2)} body.desktop.sidebar-hidden .appbar{padding-left:128px !important}`, apply: `$('#abt').insertAdjacentHTML('afterbegin', '<span class="mknav">' + ${JSON.stringify(btns(''))} + '</span>');` },
    C: { css: `.mkpill{display:inline-flex;border:1px solid var(--border-2);border-radius:7px;overflow:hidden;margin-right:12px;flex:none} .mkpill .ncb{border-radius:0;width:30px;height:26px} .mkpill .ncb+.ncb{border-left:1px solid var(--border-2)} body.desktop.sidebar-hidden .appbar{padding-left:128px !important}`, apply: `$('#abt').insertAdjacentHTML('afterbegin', '<span class="mkpill">' + ${JSON.stringify(btns(''))} + '</span>');` },
    D: { css: `#navcl.mkgrp{gap:0;border:1px solid var(--border-2);border-radius:8px;padding:1px;background:var(--side-solid)} #navcl.mkgrp .ncb{width:28px;height:26px} #navcl.mkgrp .mksep{width:1px;height:16px;background:var(--border-2);margin:0 3px} body.desktop.sidebar-hidden .appbar{padding-left:196px !important}`, apply: `$('#navcl').classList.add('mkgrp'); $('#navcl').insertAdjacentHTML('beforeend', '<span class="mksep"></span>' + ${JSON.stringify(btns(''))});` },
  };
  for (const [k, v] of Object.entries(variants)){
    for (const hidden of [false, true]){
      const ctx = await b.newContext({ viewport: { width: 1400, height: 900 }, deviceScaleFactor: 2, colorScheme: 'dark' }); const p = await ctx.newPage();
      await p.addInitScript(lib => { const db = JSON.parse(lib); window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.27.0', build: '20261102003633', updated: false }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async () => true, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, lib);
      await p.goto('file://' + path.resolve(__dirname, '../../app/app/index.html')); await p.waitForTimeout(1300);
      await p.evaluate(([css, apply, hidden]) => {
        const s = kids(null)[0], t = kids(s.id)[0], u = kids(t.id)[0] || t; go('overview', s.id); go('overview', u.id);
        if (hidden && !document.body.classList.contains('sidebar-hidden')) document.querySelector('[data-act="toggle-sidebar"]').click();
        const st = document.createElement('style'); st.textContent = css + ' body.desktop .navcl{left:84px !important;top:12px !important} .mktl{position:fixed;top:17px;left:20px;display:flex;gap:8px;z-index:99} .mktl i{width:12px;height:12px;border-radius:50%;display:block}'; document.head.append(st);
        document.body.insertAdjacentHTML('beforeend', '<span class="mktl"><i style="background:#ff5f57"></i><i style="background:#febc2e"></i><i style="background:#28c840"></i></span>');
        new Function(apply)();
      }, [v.css, v.apply, hidden]);
      await p.waitForTimeout(500);
      await p.screenshot({ path: `/tmp/navmock_${k}_${hidden ? 'h' : 's'}.png`, clip: { x: 0, y: 0, width: 760, height: 150 } });
      await ctx.close();
    }
  }
  await b.close();
})();
