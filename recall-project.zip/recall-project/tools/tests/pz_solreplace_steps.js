const fs = require('fs');
module.exports = async (p, E, shot) => {
  const log = (...a) => console.log(...a);
  const rd = n => [...fs.readFileSync(__dirname + '/' + n)];
  const [pp, sa, sb] = ['paper.pdf', 'sol_a.pdf', 'sol_b.pdf'].map(rd);
  await E(() => go('papers')); await p.waitForTimeout(500);
  const pid = await E(async ([pp, sa]) => {
    const item = { src: 'up', c: ppCourseCur(), sec: 'trial', school: 'Test High', year: 2024, key: null };
    await ppAddPdf(item, new File([new Uint8Array(pp)], 'Test 2024.pdf', { type: 'application/pdf' }), { open: false, solFile: new File([new Uint8Array(sa)], 'sol_a.pdf', { type: 'application/pdf' }) });
    return Object.values(ppPapers()).find(x => x.school === 'Test High').id;
  }, [pp, sa]);
  await p.waitForTimeout(500);
  const info = () => E(pid => ({ p: (({ solSep, solName, sol, solFile }) => ({ solSep, solName, sol, solFile: !!solFile }))(ppPapers()[pid] || {}), view: view.name }), pid);
  log('added', JSON.stringify(await info()), 'stored', await E(async pid => (await ppGetPdf(ppSolKey(pid)))?.name, pid));
  // open the menu on the papers list and replace via the real button + file chooser
  await E(() => renderPapers()); await p.waitForTimeout(300);
  const key = await E(pid => ppPapers()[pid].key || 'p:' + pid, pid);
  log('key', key, 'item?', await E(k => !!ppItemOf(k), key), 'cards with data-k', await E(() => document.querySelectorAll('#root [data-k]').length));
  await E(k => { const el = document.querySelector(`#root [data-k="${CSS.escape(k)}"]`); const r = el?.getBoundingClientRect(); ppMenu(k, { x: (r?.left || 100) + 10, y: (r?.top || 100) + 10 }); }, key); await p.waitForTimeout(250);
  log('menu', await E(() => $('#menu')?.innerText.replace(/\n/g, ' / ')));
  const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }).catch(e => null), p.click('#menu [data-act="pp-m-addsol"]')]);
  log('file chooser opened', !!fc);
  if (fc){ await fc.setFiles({ name: 'sol_b.pdf', mimeType: 'application/pdf', buffer: Buffer.from(sb) }); await p.waitForTimeout(1500); }
  log('after replace', JSON.stringify(await info()), 'stored', await E(async pid => (await ppGetPdf(ppSolKey(pid)))?.name, pid), '| toast', await E(() => $('#toast').hidden ? null : $('#toast').innerText));
  // open marking: solutions pages should be version B (3 pages)
  await E(pid => go('ppmark', pid), pid); await p.waitForTimeout(500);
  await p.waitForFunction(() => ppm && !ppm.busy && ppm.R, null, { timeout: 30000 }).catch(() => {});
  log('marking', JSON.stringify(await E(() => ({ solFrom: ppm.solFrom, pages: ppm.R?.pages.length, missing: ppm.solMissing, solTxt: (ppm.R?.pages.find(x => x.sol)?.lines || []).map(l => l.t || l.text || '').join(' ').slice(0, 60) }))));
  log('note', await E(() => $('.ppsolln')?.innerText || ''), '| side buttons', await E(() => [...document.querySelectorAll('#ppm [data-act*="sol"], .ppside [data-act*="sol"]')].map(b => b.dataset.act + ':' + b.innerText.trim()).join(', ')));
  await shot('mark');
  // replace again from the marking page (right-click menu / addsol)
  const [fc2] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }).catch(() => null), E(() => ppAddSolPick(ppm.pid))]);
  log('fc2', !!fc2); if (fc2){ await fc2.setFiles({ name: 'sol_a.pdf', mimeType: 'application/pdf', buffer: Buffer.from(sa) }); await p.waitForTimeout(800); }
  await p.waitForFunction(() => ppm && !ppm.busy && ppm.R, null, { timeout: 30000 }).catch(() => {});
  log('marking 2', JSON.stringify(await E(() => ({ solFrom: ppm?.solFrom, pages: ppm?.R?.pages.length, view: view.name }))), JSON.stringify(await info()));
  // the link on the marking page shows Replace and Delete
  log('sol line', await E(() => $('.ppsolln')?.innerText));
  // hand-placed solutions are cleared by a replace; solAt stamped
  log('stamp', await E(pid => [!!ppPapers()[pid].solAt, ppPapers()[pid].msol === undefined], pid));
  // OCR cache: stale solutions-page text is dropped when solAt changes, paper pages are kept
  log('ocr cache', await E(async pid => {
    const R = { pages: [{ n: 1, sol: false, lines: [] }, { n: 4, sol: true, lines: [] }] };
    await ppPutPdf(ppOcrKey(pid), JSON.stringify({ 1: [{ text: 'paper' }], 4: [{ text: 'OLD answer' }], _sol: 1 }), 'ocr');
    const c = JSON.parse((await ppGetPdf(ppOcrKey(pid))).buf); const sa = ppPapers()[pid]?.solAt || 0;
    if ((c._sol || 0) !== sa){ for (const pg of R.pages) if (pg.sol) delete c[pg.n]; }
    return JSON.stringify(Object.keys(c));
  }, pid));
  // delete from the marking page, then undo
  await p.click('[data-act="pp-solmenu"]'); await p.waitForTimeout(250); log('sol menu', await E(() => $('#menu')?.innerText.replace(/\n/g, ' / '))); await shot('solmenu');
  await p.click('#menu [data-act="pp-delsol"]'); await p.waitForTimeout(250); log('confirm', await E(() => $('#ppsdh')?.innerText));
  await p.click('[data-act="pp-delsolgo"]'); await p.waitForTimeout(1500);
  await p.waitForFunction(() => ppm && !ppm.busy && ppm.R, null, { timeout: 30000 }).catch(() => {});
  log('deleted', JSON.stringify(await info()), JSON.stringify(await E(() => ({ solFrom: ppm.solFrom, pages: ppm.R.pages.length, line: $('.ppsolln')?.innerText }))), '|', await E(() => $('#toast').innerText.replace(/\n/g, ' ')));
  await p.click('#toast .toastundo'); await p.waitForTimeout(500); await E(() => { ppm = null; renderPPMark(); });
  await p.waitForFunction(() => ppm && !ppm.busy && ppm.R, null, { timeout: 30000 }).catch(() => {});
  log('undo', JSON.stringify(await info()), JSON.stringify(await E(() => ({ solFrom: ppm.solFrom, pages: ppm.R.pages.length }))));
  // delete from the papers list menu
  await E(() => go('papers')); await p.waitForTimeout(400);
  await E(k => ppMenu(k, { x: 300, y: 300 }), key); await p.waitForTimeout(200); log('menu', await E(() => $('#menu').innerText.replace(/\n/g, ' / ')));
  await p.click('#menu [data-act="pp-m-delsol"]'); await p.waitForTimeout(250); await p.click('[data-act="pp-delsolgo"]'); await p.waitForTimeout(500);
  log('deleted from list', JSON.stringify(await info()));
  await E(k => ppMenu(k, { x: 300, y: 300 }), key); await p.waitForTimeout(200); log('menu after', await E(() => $('#menu').innerText.replace(/\n/g, ' / ')));
  await p.keyboard.press('Escape');
  // re-add a solutions PDF, then pretend another device holds the old copy (older stamp): with no cloud it falls back to that copy
  await E(async ([pid, sb]) => { const q = await ppSolStore(ppPapers()[pid], new File([new Uint8Array(sb)], 'sol_b.pdf', { type: 'application/pdf' })); await ppSavePaper(q); }, [pid, sb]);
  log('stale local', await E(async pid => { await ppPutPdf(ppSolKey(pid), new ArrayBuffer(8), 'old.pdf', 123); return (await ppSolOf(ppPapers()[pid]))?.name; }, pid));
};
