module.exports = async (p, E, shot) => {
  await E(() => { S.settings = { ...S.settings, todos: [{ id: 'a1', t: 'Maths assignment draft', s: null, done: 0, at: 1, l: 'today' }] }; todoTab = 'today'; go('todo'); });
  await p.waitForTimeout(500);
  const tabs = () => E(() => [...document.querySelectorAll('#tdo .tdtabs > *')].map(b => (b.tagName === 'INPUT' ? '[' + (b.value || b.placeholder) + ']' : b.classList.contains('tdtabadd') ? '+' : b.innerText.replace(/\n/g, ' ')) + (b.getAttribute('aria-selected') === 'true' ? '*' : '')).join(' | '));
  console.log('start', await tabs());
  await p.click('.tdtabadd'); await p.waitForTimeout(150); console.log('input focused', await E(() => document.activeElement.classList.contains('tdtabin')));
  await p.keyboard.type('Assignments'); await shot('typing'); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  console.log('after add', await tabs(), '| focus', await E(() => document.activeElement.id), '| lists', await E(() => JSON.stringify(S.settings.todoLists)));
  await p.keyboard.type('Physics depth study'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('task in list', await E(() => JSON.stringify(todoAll().find(x => x.t === 'Physics depth study')?.l === todoTab)), await tabs());
  await shot('list');
  // move a Today task into it through the ⋯ menu
  await p.click('[data-act="todo-tab"][data-v="today"]'); await p.waitForTimeout(150);
  await p.hover('[data-tid="a1"] .tdt'); await p.click('[data-tid="a1"] .tdmore2'); await p.waitForTimeout(150);
  console.log('move menu', await E(() => $('#menu').innerText.split('\n').slice(0, 7).join(' / ')));
  await p.locator('#menu [data-act="todo-moveto"]').last().click(); await p.waitForTimeout(200); console.log('moved', await tabs());
  // blur with empty name cancels
  await p.click('.tdtabadd'); await p.waitForTimeout(100); await p.click('.tdpage h1'); await p.waitForTimeout(200); console.log('empty cancel', await tabs());
  // rename: click the open custom tab
  const id = await E(() => S.settings.todoLists[0].id);
  await p.click(`[data-act="todo-tab"][data-v="${id}"]`); await p.waitForTimeout(100); await p.click(`[data-act="todo-tab"][data-v="${id}"]`); await p.waitForTimeout(150);
  console.log('tab menu', await E(() => $('#menu')?.innerText.replace(/\n/g, ' / '))); await shot('menu');
  await p.click('#menu [data-act="todo-tabren"]'); await p.waitForTimeout(150); await p.keyboard.type('Assessments'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('renamed', await tabs());
  // right-click → delete, then undo
  await p.click(`[data-act="todo-tab"][data-v="${id}"]`, { button: 'right' }); await p.waitForTimeout(150);
  await p.click('#menu [data-act="todo-tabdel"]'); await p.waitForTimeout(250);
  console.log('deleted', await tabs(), '| tasks left', await E(() => todoAll().length));
  await p.keyboard.press('Meta+z'); await p.waitForTimeout(300);
  console.log('undo', await tabs(), '| tasks', await E(() => todoAll().length));
  // decks page shows it too
  await E(() => go('decks')); await p.waitForTimeout(400); console.log('decks', await tabs());
  await shot('decks');
};
