// scanned paper: OCR runs once, questions found; reopening uses the saved reading
module.exports = async (p, E, shot) => {
  await p.waitForTimeout(500);
  console.log(JSON.stringify(await E(() => ({ n: ppm.items.length, ocrd: !!ppm.R.ocrd, labels: ppm.items.map(it => it.label + '[' + it.marks + ']').join(' ') }))));
  const pick = (process.env.PICK || '').split(',').filter(Boolean);
  for (const lab of pick){ const i = await E(l => ppm.items.findIndex(it => it.label === l), lab); if (i < 0){ console.log('no', lab); continue; } await E(i => ppmPick(i), i); await p.waitForTimeout(900); await shot('pick_' + lab.replace(/[^\w]/g, '')); }
  const t0 = Date.now(); const pid = await E(() => ppm.pid);
  await E(pid => { ppm = null; go('papers'); setTimeout(() => go('ppmark', pid), 50); }, pid);
  await p.waitForFunction(() => ppm?.items?.length > 0 && !ppm.busy, null, { timeout: 60000 });
  console.log('reopen', ((Date.now() - t0) / 1000).toFixed(1) + 's', await E(() => ppm.items.length));
};
