module.exports = async (p, E, shot) => {
  const M = !!process.env.MOBILE, log = (...a) => console.log(...a);
  // one card with a hint, one with only a mistake note, one with neither
  const subj = await E(() => kids(null)[0].id);
  const ids = await E(async s => { const cs = cardsIn(s).slice(0, 3); await put('cards', { ...cs[0], hint: 'Think about the domain of $f^{-1}$', mistake: 'x' }); await put('cards', { ...cs[1], hint: undefined, mistake: 'Forgot to swap the limits' }); const y = { ...cs[2], mistake: '' }; delete y.hint; await put('cards', y); return cs.map(c => c.id); }, subj);
  const open = async id => { await E(([s, id]) => { startStudy(s, true); study.queue = [id, ...study.queue.filter(x => x !== id)]; nextCard(); renderStudy(); }, [subj, id]); await p.waitForTimeout(500); };
  const hint = () => E(() => $('#qhint').innerText.replace(/\n+/g, ' | '));
  await open(ids[0]);
  log('buttons', await E(() => ({ dock: !!$('#lhdock [data-act="study-hint"]'), label: !!$('.qa .qflag'), bar: !!$('#appbar [data-act="study-flag"]'), dockW: Math.round($('#lhdock .dock').scrollWidth - $('#lhdock .dock').clientWidth) })));
  await p.click('#lhdock [data-act="study-hint"]'); await p.waitForTimeout(300); log('own hint', await hint(), '| pressed', await E(() => $('#lhdock [data-act="study-hint"]').getAttribute('aria-pressed'))); await shot('hint');
  await p.click('#lhdock [data-act="study-hint"]'); await p.waitForTimeout(200); log('toggled off', JSON.stringify(await hint()));
  if (!M){ await p.keyboard.press('h'); await p.waitForTimeout(200); log('H key', await hint()); }
  // flag
  await p.click('.qa .qflag'); await p.waitForTimeout(300); log('flag', await E(id => [S.cards[id].flag, $('.qa .qflag').innerText.trim(), $('#appbar .sflag')?.getAttribute('aria-pressed')], ids[0]), '|', await E(() => $('#toast').innerText)); await shot('flagged');
  if (!M){ await p.keyboard.press('f'); await p.waitForTimeout(250); log('F key off', await E(id => [S.cards[id].flag, $('.qa .qflag').innerText.trim()], ids[0])); await p.click('#appbar [data-act="study-flag"]'); await p.waitForTimeout(250); log('toolbar on', await E(id => S.cards[id].flag, ids[0])); }
  // answer shown: hint stays, H does nothing, no hint button
  await E(() => showAnswer()); await p.waitForTimeout(500); log('after reveal', await E(() => ({ hintBtn: !!$('#lhdock [data-act="study-hint"]'), flag: $('.qa .qflag').getAttribute('aria-pressed') })));
  // mistake fallback
  await open(ids[1]); log('new card hint closed', JSON.stringify(await hint())); await p.click('#lhdock [data-act="study-hint"]'); await p.waitForTimeout(300); log('fallback', await hint());
  await p.click('[data-act="hint-edit"]'); await p.waitForTimeout(200); await p.keyboard.type('Draw the region first'); await p.click('[data-act="hint-save"]'); await p.waitForTimeout(300); log('wrote', await hint(), '|', await E(id => S.cards[id].hint, ids[1]));
  // nothing: write one on the spot
  await open(ids[2]); await p.click('#lhdock [data-act="study-hint"]'); await p.waitForTimeout(300); log('empty', await hint(), '| focus', await E(() => document.activeElement.id)); await shot('empty');
  await p.keyboard.type('h and f typed here do nothing else'); await p.click('[data-act="hint-save"]'); await p.waitForTimeout(300); log('saved', await hint(), '| flag untouched', await E(id => !!S.cards[id].flag, ids[2]));
  // editor has the field
  await E(id => editor(id), ids[2]); await p.waitForTimeout(600); log('editor field', await E(() => $('#ehint')?.value)); await p.fill('#ehint', 'Edited hint'); await E(() => saveCard()); await p.waitForTimeout(500); log('editor saved', await E(id => S.cards[id].hint, ids[2]));
  // browse
  await E(() => { browse.status = 'flag'; go('browse'); }); await p.waitForTimeout(600);
  log('browse flagged', await E(() => ({ rows: document.querySelectorAll('.brow').length, icon: !!$('.brow .brflag'), opt: [...$('#bstatus, .brsel').options || []].map(o => o.text).join(',') })));
  await shot('browse');
  if (!M){ await p.click('.brow'); await p.waitForTimeout(300); await p.click('#brprev [data-act="card-flag"]'); await p.waitForTimeout(400); log('unflag in browse', await E(id => !!S.cards[id].flag, ids[0]), 'rows', await E(() => document.querySelectorAll('.brow').length)); }
};
