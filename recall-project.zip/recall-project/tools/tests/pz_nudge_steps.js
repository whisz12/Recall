module.exports = async (p, E, shot) => {
  await E(() => { window.desktop.appInfo = async () => ({ shell: '1.28.0' }); localStorage.removeItem('md-rel-later'); ls.set('md-rel', { at: Date.now(), tag: 'v1.29.0', assets: ['Recall-mac.zip', 'Recall-windows.zip'] }); shellNudge(); });
  await p.waitForTimeout(800);
  console.log(await E(() => document.querySelector('#updbar')?.textContent));
  await shot('bar');
};
