const fs = require('fs'); const [id, from, to] = process.argv.slice(2);
const R = JSON.parse(fs.readFileSync(`json/${id}.json`));
for (const p of R.pages){ if (from && (p.n < +from || p.n > +(to || from))) continue; console.log(`--- page ${p.n} (w ${p.w.toFixed(0)} h ${p.h.toFixed(0)} margin ${p.margin.toFixed(0)}) imgs ${p.imgs.length} art ${p.art.length}`);
  for (const l of p.lines) console.log(`${String(l.x.toFixed(0)).padStart(4)} ${String(l.y.toFixed(0)).padStart(4)} h${l.h.toFixed(0).padStart(2)} r${l.r.toFixed(0).padStart(4)} | ${l.text.slice(0, 110)}`); }
