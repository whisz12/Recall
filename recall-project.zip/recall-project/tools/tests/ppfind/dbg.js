const fs = require('fs'); process.env.PLAN = process.env.PLAN || 'plan.js';
const ctx = require('./run.js'); const id = process.argv[2], R = JSON.parse(fs.readFileSync(`json/${id}.json`));
// re-run with a hook: copy of ppPlan's event stage
const src = fs.readFileSync('plan.js', 'utf8').replace("const evQ = cut == null", "globalThis.__ev = ev; globalThis.__cut = cut; globalThis.__col = null; const evQ = cut == null").replace("const Qs = []; let last", "globalThis.__col = col; const Qs = []; let last");
const vm = require('vm'); vm.runInContext(src.replace(/^const /gm, 'var '), ctx);
const r = ctx.ppPlan(R); const pp = +(process.argv[3] || 0);
console.log('cut', ctx.__cut, 'col', ctx.__col);
for (const e of ctx.__ev) if (!pp || e.p <= pp) console.log(e.k.padEnd(6), 'p' + e.p, Math.round(e.y), 'x' + Math.round(e.x || 0), e.q ?? e.v ?? e.name ?? '', e.top ? 'TOP' : '', (e.l?.nt || '').slice(0, 60));
