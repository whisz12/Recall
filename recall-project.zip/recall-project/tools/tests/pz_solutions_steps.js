const fs = require('fs');
module.exports = async (p, E, shot) => {
  const files = ['NSB 2023 Physics Trial.pdf', 'NSB 2023 Physics Trial Solutions.pdf'].map(n => ({ n, b: [...fs.readFileSync(__dirname + '/' + n)] }));
  await E(() => go('papers')); await p.waitForTimeout(500);
  await E(fs => ppImportDialog(fs.map(f => new File([new Uint8Array(f.b)], f.n, { type: 'application/pdf' }))), files);
  await p.waitForTimeout(1500);
  console.log('import rows', await E(() => JSON.stringify(ppImp.map(r => ({ f: r.file.name, solm: r.solm, sol: r.solFile?.name, c: r.c, sec: r.sec, school: r.school, year: r.year })))));
  await (await p.$('.dialog.ppimp')).screenshot({ path: 'pz_sol_import.png' });
  await E(() => { ppImp.forEach(r => { r.school ||= 'North Sydney Boys'; r.year ||= 2023; }); ppImpDraw(); });
  await p.click('[data-act="pp-igo"][data-open="1"]'); await p.waitForTimeout(500);
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(1500);
  const info = () => E(() => ({ solFrom: ppm.solFrom, pages: ppm.R.pages.length, cutP: ppm.cutP, locked: ppm.locked, matched: ppm.items.filter(i => i.sol?.length).length, items: ppm.items.length, div: !!$('.ppsoldiv'), lockedPages: document.querySelectorAll('.pppage.locked').length, locks: document.querySelectorAll('.pplock').length, drawnS1: (() => { const el = document.querySelector(`.pppage[data-p="${ppm.solFrom}"] canvas`); return el ? el.width : null; })(), p: (({ solSep, solName, sol }) => ({ solSep, solName, sol }))(ppmP()), line: $('.ppsolln')?.innerText }));
  console.log('opened', JSON.stringify(await info()));
  await E(() => ppmReveal({ p: ppm.solFrom, y0: 0 })); await p.waitForTimeout(1000); await shot('solpages');
  // start the timer -> locked
  await p.click('#pptm'); await p.click('[data-act="pp-tm-start"]'); await p.waitForTimeout(1300);
  console.log('timer on', JSON.stringify(await info()));
  await E(() => ppmPick(2)); await E(() => { ppm.res = 'bad'; ppmSide(); }); await p.waitForTimeout(200);
  console.log('panel', await E(() => $('.ppsol')?.innerText));
  await E(() => ppmReveal({ p: ppm.solFrom, y0: 0 })); await p.waitForTimeout(800); await shot('locked');
  // time runs out -> opens
  await E(() => { const a = JSON.parse(localStorage.getItem('md-pp-tm')); for (const k in a) a[k].t0 -= 4 * 3600e3; localStorage.setItem('md-pp-tm', JSON.stringify(a)); ppTmTick(); }); await p.waitForTimeout(1500);
  console.log('time up', JSON.stringify(await info()), await E(() => $('.ppsol')?.innerText));
  await p.click('[data-act="pp-solgo"]'); await p.waitForTimeout(900); await shot('open');
};
