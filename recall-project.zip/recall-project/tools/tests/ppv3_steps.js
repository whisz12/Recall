module.exports = async (p, E, shot) => {
  console.log(JSON.stringify(await E(() => ({ n: ppm.items.length, labels: ppm.items.map(it => it.label + '[' + it.marks + ']').join(' ') }))));
  const pg = +(process.env.PG || 0); if (pg) console.log(await E(n => ppm.R.pages[n - 1].lines.map(l => Math.round(l.x) + ' ' + l.text).join('\n'), pg));
  require('fs').writeFileSync('/tmp/ocr_' + (process.env.TAG || 'x') + '.json', JSON.stringify(await E(() => ({ total: ppm.R.total, bodyH: ppm.R.bodyH, textLines: ppm.R.textLines, pages: ppm.R.pages.map(pg => ({ n: pg.n, w: pg.w, h: pg.h, margin: pg.margin, imgs: (pg.imgs || []).map(b => ({ x: b.x, y: b.y, r: b.r, b: b.b })), art: [], lines: pg.lines.map(l => ({ ocr: !!l.ocr, x: l.x, y: l.y, b: l.b, r: l.r, h: l.h, text: l.text, items: l.items.map(i => ({ s: i.s, x: i.x, r: i.r, h: i.h })) })) })) }))));
};
