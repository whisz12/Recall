module.exports = async (p, E, shot) => {
  const log = (...a) => console.log(...a);
  await E(() => { padOpen = true; startStudy(kids(null)[0].id, true); }); await p.waitForTimeout(700);
  const st = () => E(() => { const cv = $('#pad'), r = cv.getBoundingClientRect(), b = cv.parentElement.getBoundingClientRect(); return { z: pad.zoom, lab: $('#padzv').innerText, cssW: Math.round(r.width), boxW: Math.round(b.width), h: pad.h, cw: cv.width, ch: cv.height, mp: +(cv.width * cv.height / 1e6).toFixed(1), sl: Math.round(padHScroller().scrollLeft), out: $('[data-pad="zout"]').disabled, inn: $('[data-pad="zin"]').disabled }; });
  log('start', JSON.stringify(await st()));
  // draw a diagonal at 100%
  const bx = await p.locator('#pad').boundingBox();
  await p.mouse.move(bx.x + 100, bx.y + 60); await p.mouse.down(); await p.mouse.move(bx.x + 300, bx.y + 200, { steps: 8 }); await p.mouse.up(); await p.waitForTimeout(100);
  const p0 = await E(() => pad.strokes[0].pts[0].slice(0, 2).map(v => +v.toFixed(4)));
  await shot('z1');
  await p.click('[data-pad="zin"]'); await p.waitForTimeout(250); log('150', JSON.stringify(await st()));
  await p.click('[data-pad="zin"]'); await p.waitForTimeout(250); log('200', JSON.stringify(await st()));
  // draw while zoomed and scrolled: the point must land under the mouse
  const b2 = await p.locator('.padcv').boundingBox();
  await p.mouse.move(b2.x + 200, b2.y + 150); await p.mouse.down(); await p.mouse.move(b2.x + 260, b2.y + 180, { steps: 5 }); await p.mouse.up(); await p.waitForTimeout(100);
  log('zoomed stroke under pointer', JSON.stringify(await E(([x, y]) => { const r = $('#pad').getBoundingClientRect(), q = pad.strokes[1].pts[0]; return [Math.round(r.left + q[0] * r.width - x), Math.round(r.top + q[1] * r.width - y)]; }, [b2.x + 200, b2.y + 150])), 'first stroke unchanged', JSON.stringify(await E(() => pad.strokes[0].pts[0].slice(0, 2).map(v => +v.toFixed(4)))) === JSON.stringify(p0));
  await shot('z2');
  // ⌘ + scroll zooms around the pointer
  await p.mouse.move(b2.x + 300, b2.y + 200); const before = await E(([x, y]) => { const r = $('#pad').getBoundingClientRect(); return [(x - r.left) / r.width, (y - r.top) / r.width]; }, [b2.x + 300, b2.y + 200]);
  await p.keyboard.down('Meta'); await p.mouse.wheel(0, -40); await p.keyboard.up('Meta'); await p.waitForTimeout(300);
  const after = await E(([x, y]) => { const r = $('#pad').getBoundingClientRect(); return [(x - r.left) / r.width, (y - r.top) / r.width]; }, [b2.x + 300, b2.y + 200]);
  log('wheel', JSON.stringify(await st()), 'anchor drift', before.map((v, i) => +(v - after[i]).toFixed(4)));
  for (let i = 0; i < 3; i++){ await E(() => padAction('zin')); await p.waitForTimeout(200); } log('max', JSON.stringify(await st()));
  // full screen keeps zoom and works
  await p.click('[data-pad="full"]'); await p.waitForTimeout(500); log('full', JSON.stringify(await st())); await shot('full');
  await p.click('[data-pad="zout"]'); await p.waitForTimeout(250); log('full zout', JSON.stringify(await st()));
  await p.click('[data-pad="full"]'); await p.waitForTimeout(500);
  await p.click('[data-pad="z100"]'); await p.waitForTimeout(300); log('reset', JSON.stringify(await st()), 'strokes', await E(() => pad.strokes.length));
  await shot('back');
  // undo still fine
  await p.click('[data-pad="undo"]'); await p.waitForTimeout(150); log('undo', await E(() => pad.strokes.length));
};
