// separate solutions PDF: add it, reopen, see which parts got their solution
module.exports = async (p, E, shot) => {
  const sol = [...require('fs').readFileSync('/home/claude/papers/p01sol.pdf')];
  const pid = await E(() => ppm.pid);
  await E(async ([pid, sol]) => { const f = new File([new Uint8Array(sol)], 'Premiere X2 Solutions.pdf', { type: 'application/pdf' }); const q = await ppSolStore(ppPapers()[pid], f); await ppSavePaper(q, 'add solutions'); ppm = null; go('papers'); setTimeout(() => go('ppmark', pid), 50); }, [pid, sol]);
  await p.waitForFunction(() => ppm?.items?.length > 0 && !ppm.busy, null, { timeout: 120000 });
  console.log(JSON.stringify(await E(() => ({ solFrom: ppm.solFrom, with: ppm.items.filter(it => it.sol).length, of: ppm.items.length, missing: ppm.items.filter(it => !it.sol).map(it => it.label).join(' ') }))));
  const i = await E(() => ppm.items.findIndex(it => it.label === 'Q12(b)(ii)')); await E(i => { ppmPick(i); ppSplitSet(true); }, i); await p.waitForTimeout(1500); await shot('split');
};
