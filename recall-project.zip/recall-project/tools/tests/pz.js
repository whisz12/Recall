// open a paper in the marking screen; WEB=1 MOBILE=1 for the web build. node pz.js W H TAG
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
const R = '/home/claude/w/recall-project', MOBILE = !!process.env.MOBILE, W = +process.argv[2] || 1400, H = +process.argv[3] || 900, TAG = process.argv[4] || 'd';
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext(MOBILE ? { viewport: { width: W, height: H }, hasTouch: true, isMobile: true, deviceScaleFactor: 2, userAgent: 'Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1', acceptDownloads: true } : { viewport: { width: W, height: H }, deviceScaleFactor: 2, acceptDownloads: true });
  const p = await ctx.newPage(); p.setDefaultTimeout(8000);
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/errimg|ERR_|supabase|net::|Failed to load/.test(m.text())) errs.push('console: ' + m.text()); });
  const V = R + '/app/app/vendor/';
  await ctx.route(/raw\.githubusercontent\.com|api\.github\.com/, r => r.fulfill({ status: 404, body: '' }));
  await ctx.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)/, route => { const u = route.request().url(); const m = u.includes('pdf.worker') ? V + 'pdf.worker.min.js' : u.includes('pdf.min') ? V + 'pdf.min.js' : u.includes('supabase') ? V + 'supabase.js' : null; if (m) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(m) }); { const T = '/tmp/tess/'; let f = null; if (u.includes('tesseract.js@5.1.1/dist/')) f = T + 'tesseract.js-5.1.1/package/dist/' + u.split('/dist/')[1]; else if (u.includes('tesseract.js-core@5.1.1')) f = T + 'tesseract.js-core-5.1.1/package/' + u.split('tesseract.js-core@5.1.1/')[1]; else if (u.includes('@tesseract.js-data/eng')) f = T + 'tesseract.js-data-eng-1.0.0/package/' + u.split('eng@1.0.0/')[1]; if (f && fs.existsSync(f)) return route.fulfill({ status: 200, contentType: f.endsWith('.wasm') ? 'application/wasm' : f.endsWith('.gz') ? 'application/gzip' : 'text/javascript', body: fs.readFileSync(f) }); } route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }); });
  const lib = fs.readFileSync(R + '/tools/tests/lib20.json', 'utf8');
  if (process.env.WEB){
    const http = require('http'), root = R + '/web';
    http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); fs.createReadStream(f).pipe(r); }).listen(8772);
    await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
    await p.goto('http://127.0.0.1:8772/'); await p.waitForTimeout(1800);
  } else {
    await p.addInitScript(lib => { const db = JSON.parse(lib); let n = 0; window.__saved = []; window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x' + (n++) + '.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.28.0', build: '1', updated: false }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async (name, bytes) => { window.__saved.push([name, bytes.length]); return '/Users/x/Downloads/' + name; }, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, lib);
    await p.goto('file://' + R + '/app/app/index.html'); await p.waitForTimeout(1300);
  }
  const E = (f, a) => p.evaluate(f, a), shot = n => p.screenshot({ path: `pz_${TAG}_${n}.png` });
  if (process.env.DARK) { await E(() => { undoMute = true; saveTheme({ ...themeSettings(), base: 'harness', mode: 'fixed' }); undoMute = false; render(); }); }
  const bytes = [...fs.readFileSync(__dirname + '/paper.pdf')];
  await E(async bytes => { const f = new File([new Uint8Array(bytes)], 'NSB 2023 Physics Trial.pdf', { type: 'application/pdf' }); await ppAddPdf({ key: null, c: 'phy', sec: 'trial', school: 'North Sydney Boys', year: 2023, sol: false, src: 'up' }, f); }, bytes);
  await p.waitForSelector('#ppm .ppsq', { timeout: 15000 }).catch(async () => { await shot('fail'); console.log(JSON.stringify({ errs, html: (await p.evaluate(() => ($('#pprail')?.innerText || document.body.innerText).slice(0, 600))) })); process.exit(1); }); await p.waitForTimeout(1200);
  await shot('mark');
  const script = process.env.STEPS ? require(path.resolve(process.env.STEPS)) : null;
  if (script) await script(p, E, shot, ctx);
  console.log(JSON.stringify({ errs }, null, 1)); await b.close(); process.exit(0);
})();
