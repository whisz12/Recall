const { app, BrowserWindow, ipcMain, protocol, net, shell, Menu, dialog, nativeTheme, systemPreferences, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

protocol.registerSchemesAsPrivileged([
  { scheme: 'errimg', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } }
]);

// v1.9: the library lives in a visible folder (~/Error Log) instead of the hidden app-support folder.
const OLD_LIB = () => path.join(app.getPath('userData'), 'Library');
// v1.17: the app is now called Recall. Keep the old settings folder, and rename ~/Error Log to ~/Recall once.
app.setName('Recall');
try { app.setPath('userData', path.join(app.getPath('appData'), 'Error Log')); } catch {}
let libDir = null;
const LIB = () => {
  if (libDir) return libDir;
  const home = app.getPath('home'), neu = path.join(home, 'Recall'), old = path.join(home, 'Error Log');
  if (!fs.existsSync(neu) && fs.existsSync(path.join(old, 'data.json'))) { try { fs.renameSync(old, neu); } catch (e) { console.error(e); return libDir = old; } }
  return libDir = neu;
};
const DATA = () => path.join(LIB(), 'data.json');
const IMG = () => path.join(LIB(), 'images');
const SEED = path.join(__dirname, 'seed');

let db = { nodes: {}, cards: {}, settings: { newPerDay: 20 } };

// deck files opened from Finder (double-clicking a .recall file) are handed to the page to import
const pendingFiles = []; let rendererReady = false;
function openDeckFile(p) {
  try {
    const payload = { name: path.basename(p), bytes: fs.readFileSync(p) };
    if (win && rendererReady) win.webContents.send('import-file', payload); else pendingFiles.push(payload);
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  } catch (e) { console.error(e); }
}
app.on('open-file', (e, p) => { e.preventDefault(); openDeckFile(p); });
ipcMain.on('files-ready', () => { rendererReady = true; while (pendingFiles.length && win) win.webContents.send('import-file', pendingFiles.shift()); });
ipcMain.handle('saveFile', async (_e, name, bytes) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), String(name).replace(/[\/]/g, '-')) });
  if (r.canceled || !r.filePath) return null;
  fs.writeFileSync(r.filePath, Buffer.from(bytes)); shell.showItemInFolder(r.filePath); return r.filePath;
});
let saveTimer = null;

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(src)) {
    const s = path.join(src, f), d = path.join(dst, f);
    if (fs.statSync(s).isDirectory()) copyDir(s, d);
    else if (!fs.existsSync(d)) fs.copyFileSync(s, d);
  }
}

function loadLibrary() {
  // Move an existing library from the old hidden location (copy; the old copy is left as a backup).
  try { if (!fs.existsSync(DATA()) && fs.existsSync(path.join(OLD_LIB(), 'data.json'))) copyDir(OLD_LIB(), LIB()); } catch (e) { console.error(e); }
  fs.mkdirSync(IMG(), { recursive: true });
  if (!fs.existsSync(DATA())) {
    // a brand-new library starts empty; cards arrive by signing in to sync or importing a deck
    db.settings.migrations = ['1.3-structure', '1.4-physics', '1.6-m6', '1.7-bubbles', '1.9-eco-t1-cards'];
    fs.writeFileSync(DATA(), JSON.stringify(db));
  }
  try {
    const d = JSON.parse(fs.readFileSync(DATA(), 'utf8'));
    db = { nodes: d.nodes || {}, cards: d.cards || {}, settings: { newPerDay: 20, ...(d.settings || {}) } };
  } catch (e) {
    // Keep the unreadable file aside instead of overwriting it.
    const bad = DATA() + '.unreadable-' + Date.now();
    try { fs.renameSync(DATA(), bad); } catch {}
    dialog.showErrorBox('Recall', 'Your library file could not be read, so it was set aside as ' + path.basename(bad) + ' and a new one was started.');
  }
}

// One-time restructure (v1.3): Physics modules and Economics topics lose their old subtopics;
// Physics Modules 5 & 6 and Economics Topic 1 get Multiple Choice / Short Answer instead.
function migrate() {
  const done = db.settings.migrations || [];
  if (done.includes('1.3-structure')) return;
  const mc = new Set(['ph-m5-03','ph-m5-10','ph-m5-11','ph-m5-22','ph-m5-32','ph-m5-33','ph-m5-34','ec-05','ec-06','ec-09','ec-10']);
  const split = new Set(['ph-m5', 'ph-m6', 'ec-t1']);
  const now = Date.now();
  const descendants = pid => { const out = []; const walk = id => Object.values(db.nodes).filter(n => n.parentId === id).forEach(n => { out.push(n.id); walk(n.id); }); walk(pid); return out; };
  for (const pid of ['ph-m5', 'ph-m6', 'ec-t1', 'ec-t2', 'ec-t3', 'ec-t4']) {
    if (!db.nodes[pid]) continue;
    const gone = new Set(descendants(pid));
    for (const c of Object.values(db.cards)) {
      if (!(gone.has(c.nodeId) || c.nodeId === pid)) continue;
      c.nodeId = split.has(pid) ? (mc.has(c.id) ? pid + '-mc' : pid + '-sa') : pid;
    }
    for (const id of gone) delete db.nodes[id];
    if (split.has(pid)) {
      db.nodes[pid + '-mc'] = { id: pid + '-mc', name: 'Multiple Choice', parentId: pid, order: 0, createdAt: now };
      db.nodes[pid + '-sa'] = { id: pid + '-sa', name: 'Short Answer', parentId: pid, order: 1, createdAt: now };
    }
  }
  db.settings.migrations = [...done, '1.3-structure'];
  writeNow();
}

// v1.4: Physics gets its original subtopics back; Multiple Choice / Short Answer become a
// card property (qtype) shown as two large shortcut decks on each module instead.
function migratePhysics() {
  const done = db.settings.migrations || [];
  if (done.includes('1.4-physics')) return;
  const mc = new Set(['ph-m5-03','ph-m5-10','ph-m5-11','ph-m5-22','ph-m5-32','ph-m5-33','ph-m5-34']);
  const m5 = ['Projectile Motion','Circular Motion','Harder Circular Motion','Introduction to Gravity','Satellites in Orbit','Further Analysis of Gravity','Exam Homework and Exam'];
  const m6 = ['Charged Particles in Fields','The Motor Effect','Electromagnetic Induction','Applications of the Motor Effect'];
  const sec = i => i <= 1 ? 0 : i <= 8 ? 1 : i <= 18 ? 2 : i <= 21 ? 3 : i <= 23 ? 4 : i <= 29 ? 5 : 6;
  const now = Date.now();
  [['ph-m5', m5], ['ph-m6', m6]].forEach(([pid, names]) => {
    if (!db.nodes[pid]) return;
    names.forEach((name, i) => { const id = pid + '-' + i; if (!db.nodes[id]) db.nodes[id] = { id, name, parentId: pid, order: i, createdAt: now }; });
  });
  const typeNodes = { 'ph-m5-mc': 'mc', 'ph-m5-sa': 'sa', 'ph-m6-mc': 'mc', 'ph-m6-sa': 'sa' };
  for (const c of Object.values(db.cards)) {
    let m = /^ph-m5-(\d\d)$/.exec(c.id);
    if (m) { if (['ph-m5', 'ph-m5-mc', 'ph-m5-sa'].includes(c.nodeId)) c.nodeId = 'ph-m5-' + sec(+m[1]); c.qtype = mc.has(c.id) ? 'mc' : 'sa'; continue; }
    if (/^ph-m6-\d\d$/.test(c.id)) { if (['ph-m6', 'ph-m6-mc', 'ph-m6-sa'].includes(c.nodeId)) c.nodeId = 'ph-m6-0'; c.qtype = 'sa'; continue; }
    if (typeNodes[c.nodeId]) { c.qtype = typeNodes[c.nodeId]; c.nodeId = db.nodes[c.nodeId].parentId; }
  }
  for (const id of Object.keys(typeNodes)) delete db.nodes[id];
  db.settings.migrations = [...(db.settings.migrations || []), '1.4-physics'];
  writeNow();
}

// v1.6: Physics Module 6 keeps one subtopic, renamed "Charges in Electric Fields",
// and gains "Charges in Magnetic Fields". Cards in removed subtopics move to the kept one.
function migrateM6() {
  const done = db.settings.migrations || [];
  if (done.includes('1.6-m6')) return;
  if (db.nodes['ph-m6']) {
    const keep = 'ph-m6-0', gone = ['ph-m6-1', 'ph-m6-2', 'ph-m6-3'];
    const now = Date.now();
    if (!db.nodes[keep]) db.nodes[keep] = { id: keep, parentId: 'ph-m6', order: 0, createdAt: now };
    db.nodes[keep].name = 'Charges in Electric Fields';
    for (const c of Object.values(db.cards)) if (gone.includes(c.nodeId)) c.nodeId = keep;
    for (const id of gone) delete db.nodes[id];
    const hasMag = Object.values(db.nodes).some(n => n.parentId === 'ph-m6' && /charges in magnetic fields/i.test(n.name));
    if (!hasMag) db.nodes['ph-m6-4'] = { id: 'ph-m6-4', name: 'Charges in Magnetic Fields', parentId: 'ph-m6', order: 1, createdAt: now };
  }
  db.settings.migrations = [...(db.settings.migrations || []), '1.6-m6'];
  writeNow();
}

// v1.7: question-type bubbles live on each topic (node.types) and are editable.
// Physics modules get Multiple Choice / Short Answer / Calculations (+ Modules 7 and 8);
// every Economics topic gets Multiple Choice / Short Answer (old MC/SA subtopics become bubbles).
function migrateBubbles() {
  const done = db.settings.migrations || [];
  if (done.includes('1.7-bubbles')) return;
  restructureBubbles(db);
  db.settings.migrations = [...(db.settings.migrations || []), '1.7-bubbles'];
  writeNow();
}
function restructureBubbles(d) {
  const NAMES = { mc: 'Multiple Choice', sa: 'Short Answer', calc: 'Calculations' };
  const CALC = new Set(['ph-m5-00','ph-m5-01','ph-m5-04','ph-m5-05','ph-m5-06','ph-m5-07','ph-m5-09','ph-m5-12','ph-m5-13','ph-m5-15','ph-m5-16','ph-m5-17','ph-m5-18','ph-m5-19','ph-m5-24','ph-m5-26','ph-m5-29','ph-m5-30','ph-m6-00','ph-m6-01']);
  const now = Date.now();
  const kidsOf = pid => Object.values(d.nodes).filter(n => n.parentId === pid);
  const below = pid => { const out = new Set([pid]); let grew = true; while (grew) { grew = false; for (const n of Object.values(d.nodes)) if (out.has(n.parentId) && !out.has(n.id)) { out.add(n.id); grew = true; } } return out; };
  const subject = re => Object.values(d.nodes).find(n => !n.parentId && re.test(n.name));
  const ensureTypes = (node, keys) => { const have = node.types || []; node.types = [...have, ...keys.filter(k => !have.some(t => t.k === k)).map(k => ({ k, name: NAMES[k] }))]; };
  const ph = subject(/^physics$/i), ec = subject(/^economics$/i);
  if (ph) {
    const mods = kidsOf(ph.id);
    const order = mods.length ? Math.max(...mods.map(m => m.order ?? 0)) : -1;
    [['ph-m7', 'Module 7 – The Nature of Light', /module 7\b/i, 1], ['ph-m8', 'Module 8 – From the Universe to the Atom', /module 8\b/i, 2]].forEach(([id, name, re, i]) => {
      if (!mods.some(m => re.test(m.name)) && !d.nodes[id]) d.nodes[id] = { id, name, parentId: ph.id, order: order + i, createdAt: now };
    });
    for (const m of kidsOf(ph.id)) ensureTypes(m, ['mc', 'sa', 'calc']);
    for (const c of Object.values(d.cards)) if (CALC.has(c.id)) c.qtype = 'calc';
  }
  if (ec) {
    for (const t of kidsOf(ec.id)) {
      ensureTypes(t, ['mc', 'sa']);
      for (const sub of kidsOf(t.id)) {
        const k = /^multiple choice$/i.test(sub.name.trim()) ? 'mc' : /^short answer$/i.test(sub.name.trim()) ? 'sa' : null;
        if (!k) continue;
        const set = below(sub.id);
        for (const c of Object.values(d.cards)) if (set.has(c.nodeId)) { c.nodeId = t.id; c.qtype = k; }
        t.types = t.types.map(x => x.k === k ? { ...x, ...(sub.color ? { color: sub.color } : {}), ...(sub.emoji ? { emoji: sub.emoji } : {}) } : x);
        for (const id of set) delete d.nodes[id];
      }
    }
  }
}

let ownMtime = 0;
// v1.9: Economics Topic 1 knowledge flashcards, added to the "flashcards" section of Topic 1.
function migrateEcoT1Cards() {
  const done = db.settings.migrations || [];
  if (done.includes('1.9-eco-t1-cards')) return;
  const src = path.join(SEED, 'eco-t1');
  let list = [];
  try { list = JSON.parse(fs.readFileSync(path.join(src, 'cards.json'), 'utf8')); } catch (e) { console.error(e); return; }
  for (const f of fs.readdirSync(src)) if (f.endsWith('.png')) { const d = path.join(IMG(), f); if (!fs.existsSync(d)) fs.copyFileSync(path.join(src, f), d); }
  const now = Date.now();
  const kidsOf = pid => Object.values(db.nodes).filter(n => (n.parentId || null) === pid);
  let eco = Object.values(db.nodes).find(n => !n.parentId && /^economics$/i.test(n.name.trim()));
  if (!eco) { eco = { id: 'economics', name: 'Economics', parentId: null, order: kidsOf(null).length, createdAt: now }; db.nodes[eco.id] = eco; }
  let t1 = kidsOf(eco.id).find(n => /^topic\s*1\b/i.test(n.name.trim())) || db.nodes['ec-t1'];
  if (!t1) { t1 = { id: 'ec-t1', name: 'Topic 1 – The Global Economy', parentId: eco.id, order: 0, createdAt: now }; db.nodes[t1.id] = t1; }
  const FLASH = /flash\s*-?\s*cards?/i;
  const sub = Object.values(db.nodes).find(n => n.parentId === t1.id && FLASH.test(n.name));
  let nodeId = t1.id, qtype = null;
  if (sub) nodeId = sub.id;
  else {
    t1.types = t1.types || [];
    let b = t1.types.find(t => FLASH.test(t.name));
    if (!b) { let k = 'flashcards', i = 2; while (t1.types.some(t => t.k === k)) k = 'flashcards-' + i++; b = { k, name: 'Flashcards' }; t1.types.push(b); }
    qtype = b.k;
  }
  list.forEach((c, i) => {
    const id = 'ec-t1-fc-' + String(i + 1).padStart(2, '0');
    if (db.cards[id]) return;
    const card = { id, nodeId, kind: 'learn', label: c.label, qText: c.q, qImg: null, mistake: '', solText: c.a,
      solImgs: (c.imgs || []).map(f => ({ file: f })), createdAt: now + i, order: 1000 + i, source: 'ECO notes · Topic 1',
      srs: { state: 'new', step: 0, due: 0, ivl: 0, ease: 2.5, reps: 0, lapses: 0, last: 0, intro: 0 } };
    if (qtype) card.qtype = qtype;
    db.cards[id] = card;
  });
  db.settings.migrations = [...(db.settings.migrations || []), '1.9-eco-t1-cards'];
  writeNow();
}

function writeNow() {
  clearTimeout(saveTimer); saveTimer = null;
  const tmp = DATA() + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DATA());
  try { ownMtime = fs.statSync(DATA()).mtimeMs; } catch {}
}
// Reload when data.json is changed by something other than this app (e.g. edited while the app is open).
function watchLibrary() {
  try { ownMtime = fs.statSync(DATA()).mtimeMs; } catch {}
  fs.watchFile(DATA(), { interval: 1000 }, cur => {
    if (!cur.mtimeMs || cur.mtimeMs === ownMtime) return;
    let d; try { d = JSON.parse(fs.readFileSync(DATA(), 'utf8')); } catch { return; }
    ownMtime = cur.mtimeMs;
    db = { nodes: d.nodes || {}, cards: d.cards || {}, settings: { newPerDay: 20, ...(d.settings || {}) } };
    if (win && !win.isDestroyed()) win.webContents.send('library-changed');
  });
}
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { try { writeNow(); } catch (e) { console.error(e); } }, 300);
}
function backup() {
  try {
    const dir = path.join(LIB(), 'backups'); fs.mkdirSync(dir, { recursive: true });
    const stamp = new Date().toISOString().slice(0, 10);
    const f = path.join(dir, `data-${stamp}.json`);
    if (!fs.existsSync(f) && fs.existsSync(DATA())) fs.copyFileSync(DATA(), f);
    const old = fs.readdirSync(dir).filter(x => x.startsWith('data-')).sort();
    while (old.length > 14) fs.unlinkSync(path.join(dir, old.shift()));
  } catch {}
}

ipcMain.handle('load', () => db);
ipcMain.handle('put', (_e, coll, id, doc) => {
  if (!['nodes', 'cards'].includes(coll) || typeof id !== 'string') throw new Error('bad write');
  db[coll][id] = { ...doc, id }; scheduleSave(); return true;
});
ipcMain.handle('del', (_e, coll, id) => {
  if (!['nodes', 'cards'].includes(coll)) throw new Error('bad delete');
  delete db[coll][id]; scheduleSave(); return true;
});
ipcMain.on('appearance', (_e, m, bg, fg) => {
  if (m === 'light' || m === 'dark') nativeTheme.themeSource = m;
  if (process.platform !== 'darwin' && win && /^#[0-9a-f]{6}$/i.test(bg || '')) { try { win.setTitleBarOverlay({ color: bg, symbolColor: /^#[0-9a-f]{6}$/i.test(fg || '') ? fg : (m === 'light' ? '#1d2129' : '#e7e9ef'), height: 36 }); win.setBackgroundColor(bg); } catch {} }
});
ipcMain.handle('settings', (_e, s) => { db.settings = { ...db.settings, ...s }; scheduleSave(); return true; });
ipcMain.handle('saveImage', (_e, buf, ext) => {
  const safeExt = ['webp', 'png', 'jpg', 'jpeg'].includes(ext) ? ext : 'png';
  const file = 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8) + '.' + safeExt;
  fs.writeFileSync(path.join(IMG(), file), Buffer.from(buf));
  return { file };
});
ipcMain.handle('askCamera', async () => {
  if (process.platform !== 'darwin') return true;
  const st = systemPreferences.getMediaAccessStatus('camera');
  if (st === 'granted') return true;
  if (st === 'denied' || st === 'restricted') return false;
  try { return await systemPreferences.askForMediaAccess('camera'); } catch { return false; }
});
ipcMain.handle('hasImage', (_e, file) => fs.existsSync(path.join(IMG(), path.basename(String(file)))));
ipcMain.handle('writeImage', (_e, file, bytes) => { const f = path.join(IMG(), path.basename(String(file))); if (!fs.existsSync(f)) fs.writeFileSync(f, Buffer.from(bytes)); return true; });
ipcMain.handle('readImage', (_e, file) => fs.readFileSync(path.join(IMG(), path.basename(String(file)))));
// iPhone photos (HEIC) can't be decoded by Chromium; macOS's built-in `sips` converts them to PNG.
ipcMain.handle('convertImage', async (_e, buf) => {
  const os = require('os'), { execFile } = require('child_process');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'errlog-'));
  const inp = path.join(dir, 'in.heic'), out = path.join(dir, 'out.png');
  fs.writeFileSync(inp, Buffer.from(buf));
  try {
    await new Promise((res, rej) => execFile('/usr/bin/sips', ['-s', 'format', 'png', inp, '--out', out], err => err ? rej(err) : res()));
    return fs.readFileSync(out);
  } finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch {} }
});
ipcMain.handle('deleteImage', (_e, file) => {
  const f = path.join(IMG(), path.basename(String(file)));
  try { fs.unlinkSync(f); } catch {}
  return true;
});


/* ---------- self-updating: the app's page comes from GitHub, so one upload there updates every Mac and PC ----------
   GitHub has version.json ({ build, minShell }) and desktop.html. A newer page is downloaded into its own folder in
   userData (next to a copy of the bundled fonts/libraries) and used from the next restart. If an update needs a newer
   app shell (new native features), it's skipped and the app says so instead. */
const UPD_BASE = process.env.RECALL_UPDATE_URL || 'https://whisz12.github.io/Recall/';
const BUNDLED = path.join(__dirname, 'app');
const UPD_ROOT = () => path.join(app.getPath('userData'), 'app-updates');
const stampOf = f => { try { const fd = fs.openSync(f, 'r'), b = Buffer.alloc(600); fs.readSync(fd, b, 0, 600, 0); fs.closeSync(fd); const m = b.toString('utf8').match(/recall-build:(\d{14}) min-shell:([\d.]+)/); return m ? { build: m[1], min: m[2] } : null; } catch { return null; } };
const verGE = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++){ if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return true; };
function pagePath(){
  const bundled = path.join(BUNDLED, 'index.html'), b = stampOf(bundled);
  let best = null;
  try { for (const d of fs.readdirSync(UPD_ROOT())){ const f = path.join(UPD_ROOT(), d, 'index.html'), st = stampOf(f);
    if (st && st.build === d && verGE(app.getVersion(), st.min) && (!b || st.build > b.build) && (!best || st.build > best.build)) best = { ...st, f }; } } catch {}
  return best ? best.f : bundled;
}
function cleanUpdates(keep){ try { for (const d of fs.readdirSync(UPD_ROOT())) if (d !== keep) fs.rmSync(path.join(UPD_ROOT(), d), { recursive: true, force: true }); } catch {} }
let loadedPage = null, updReady = null, updBusy = false, updLast = 0;
const updSend = m => win && !win.isDestroyed() && win.webContents.send('update-status', m);
async function checkUpdate(manual){
  if (updBusy) return; updBusy = true; updLast = Date.now();
  try {
    // every request has a time limit: a hung check used to leave updBusy set, which blocked all later checks until a restart
    const tget = async (u, ms) => { const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms); try { return await net.fetch(u, { cache: 'no-store', signal: ac.signal }); } finally { clearTimeout(t); } };
    const r = await tget(UPD_BASE + 'version.json?t=' + Date.now(), 20000); if (!r.ok) throw new Error('GitHub replied ' + r.status);
    const v = await r.json(), build = String(v.build || ''), min = String(v.minShell || '0');
    const have = updReady || stampOf(loadedPage)?.build || '0';
    if (!/^\d{14}$/.test(build) || build <= have){ if (manual) updSend({ state: 'current', build: have }); return; }
    if (!verGE(app.getVersion(), min)){ updSend({ state: 'shell', min, build }); return; }
    const h = await tget(UPD_BASE + 'desktop.html?t=' + Date.now(), 120000); if (!h.ok) throw new Error('GitHub replied ' + h.status);
    const html = await h.text(), m = html.slice(0, 600).match(/recall-build:(\d{14}) min-shell:([\d.]+)/);
    if (!m || m[1] !== build || html.length < 100000 || !/<\/html>\s*$/.test(html)) throw new Error('the download was incomplete, so it was skipped');
    const dir = path.join(UPD_ROOT(), build), tmp = dir + '.part';
    fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    for (const e of fs.readdirSync(BUNDLED)) if (e !== 'index.html') fs.cpSync(path.join(BUNDLED, e), path.join(tmp, e), { recursive: true });
    fs.writeFileSync(path.join(tmp, 'index.html'), html);
    fs.rmSync(dir, { recursive: true, force: true });
    // Windows: antivirus often holds new files for a moment, so a rename can fail with EPERM/EBUSY; wait and retry, then copy
    for (let k = 0; ; k++){ try { fs.renameSync(tmp, dir); break; } catch (e) { if (k >= 4){ fs.cpSync(tmp, dir, { recursive: true }); fs.rmSync(tmp, { recursive: true, force: true }); break; } await new Promise(r => setTimeout(r, 400 * (k + 1))); } }
    updReady = build; updSend({ state: 'ready', build });
  } catch (e) { if (manual) updSend({ state: 'error', msg: String(e?.message || e) }); }
  finally { updBusy = false; }
}
// 1.28: Past papers. THSC only serves its PDFs to its own site, so the app (not the page) fetches one paper when the
// student opens it, the same way THSC's own viewer does: metadata, then the gzip fragments one at a time, then gunzip.
const THSC_API = 'https://www.thsconline.net/api/v1';
ipcMain.handle('paper-fetch', async (_e, no, title) => {
  no = String(no || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 12);
  title = String(title || '').replace(/\(Adv\.\)/g, '__ADV__').replace(/\(Std\.\)/g, '__STD__').replace(/[^A-Za-z0-9._\- ]/g, '').replace(/__ADV__/g, '(Adv.)').replace(/__STD__/g, '(Std.)').slice(0, 160);
  if (!no || !title.trim()) throw new Error('Not a THSC paper');
  const enc = encodeURIComponent, ua = `Recall/${app.getVersion()} (HSC revision app; one paper when a student opens it)`;
  const get = async (url, ms) => {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
    try { const r = await net.fetch(url, { signal: ac.signal, cache: 'no-cache', headers: { 'User-Agent': ua } }); if (!r.ok) throw new Error('THSC replied ' + r.status); return r; }
    finally { clearTimeout(t); }
  };
  const meta = await (await get(`${THSC_API}/getmetadata/${enc(no)}/${enc(title)}`, 30000)).json();
  if (meta?.error) throw new Error(String(meta.error));
  const n = Number(meta?.fragmentCount); if (!Number.isSafeInteger(n) || n < 1 || n > 200) throw new Error('THSC sent an odd reply');
  const parts = [];
  for (let i = 0; i < n; i++) parts.push(Buffer.from(await (await get(`${THSC_API}/getfragment/${enc(no)}/${enc(title)}/${i}`, 120000)).arrayBuffer()));
  const pdf = require('zlib').gunzipSync(Buffer.concat(parts));
  if (pdf.subarray(0, 5).toString('latin1') !== '%PDF-') throw new Error('THSC didn’t send a PDF');
  let name = String(meta.originalFileName || title + '.pdf').split(/[\\/]/).pop(); if (!/\.pdf$/i.test(name)) name = name.replace(/\.gz$/i, '').replace(/\.[^.]+$/, '') + '.pdf';
  return { name, bytes: new Uint8Array(pdf.buffer, pdf.byteOffset, pdf.byteLength) };
});
// 1.29: NESA HSC papers. nsw.gov.au sends no CORS header, so the page can't read NESA's exam pages or PDFs itself.
// The app fetches them for it, only from NESA's HSC exam paper pages and its PDF files, one request per call.
// 1.30: older exam packs (2001 onwards) can still point at NESA's previous sites, so their PDFs are allowed too
const NESA_OLD = /^(www\.)?(educationstandards\.nsw\.edu\.au|boardofstudies\.nsw\.edu\.au|arc\.nesa\.nsw\.edu\.au)$/;
const NESA_OK = u => { try { const x = new URL(u); return (x.protocol === 'https:' && (x.hostname === 'www.nsw.gov.au' || x.hostname === 'nsw.gov.au') && (x.pathname.startsWith('/education-and-training/nesa/curriculum/hsc-exam-papers/') || /^\/sites\/default\/files\/[^?#]+\.pdf$/i.test(x.pathname))) || (/^https?:$/.test(x.protocol) && NESA_OLD.test(x.hostname) && /\.pdf$/i.test(x.pathname)); } catch { return false; } };
ipcMain.handle('nesa-get', async (_e, url) => {
  url = String(url || '');
  if (!NESA_OK(url)) throw new Error('Not a NESA exam paper link');
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), 120000);
  try {
    const r = await net.fetch(url, { signal: ac.signal, cache: 'no-cache' });
    if (!r.ok) throw new Error('NESA replied ' + r.status);
    if (!NESA_OK(r.url || url)) throw new Error('NESA sent Recall somewhere else');
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length > 80 * 1024 * 1024) throw new Error('That file is over 80 MB');
    const fin = new URL(r.url || url);
    if (/\.pdf$/i.test(fin.pathname)){
      if (buf.subarray(0, 5).toString('latin1') !== '%PDF-') throw new Error('NESA didn’t send a PDF');
      let name = 'paper.pdf'; try { name = decodeURIComponent(fin.pathname.split('/').pop()); } catch {}
      return { url: fin.href, name, bytes: new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength) };
    }
    return { url: fin.href, html: buf.toString('utf8').slice(0, 4e6) };
  } finally { clearTimeout(t); }
});
ipcMain.handle('app-info', () => ({ shell: app.getVersion(), build: stampOf(loadedPage)?.build || null, ready: updReady, updated: !!loadedPage && !loadedPage.startsWith(BUNDLED) }));
ipcMain.handle('check-update', () => checkUpdate(true));
ipcMain.on('update-restart', () => { if (!win) return; const pg = pagePath(); loadedPage = pg; updReady = null; win.loadFile(pg); });

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1360, height: 880, minWidth: 900, minHeight: 600,
    title: 'Recall',
    ...(process.platform === 'darwin'
      ? { titleBarStyle: 'hiddenInset', trafficLightPosition: { x: 18, y: 19 }, vibrancy: 'sidebar', visualEffectState: 'active', backgroundColor: '#00000000' }
      : { titleBarStyle: 'hidden', titleBarOverlay: { color: '#14161b', symbolColor: '#e7e9ef', height: 36 }, backgroundColor: '#14161b', icon: path.join(__dirname, 'winicon.png') }),
    show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, spellcheck: true }
  });
  loadedPage = pagePath(); cleanUpdates(path.basename(path.dirname(loadedPage)));
  win.loadFile(loadedPage);
  win.webContents.once('did-finish-load', () => setTimeout(() => checkUpdate(false), 6000));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });
}

function buildMenu() {
  const mac = process.platform === 'darwin';
  const template = [
    ...(mac ? [{ label: app.name, submenu: [{ role: 'about' }, { label: 'Check for Updates…', click: () => checkUpdate(true) }, { type: 'separator' }, { role: 'services' }, { type: 'separator' }, { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' }, { type: 'separator' }, { role: 'quit' }] }] : []),
    { label: 'File', submenu: [
      { label: 'Import Deck…', accelerator: 'CmdOrCtrl+O', click: () => win?.webContents.send('menu-import') },
      { label: 'Export All Decks…', accelerator: 'Shift+CmdOrCtrl+E', click: () => win?.webContents.send('menu-export') },
      { type: 'separator' },
      { label: mac ? 'Show Library in Finder' : 'Show Library in File Explorer', click: () => shell.openPath(LIB()) },
      { type: 'separator' },
      mac ? { role: 'close' } : { role: 'quit', label: 'Exit' }
    ] },
    { label: 'Edit', submenu: [
      { label: 'Undo', accelerator: 'CmdOrCtrl+Z', click: (_, w) => (w || BrowserWindow.getFocusedWindow())?.webContents.send('menu-undo') },
      { label: 'Redo', accelerator: 'Shift+CmdOrCtrl+Z', click: (_, w) => (w || BrowserWindow.getFocusedWindow())?.webContents.send('menu-redo') },
      { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'pasteAndMatchStyle' }, { role: 'delete' }, { role: 'selectAll' }
    ] },
    { label: 'View', submenu: [{ label: 'Toggle Sidebar', accelerator: 'CmdOrCtrl+S', click: () => { if (win) win.webContents.send('toggle-sidebar'); } }, { type: 'separator' }, { role: 'reload' }, { role: 'togglefullscreen' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }] },
    ...(mac ? [{ role: 'windowMenu' }] : [])
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  const deckArg = argv => (argv || []).slice(1).find(a => /\.(recall|apkg|colpkg)$/i.test(a) && fs.existsSync(a));
  app.on('second-instance', (_e, argv) => { const f = deckArg(argv); if (f) openDeckFile(f); if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  if (process.platform !== 'darwin'){ const f = deckArg(process.argv); if (f) openDeckFile(f); }
  app.whenReady().then(() => {
    nativeTheme.themeSource = 'dark';
    loadLibrary(); backup(); migrate(); migratePhysics(); migrateM6(); migrateBubbles(); migrateEcoT1Cards(); watchLibrary();
    protocol.handle('errimg', req => {
      const name = path.basename(decodeURIComponent(new URL(req.url).pathname));
      return net.fetch(pathToFileURL(path.join(IMG(), name)).toString());
    });
    session.defaultSession.setPermissionRequestHandler((_wc, perm, cb, details) => cb(perm !== 'media' || !(details.mediaTypes || []).includes('audio')));
    buildMenu(); createWindow();
    setInterval(() => checkUpdate(false), 3 * 3600e3);
    app.on('browser-window-focus', () => { if (Date.now() - updLast > 3600e3) checkUpdate(false); });
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('before-quit', () => { if (saveTimer) { try { writeNow(); } catch {} } });
  app.on('window-all-closed', () => { if (saveTimer) { try { writeNow(); } catch {} } if (process.platform !== 'darwin') app.quit(); });
}
