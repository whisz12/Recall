// "Finished" heading above ticked-off tasks: only when there are some, not draggable/selectable, page + Decks card
module.exports = async (p, E, shot) => {
  await E(() => { const t = Date.now(), maths = kids(null).find(n => n.name === 'Maths')?.id, phy = kids(null).find(n => n.name === 'Physics')?.id;
    const L = [['At school', null, 0, 'h'], ['Proofs 2 homework', maths, 60], ['5.1 Pro Ed', phy, 45], ['Vectors ex 3', maths], ['Read Module C notes', null, 20]];
    S.settings = { ...S.settings, todos: L.map(([tx, s, m, k], i) => ({ id: 't' + i, t: tx, s, done: 0, at: t + i, l: 'today', ...(m ? { m } : {}), ...(k ? { k } : {}) })) }; todoTab = 'today'; go('decks'); });
  await p.waitForTimeout(500); await p.keyboard.press('t'); await p.waitForTimeout(600);
  const rows = () => E(() => [...document.querySelectorAll('#tdo .tdl > .tdr')].map(r => (r.classList.contains('tddh') ? 'FIN:' + r.querySelector('.tdhn').textContent : (r.classList.contains('tdh') ? 'H:' : '') + (r.classList.contains('tdon') ? '✓' : '') + (r.querySelector('.tdtx')?.textContent || ''))).join(' | '));
  console.log('none done:', await rows());
  await p.click('[data-tid="t2"] .tdck'); await p.waitForTimeout(1000);
  console.log('one done:', await rows());
  await p.click('[data-tid="t4"] .tdck'); await p.waitForTimeout(1000);
  console.log('two done:', await rows());
  await shot('donehead');
  // heading can't be dragged or selected
  const h = await (await p.$('.tddh')).boundingBox();
  await p.mouse.move(h.x + 200, h.y + h.height / 2); await p.mouse.down(); await p.mouse.move(h.x + 200, h.y - 80, { steps: 8 }); await p.mouse.up(); await p.waitForTimeout(300);
  await p.click('.tddh', { modifiers: ['Shift'] }); await p.waitForTimeout(200);
  console.log('after drag/select on heading:', await rows(), '| sel', await E(() => todoSel.size));
  // drag an open task to the bottom: stays above Finished
  const r1 = await (await p.$('[data-tid="t1"]')).boundingBox();
  await p.mouse.move(r1.x + 300, r1.y + r1.height / 2); await p.mouse.down(); await p.mouse.move(r1.x + 300, h.y + 200, { steps: 14 }); await p.waitForTimeout(150); await p.mouse.up(); await p.waitForTimeout(500);
  console.log('dragged open task down:', await rows());
  // untick one, clear the rest: heading goes
  await p.click('[data-tid="t2"] .tdck'); await p.waitForTimeout(600); console.log('untick:', await rows());
  await p.click('[data-act="todo-clear"]'); await p.waitForTimeout(500); console.log('cleared:', await rows());
  // Decks card shows it too
  await p.click('[data-tid="t3"] .tdck'); await p.waitForTimeout(1000);
  await E(() => go('decks')); await p.waitForTimeout(700);
  console.log('decks card:', await rows());
  await shot('donehead_decks');
};
