# Builds the hosted iPad/web version of Recall into web/ from src/mistake-deck.html
import os as _o
ROOT = _o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))
import json, os, re, time
SP = ROOT + '/tools/'
OUT = ROOT + '/web/'
s = open(ROOT + '/src/mistake-deck.html').read()
cfg = json.load(open(SP + 'cloud.json')) if os.path.exists(SP + 'cloud.json') else {}
if cfg.get('url'): s = s.replace("'__CLOUD_URL__'", json.dumps(cfg['url']).replace('"', "'")).replace("'__CLOUD_KEY__'", json.dumps(cfg['key']).replace('"', "'"))
ver = os.environ.get('RECALL_VER') or time.strftime('%Y%m%d%H%M%S')
head = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Recall">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="theme-color" content="#141414">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icon-180.png">
<link rel="icon" href="icon-192.png">
<script>window.RECALL_HOSTED = true; window.RECALL_BUILD = "{ver}";
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {{}}));
if (innerWidth >= 900) document.documentElement.classList.add('desktop', 'hosted');
// home-screen app on iPad/iPhone: iOS blurs a band under the status bar, so the top bars start below it
if ((navigator.standalone || matchMedia('(display-mode: standalone)').matches) && navigator.maxTouchPoints > 0) document.documentElement.classList.add('iosapp');</script>
'''
# the page body expects body.desktop for the sidebar layout on big screens (iPad); add it once the body exists
s = s.replace('<header class="toolbar">', '<script>if (document.documentElement.classList.contains("desktop")) document.body.classList.add("desktop", "hosted");</script>\n<header class="toolbar">', 1)
css = '''
/* iPad / browser tweaks */
html.hosted body.desktop .toolbar{padding-top:max(22px, var(--sat))}
html.hosted body.desktop::after{display:none}
html.hosted body.desktop .sidetoggle{top:max(10px, var(--sat))}
html.hosted body.desktop .page{padding-top:max(30px, calc(var(--sat) + 14px))}
html.hosted .subj[data-win] > .shd{touch-action:none}
html.hosted body{-webkit-tap-highlight-color:transparent}
'''
k = s.index('</style>'); s = s[:k] + css + s[k:]
open(OUT + 'index.html', 'w').write(head + '</head>\n<body>\n' + s + '\n</body>\n</html>\n')
json.dump({ "name": "Recall", "short_name": "Recall", "start_url": "./", "scope": "./", "display": "standalone", "background_color": "#141414", "theme_color": "#141414",
  "icons": [{ "src": "icon-192.png", "sizes": "192x192", "type": "image/png" }, { "src": "icon-512.png", "sizes": "512x512", "type": "image/png" }] }, open(OUT + 'manifest.webmanifest', 'w'), indent=1)
open(OUT + 'sw.js', 'w').write(f'''// Recall offline cache ({ver}): the app loads even without internet; cards sync when you're back online
const C = 'recall-{ver}', SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icon-180.png', 'icon-192.png', 'icon-512.png', 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.117.2/dist/umd/supabase.js', 'https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js'];
self.addEventListener('install', e => {{ self.skipWaiting(); e.waitUntil(caches.open(C).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {{}}))))); }});
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C && !k.endsWith('-img')).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {{
  const u = new URL(e.request.url); if (e.request.method !== 'GET') return;
  const same = u.origin === location.origin, cdn = /cdn\\.jsdelivr\\.net|fonts\\.(googleapis|gstatic)\\.com/.test(u.host);
  // card images: keep a copy so they show offline (stored by file path, since the access link changes)
  if (/supabase\\.co$/.test(u.host) && u.pathname.includes('/storage/v1/object/')){{
    const key = u.origin + u.pathname.replace('/object/sign/', '/object/');
    return e.respondWith(caches.open('recall-img').then(c => c.match(key).then(hit => hit || fetch(e.request).then(r => {{ if (r.ok) c.put(key, r.clone()); return r; }}))));
  }}
  if (!same && !cdn) return;
  if (same && /\/(version\.json|desktop\.html)$/.test(u.pathname)) return;   // update checks always go to GitHub
  if (e.request.mode === 'navigate' && !/\/(index\.html)?$/.test(u.pathname)) return;   // other pages (like download.html) never replace the cached app
  if (e.request.mode === 'navigate') return e.respondWith(fetch(e.request).then(r => {{ const cp = r.clone(); caches.open(C).then(c => c.put('index.html', cp)); return r; }}).catch(() => caches.match('index.html')));
  e.respondWith(caches.match(e.request).then(hit => {{ const net = fetch(e.request).then(r => {{ if (r.ok || r.type === 'opaque') {{ const cp = r.clone(); caches.open(C).then(c => c.put(e.request, cp)); }} return r; }}).catch(() => hit); return hit || net; }}));
}});
// study group notifications (sent by the "notify" Supabase function)
self.addEventListener('push', e => {{
  let m = {{}}; try {{ m = e.data ? e.data.json() : {{}}; }} catch {{ m = {{ body: e.data && e.data.text() }}; }}
  const tag = m.tag || (m.kind === 'remind' ? 'remind' : (m.kind || 'n') + (m.group || ''));
  const show = self.registration.showNotification(m.title || 'Recall', {{ body: m.body || '', icon: 'icon-192.png', badge: 'icon-192.png', tag, data: {{ url: m.url || './', group: m.group || null, go: m.go || null }} }});
  // "your timer stopped" arriving after you're already back in Recall: show it (a push must), then take it away
  e.waitUntil(m.kind !== 'left' ? show : show.then(() => self.clients.matchAll({{ type: 'window', includeUncontrolled: true }})).then(cs => cs.some(c => c.visibilityState === 'visible') ? self.registration.getNotifications({{ tag }}).then(ns => ns.forEach(n => n.close())) : null));
}});
self.addEventListener('notificationclick', e => {{
  e.notification.close(); const d = e.notification.data || {{}};
  e.waitUntil(self.clients.matchAll({{ type: 'window', includeUncontrolled: true }}).then(cs => {{
    const c = cs[0]; if (c){{ if (d.go !== 'stay') c.postMessage({{ go: d.group ? 'group' : 'decks', g: d.group }}); return c.focus(); }}
    return self.clients.openWindow(d.url || './');
  }}));
}});
''')
open(OUT + '.nojekyll', 'w').write('')
print('built', OUT, ver, 'cloud' if cfg.get('url') else 'NO CLOUD CONFIG')
