const { chromium } = require('playwright'); const fs = require('fs'), path = require('path'), http = require('http');
const ROOT = '' + require('path').join(__dirname, '../../web') + '', OUT = '' + require('path').join(__dirname, 'shots/') + ''; fs.mkdirSync(OUT, { recursive: true });
const BART = fs.readFileSync('' + require('path').join(__dirname, 'bart.txt') + '', 'utf8');
const ECON = 'Inflation reduces the purchasing power of money.\nThe Reserve Bank targets inflation of 2 to 3 per cent, on average, over time.\nIt lowers the cash rate when demand is weak — and raises it when demand is strong.';
const srv = http.createServer((q, r) => { let f = path.join(ROOT, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); fs.createReadStream(f).pipe(r); }).listen(8771);
const log = []; const ok = (c, m) => { log.push((c ? 'PASS ' : 'FAIL ') + m); if (process.env.LIVE) console.log((c ? 'PASS ' : 'FAIL ') + m); };
async function page(b, opt){
  const ctx = await b.newContext(opt); const p = await ctx.newPage(); p.errs = [];
  p.on('pageerror', e => p.errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/supabase|net::|Failed to load|favicon|cdn\.jsdelivr/i.test(m.text())) p.errs.push('console: ' + m.text()); });
  p.on('dialog', d => { p.errs.push('native dialog ' + d.message()); d.dismiss(); });
  await p.goto('http://127.0.0.1:8771/index.html'); await p.waitForTimeout(1800);
  await p.evaluate(([bart, econ]) => { if (dialogOpen()) closeDialog(); const now = Date.now();
    mmPut({ id: 'mmA', t: 'Bart for President', sub: 'English', kind: 'essay', text: bart, marks: [], secs: {}, hist: [], ms: {}, pts: 0, at: now, used: now }, 'seed');
    mmPut({ id: 'mmB', t: 'Topic 2 extended response', sub: 'Economics', kind: 'text', text: econ, marks: [], secs: {}, hist: [], ms: {}, pts: 0, at: now - 1000, used: now - 1000 }, 'seed');
    mm.pid = 'mmA'; go('memo'); }, [BART, ECON]);
  await p.waitForTimeout(300); return p;
}
const runInfo = p => p.evaluate(() => { const r = mm.run; return r ? { done: !!r.done, acc: r.acc, mode: r.mode, diff: r.diff, n: r.words.length } : null; });
async function solve(p, mode, diff){
  await p.evaluate(([m, d]) => { mm.run = null; mm.pid = 'mmA'; mm.sel = new Set([2]); mm.range = null; mm.mode = m; mm.diff = d; go('memo'); mmStart(); }, [mode, diff]);
  await p.waitForTimeout(60);
  const eng = mode === 'type' && diff === 0 ? 'first' : mode;
  for (let guard = 0; guard < 2000; guard++){
    const st = await runInfo(p); if (!st || st.done) break;
    if (eng === 'reveal'){ await p.keyboard.press('Space'); continue; }
    if (eng === 'slider'){ await p.click('[data-act="mm-done"]'); continue; }
    if (eng === 'listen'){ await p.evaluate(() => { mm.run.ended = true; mmPaint(true); }); await p.click('[data-act="mm-done"]'); continue; }
    if (eng === 'first'){ const ch = await p.evaluate(() => mm.run.words[mm.run.pos].f); await p.focus('#mmin'); await p.keyboard.type(ch); continue; }
    if (eng === 'blanks'){
      if (diff === 0){ const k = await p.evaluate(() => { const r = mm.run, cur = r.blanks[r.bi]; return r.bank.find(b => !r.got.has(b.k) && r.words[b.k].core === r.words[cur].core).k; }); await p.click(`[data-act="mm-bank"][data-k="${k}"]`); }
      else { const w = await p.evaluate(() => mm.run.words[mm.run.blanks[mm.run.bi]].t.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’]+$/gu, '')); await p.fill('#mmin', w); await p.press('#mmin', 'Enter'); }
      continue; }
    if (eng === 'reorder'){ const j = await p.evaluate(() => mm.run.ci); await p.click(`[data-act="mm-chunk"][data-j="${j}"]`); continue; }
    if (eng === 'target'){ const ks = await p.evaluate(() => [...mm.run.swap.keys()]); for (const k of ks) await p.click(`[data-act="mm-flag"][data-k="${k}"]`); await p.click('[data-act="mm-t-check"]'); await p.click('[data-act="mm-done"]'); continue; }
    if (eng === 'type'){ const t = await p.evaluate(() => mm.run.sc.map(k => mm.run.words[k].t).join(' ') + ' '); await p.fill('#mmta', t); continue; }
    if (eng === 'choice'){ const j = await p.evaluate(() => mm.run.ok); await p.keyboard.press(String(j + 1)); continue; }
    if (eng === 'speak'){ await p.evaluate(() => { const r = mm.run; r.live = r.sc.map(k => r.words[k].t).join(' '); MM_RUN.speak.align(r); if (r.pos >= r.sc.length) mmFinish(); }); continue; }
  }
  return runInfo(p);
}
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  /* ---------------- desktop ---------------- */
  const p = await page(b, { viewport: { width: 1400, height: 900 } });
  // desktop app layout needs body.desktop: the hosted build adds it at >= 900px
  ok(await p.evaluate(() => document.body.classList.contains('desktop')), 'desktop layout on');
  await p.screenshot({ path: OUT + 'd-home.png' });
  ok(await p.$('.mmnav .mmproj[aria-current="true"]'), 'project list with current project');
  ok((await p.$$('.mmpara')).length === 6, 'six paragraphs shown');
  ok(await p.evaluate(() => [...document.querySelectorAll('.mmgut b')].map(x => x.textContent).join(',')) === 'Intro,Body 1,Body 2,Body 3,Body 4,Conclusion', 'essay section labels');
  await p.click('[data-act="mm-sec"][data-v="2"]'); await p.click('[data-act="mm-sec"][data-v="3"]');
  ok(await p.evaluate(() => $('.mmph b').textContent) === 'Body 2, Body 3', 'panel shows chosen sections');
  await p.click('[data-act="mm-mode"][data-v="choice"]'); await p.click('[data-act="mm-diff"][data-v="2"]');
  ok(await p.evaluate(() => $('.mmdesc').textContent.includes('6 choices')), 'difficulty description updates');
  await p.screenshot({ path: OUT + 'd-home-sel.png' });
  // formatting via a real selection
  await p.evaluate(() => { const ws = document.querySelectorAll('#mmtext .mw'); const r = document.createRange(); r.setStartBefore(ws[3]); r.setEndAfter(ws[8]); const s = getSelection(); s.removeAllRanges(); s.addRange(r); });
  await p.waitForTimeout(400);
  ok(await p.$('#mmfmt'), 'format bar appears on selection');
  await p.screenshot({ path: OUT + 'd-fmtbar.png' });
  await p.click('#mmfmt [data-c="#4C86E0"]');
  let marks = await p.evaluate(() => mmGet('mmA').marks);
  ok(marks.length === 1 && marks[0].a === 3 && marks[0].b === 8 && marks[0].k === 'h', 'highlight saved as a word range ' + JSON.stringify(marks));
  await p.evaluate(() => { const ws = document.querySelectorAll('#mmtext .mw'); const r = document.createRange(); r.setStartBefore(ws[20]); r.setEndAfter(ws[24]); getSelection().removeAllRanges(); getSelection().addRange(r); }); await p.waitForTimeout(400);
  await p.click('#mmfmt [data-act="mm-tool"][data-v="b"]'); await p.click('#mmfmt [data-c="#E5675C"]');
  await p.evaluate(() => { const ws = document.querySelectorAll('#mmtext .mw'); const r = document.createRange(); r.setStartBefore(ws[22]); r.setEndAfter(ws[26]); getSelection().removeAllRanges(); getSelection().addRange(r); }); await p.waitForTimeout(400);
  await p.click('#mmfmt [data-act="mm-tool"][data-v="u"]'); await p.click('#mmfmt [data-c="#4FA85A"]');
  marks = await p.evaluate(() => mmGet('mmA').marks);
  ok(marks.length === 3, 'bold and underline added too ' + marks.length);
  await p.keyboard.press('Meta+z'); await p.waitForTimeout(200);
  ok((await p.evaluate(() => mmGet('mmA').marks.length)) === 2, 'undo removes the last formatting');
  await p.evaluate(() => { const ws = document.querySelectorAll('#mmtext .mw'); const r = document.createRange(); r.setStartBefore(ws[30]); r.setEndAfter(ws[40]); getSelection().removeAllRanges(); getSelection().addRange(r); }); await p.waitForTimeout(400);
  await p.click('#mmfmt [data-act="mm-prac"]');
  ok(await p.evaluate(() => mm.range && mm.range.a === 30 && mm.range.b === 40 && $('.mmph b').textContent === 'Your selection'), 'practise a selection');
  await p.screenshot({ path: OUT + 'd-formatted.png' });
  // every mode and difficulty, answered perfectly
  for (const m of ['reveal', 'slider', 'listen', 'first', 'blanks', 'reorder', 'target', 'type', 'choice', 'speak']) for (const d of [0, 1, 2]){
    const st = await solve(p, m, d);
    const want = m === 'listen' ? null : 100;
    ok(st && st.done && st.acc === want, `${m} ${['easy', 'medium', 'hard'][d]} perfect → ${JSON.stringify(st)}`);
  }
  await p.screenshot({ path: OUT + 'd-result.png' });
  const after = await p.evaluate(() => { const pr = mmGet('mmA'); return { h: pr.hist.length, secs: Object.keys(pr.secs), pts: pr.pts, ms: pr.ms, memo: mmStats(pr).memo }; });
  ok(after.h === 30 && after.secs.includes('2') && after.pts > 0, 'history, schedule and points recorded ' + JSON.stringify(after));
  // mistakes are counted
  await p.evaluate(() => { mm.run = null; mm.sel = new Set([0]); mm.range = null; mm.mode = 'first'; mm.diff = 1; mmStart(); });
  await p.focus('#mmin'); const w0 = await p.evaluate(() => mm.run.words[mm.run.pos].f); await p.keyboard.type(w0 === 'z' ? 'q' : 'z');
  ok(await p.evaluate(() => mm.run.res[mm.run.pos] === 0 && /Accuracy 0%/.test($('#mmracc').textContent)), 'wrong first letter counts against accuracy');
  await p.screenshot({ path: OUT + 'd-first-medium.png' });
  ok(await p.evaluate(() => $('#mmbody').querySelectorAll('.mrw').length) <= 2, 'medium first letters shows only the next word');
  await p.click('[data-act="mm-done"]');
  ok(await p.evaluate(() => mm.run.done && mm.run.acc === 0), 'finishing early marks the rest wrong');
  await p.evaluate(() => { mm.run = null; mm.sel = new Set([0]); mm.mode = 'first'; mm.diff = 0; mmStart(); }); await p.screenshot({ path: OUT + 'd-first-easy.png' });
  await p.evaluate(() => { mm.run = null; mm.mode = 'choice'; mm.diff = 1; mmStart(); });
  const bad = await p.evaluate(() => (mm.run.ok + 1) % mm.run.n); await p.keyboard.press(String(bad + 1));
  ok(await p.evaluate(() => mm.run.res[mm.run.pos] === 0 && mm.run.bad.size === 1), 'wrong multiple-choice pick counted');
  await p.screenshot({ path: OUT + 'd-choice.png' });
  await p.evaluate(() => { mm.run = null; mm.mode = 'target'; mm.diff = 1; mmStart(); }); await p.screenshot({ path: OUT + 'd-target.png' });
  await p.evaluate(() => { mm.run = null; mm.mode = 'reorder'; mm.diff = 0; mmStart(); }); await p.screenshot({ path: OUT + 'd-reorder.png' });
  await p.evaluate(() => { mm.run = null; mm.mode = 'blanks'; mm.diff = 1; mmStart(); }); await p.screenshot({ path: OUT + 'd-blanks.png' });
  await p.evaluate(() => { mm.run = null; mm.mode = 'slider'; mm.diff = 1; mmStart(); }); await p.screenshot({ path: OUT + 'd-slider.png' });
  await p.evaluate(() => { mm.run = null; mm.sel = new Set([1]); mm.mode = 'type'; mm.diff = 1; mmStart(); }); await p.fill('#mmta', 'Bart’s most overlooked qualifcation is hiss '); await p.waitForTimeout(50); await p.screenshot({ path: OUT + 'd-type.png' });
  ok(await p.evaluate(() => mm.run.res.filter(x => x === 1).length === 5 && mm.run.res.filter(x => x === 0).length === 1), 'typing: one-letter slip forgiven, wrong word counted');
  await p.keyboard.press('Escape'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => !mm.run && view.name === 'memo'), 'Escape leaves a session');
  // keys like D or B don't leave mid-session
  await p.evaluate(() => { mm.mode = 'reveal'; mm.diff = 0; mmStart(); }); await p.keyboard.press('d'); await p.keyboard.press('b');
  ok(await p.evaluate(() => view.name === 'memo' && !!mm.run), 'app shortcuts blocked during a session');
  await p.keyboard.press('Escape');
  // due
  await p.evaluate(() => { const pr = mmGet('mmA'); mmPut({ ...pr, secs: { ...pr.secs, 1: { ivl: 1, due: Date.now() - 1000 }, 4: { ivl: 2, due: Date.now() - 5 } } }, 'x', true); render(); });
  ok(await p.evaluate(() => mmDueAll() === 2 && /2 due/.test($('.mmnav').textContent)), 'due count');
  await p.click('.mmduebtn'); ok(await p.evaluate(() => [...mm.sel].sort().join() === '1,4'), 'Practise what’s due selects the due paragraphs');
  ok(await p.evaluate(() => $('nav [data-nav="memo"] .navn')?.textContent === '2'), 'sidebar shows the due count');
  // new project dialog + edit keeps marks
  await p.click('[data-act="mm-new"]'); await p.fill('#mmdt', 'Speech'); await p.fill('#mmdx', 'Four score and seven years ago.\nOur fathers brought forth on this continent a new nation.'); await p.click('[data-act="mm-save"]');
  ok(await p.evaluate(() => mmCur().t === 'Speech' && mmLabels(mmCur()).join() === 'Part 1,Part 2' || mmLabels(mmCur()).join() === '¶1,¶2'), 'new project created ' + await p.evaluate(() => mmLabels(mmCur()).join()));
  await p.evaluate(() => { mm.pid = 'mmA'; render(); });
  await p.evaluate(() => mmDialog('mmA')); await p.evaluate(() => { const x = $('#mmdx'); x.value = 'An added first line.\n' + x.value; }); await p.click('[data-act="mm-save"]');
  const m2 = await p.evaluate(() => ({ marks: mmGet('mmA').marks, secs: Object.keys(mmGet('mmA').secs) }));
  ok(m2.marks.length === 2 && m2.marks[0].a === 7 && m2.secs.includes('3'), 'editing the text keeps formatting and scores in place ' + JSON.stringify(m2));
  // guide
  await p.click('[data-act="mm-tab"][data-v="guide"]'); await p.waitForTimeout(200); await p.screenshot({ path: OUT + 'd-guide.png' });
  for (const g of ['modA', 'modB', 'modC', 'tips', 'adapt', 'exemplars', 'booklet']){ await p.click(`[data-act="mg-sec"][data-v="${g}"]`); await p.waitForTimeout(80); ok(await p.evaluate(() => $('#mgd').textContent.length > 300), 'guide section ' + g); if (g === 'tips' || g === 'adapt' || g === 'booklet') await p.screenshot({ path: OUT + 'd-guide-' + g + '.png' }); }
  await p.click('[data-act="mg-sec"][data-v="exemplars"]'); await p.click('[data-act="mg-mem"][data-i="1"]');
  console.log('EXEMPLAR', await p.evaluate(() => JSON.stringify({ t: mmCur().t, tab: mm.tab, n: mmParsed(mmCur()).W.length, head: mmCur().text.slice(0, 200) })));
  ok(await p.evaluate(() => mmCur().t === 'Lost In Translation' && mm.tab === 'projects' && mmParsed(mmCur()).W.length > 500 && !/[#*]{1,}/.test(mmCur().text.slice(0, 400))), 'exemplar becomes a project');
  await p.screenshot({ path: OUT + 'd-exemplar.png' });
  // light theme look
  await p.evaluate(() => { mm.pid = 'mmA'; mm.sel = new Set([1]); }); await p.evaluate(() => { S.settings.theme = { base: 'slate', over: {}, mode: 'dark', dark: 'slate', light: 'paper' }; ls.set('md-theme', S.settings.theme); themeKey = ''; applyTheme(); render(); }); await p.waitForTimeout(200);
  await p.screenshot({ path: OUT + 'd-dark.png' }); await p.evaluate(() => { mm.mode = 'first'; mm.diff = 0; mmStart(); }); await p.screenshot({ path: OUT + 'd-dark-first.png' }); await p.keyboard.press('Escape');
  ok(p.errs.length === 0, 'desktop: no errors ' + JSON.stringify(p.errs.slice(0, 5)));

  /* ---------------- 25 Nov additions ---------------- */
  await p.evaluate(() => { S.settings.theme = { base: 'slate', over: {}, mode: 'dark', dark: 'slate', light: 'paper' }; themeKey = ''; applyTheme(); mm.run = null; mm.tab = 'projects'; mm.pid = 'mmA'; mm.sel.clear(); mm.range = null; mm.hist = []; render(); });
  await p.setViewportSize({ width: 1400, height: 900 }); await p.waitForTimeout(200);
  // right-click menus
  await p.click('.mmproj[data-id="mmB"]', { button: 'right' }); await p.waitForTimeout(100);
  ok(await p.evaluate(() => !!$('#menu [data-act="mm-edit"][data-id="mmB"]') && !!$('#menu [data-act="mm-delask"]') && !!$('#menu [data-act="mm-open"]')), 'right-click a project: open, edit, delete');
  await p.screenshot({ path: OUT + 'n-rclick.png' });
  await p.keyboard.press('Escape');
  const nb = await p.evaluate(() => { const r = $('.mmnav').getBoundingClientRect(); return { x: r.left + 60, y: r.bottom - 40 }; });
  await p.mouse.click(nb.x, nb.y, { button: 'right' }); await p.waitForTimeout(100);
  ok(await p.evaluate(() => !!$('#menu [data-act="mm-new"]')), 'right-click empty list: new project');
  await p.click('#menu [data-act="mm-new"]'); ok(await p.evaluate(() => !!$('#mmdt')), 'new project dialog opens from the menu'); await p.keyboard.press('Escape');
  // hide the projects column
  await p.click('[data-act="mm-navtog"]'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => getComputedStyle($('.mmnav')).display === 'none' && !!$('.mmnavshow')), 'projects column hides, show button appears');
  await p.screenshot({ path: OUT + 'n-navhidden.png' });
  await p.click('.mmnavshow'); ok(await p.evaluate(() => getComputedStyle($('.mmnav')).display !== 'none'), 'and comes back');
  // scroll position kept when formatting
  await p.evaluate(() => { $('.mmmain').scrollTop = 700; }); await p.waitForTimeout(100);
  await p.evaluate(() => { const r = document.createRange(), m = $('.mmmain'), ws = [...document.querySelectorAll('#mmtext .mw')].filter(w => { const b = w.getBoundingClientRect(); return b.top > 200 && b.bottom < 700; }); r.setStartBefore(ws[0]); r.setEndAfter(ws[3]); getSelection().removeAllRanges(); getSelection().addRange(r); }); await p.waitForTimeout(350);
  await p.click('#mmfmt [data-act="mm-tool"][data-v="h"]'); await p.click('#mmfmt [data-c="#D99A2B"]'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => Math.abs($('.mmmain').scrollTop - 700) < 5), 'formatting keeps the scroll position ' + await p.evaluate(() => $('.mmmain').scrollTop));
  // sections: edit
  await p.evaluate(() => { $('.mmmain').scrollTop = 0; }); await p.click('[data-act="mm-secs"]'); await p.waitForTimeout(100);
  await p.screenshot({ path: OUT + 'n-sections.png' });
  await p.selectOption('.mmsecl select[data-i="2"]', 'join'); const lastI = await p.evaluate(() => mmParsed(mmGet('mmA')).P.length - 1); await p.selectOption(`.mmsecl select[data-i="${lastI}"]`, 'body'); await p.click('[data-act="mm-secsave"]'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => (L => L.length === mmParsed(mmGet('mmA')).P.length - 1 && !L.includes('Conclusion') && L[1] === 'Body 1')(mmLabels(mmGet('mmA'))) && mmSections(mmGet('mmA'))[1].ps.join() === '1,2'), 'sections can be set by hand ' + await p.evaluate(() => mmLabels(mmGet('mmA')).join() + ' ' + JSON.stringify(mmGet('mmA').roles) + ' P' + mmParsed(mmGet('mmA')).P.length + ' pid ' + mm.pid));
  await p.click('[data-act="mm-sec"][data-v="1"]'); ok(await p.evaluate(() => mmSelIdx(mmGet('mmA')).length === mmParsed(mmGet('mmA')).P.slice(1, 3).reduce((n, x) => n + x.b - x.a + 1, 0)), 'a joined section practises both paragraphs');
  await p.screenshot({ path: OUT + 'n-joined.png' });
  await p.evaluate(() => mmSecSave('mmA', true)); ok(await p.evaluate(() => !mmGet('mmA').roles), 'Guess again clears hand-set sections');
  // back between pages
  await p.evaluate(() => { mm.hist = []; mm.sel.clear(); render(); }); await p.click('[data-act="mm-sec"][data-v="2"]'); await p.click('[data-act="mm-sec"][data-v="3"]');
  await p.click('#navcl [data-act="hist-back"]'); ok(await p.evaluate(() => [...mm.sel].join() === '2'), 'Back button undoes the last section pick');
  await p.mouse.click(5, 880); await p.keyboard.press('Backspace'); ok(await p.evaluate(() => mm.sel.size === 0), 'Backspace goes back too');
  // back inside a session
  await p.evaluate(() => { mm.sel = new Set([1]); mm.mode = 'reveal'; mm.diff = 0; mmStart(); });
  await p.keyboard.press('Space'); await p.keyboard.press('Space'); await p.keyboard.press('Space');
  ok(await p.evaluate(() => mm.run.u === 1 && mm.run.shown), 'revealed sentence 2');
  await p.keyboard.press('Backspace'); ok(await p.evaluate(() => mm.run.u === 1 && !mm.run.shown), 'Backspace hides it again');
  await p.keyboard.press('Meta+z'); ok(await p.evaluate(() => mm.run.u === 0 && mm.run.shown && mm.run.res.every(x => x == null)), '⌘Z undoes the mark');
  await p.click('#navcl [data-act="hist-back"]'); ok(await p.evaluate(() => mm.run && mm.run.u === 0 && !mm.run.shown), 'Back button steps back in the session');
  await p.click('#navcl [data-act="hist-back"]'); ok(await p.evaluate(() => !mm.run), 'and leaves it when there is nothing left to undo');
  await p.evaluate(() => { mm.sel = new Set([1]); mm.mode = 'first'; mm.diff = 1; mmStart(); });
  for (let i = 0; i < 3; i++){ const ch = await p.evaluate(() => mm.run.words[mm.run.pos].f); await p.focus('#mmin'); await p.keyboard.type(ch); }
  await p.keyboard.press('Backspace'); ok(await p.evaluate(() => mm.run.pos === mm.run.sc[2]), 'Backspace in first letters steps back one word');
  await p.keyboard.press('Escape');
  // Type it shows the word you're typing
  await p.evaluate(() => { mm.sel = new Set([1]); mm.mode = 'type'; mm.diff = 2; mmStart(); }); const tw = await p.evaluate(() => mm.run.sc.slice(0, 3).map(k => mm.run.words[k].t)); await p.fill('#mmta', tw[0] + ' ' + tw[1] + ' ' + tw[2].slice(0, 3)); await p.waitForTimeout(50);
  ok(await p.evaluate(() => $('#mmbody .mrtyping')?.textContent === mm.run.partial && mm.run.partial.length === 3 && !$('#mmbody .mrtyping.mrbad')), 'Type it shows the word as you type it ' + await p.evaluate(() => JSON.stringify({ p: mm.run?.partial, m: mm.run?.mode, h: [...document.querySelectorAll('#mmbody .mrnext')].map(x => x.outerHTML.slice(0, 90)) })));
  await p.fill('#mmta', tw[0] + ' ' + tw[1] + ' qqz'); ok(await p.evaluate(() => !!$('#mmbody .mrtyping.mrbad')), 'and marks it when it goes wrong');
  await p.screenshot({ path: OUT + 'n-typing.png' }); await p.keyboard.press('Escape');
  // banks
  await p.click('[data-act="mm-tab"][data-v="banks"]'); await p.waitForTimeout(100); await p.screenshot({ path: OUT + 'n-banks-empty.png' });
  await p.click('[data-act="mb-new"]'); await p.fill('#mbw', 'ephemeral'); await p.fill('#mbm', 'lasting a very short time'); await p.fill('#mbe', 'Bart’s ephemeral reign over the canteen.'); await p.fill('#mbg', 'Mod C, adjectives'); await p.click('[data-act="mb-save"]');
  await p.click('[data-act="mb-new"]'); await p.fill('#mbw', 'acerbic'); await p.fill('#mbm', 'sharp and forthright'); await p.click('[data-act="mb-save"]');
  await p.click('[data-act="mm-bank-tab"][data-v="t"]'); await p.click('[data-act="mb-new"]'); await p.fill('#mbn', 'Enjambment'); await p.selectOption('#mbf', 'Poetry'); await p.fill('#mbd', 'A line runs on past its end, pushing the reader forward.'); await p.click('[data-act="mb-save"]');
  await p.click('[data-act="mm-bank-tab"][data-v="n"]'); await p.click('[data-act="mb-new"]'); await p.fill('#mbh', 'Mod B thesis ideas'); await p.fill('#mbb', 'Power and performance\nThe cost of ambition'); await p.click('[data-act="mb-save"]');
  ok(await p.evaluate(() => mbAll('v').length === 2 && mbAll('t').length === 1 && mbAll('n').length === 1), 'banks save words, techniques and notes');
  await p.screenshot({ path: OUT + 'n-notes.png' });
  await p.click('[data-act="mm-bank-tab"][data-v="v"]'); await p.fill('#mbq', 'sharp'); ok(await p.evaluate(() => $('#mblist').querySelectorAll('.mbrow').length === 1), 'bank search');
  await p.fill('#mbq', ''); await p.screenshot({ path: OUT + 'n-vocab.png' });
  await p.click('[data-act="mm-bank-tab"][data-v="t"]'); await p.screenshot({ path: OUT + 'n-tech.png' });
  await p.click('[data-act="mm-tab"][data-v="projects"]'); await p.waitForTimeout(100);
  await p.evaluate(() => { const ws = document.querySelectorAll('#mmtext .mw'); const r = document.createRange(); r.setStartBefore(ws[11]); r.setEndAfter(ws[11]); getSelection().removeAllRanges(); getSelection().addRange(r); }); await p.waitForTimeout(350);
  await p.click('#mmfmt [data-act="mm-vocab"]'); ok(await p.evaluate(() => $('#mbw').value.length > 1 && $('#mbe').value.length > 20), 'Add to vocab from a selection ' + await p.evaluate(() => $('#mbw')?.value)); await p.keyboard.press('Escape');
  // study group timer
  const grt = await p.evaluate(async () => { gr.groups = [{ id: 'g1', name: 'Test' }]; focus = { ...focus, state: 'idle' }; mm.sel = new Set([0]); mm.mode = 'choice'; mm.diff = 0; mmStart(); await new Promise(r => setTimeout(r, 300)); return { st: focus.state, subj: focus.subj }; });
  ok(grt.st === 'studying' && grt.subj === 'English', 'starting a session starts the group study timer ' + JSON.stringify(grt));
  await p.keyboard.press('Escape');
  ok(p.errs.filter(x => !/grMergeDay|grPush|supabase|fetch/i.test(x)).length === 0, 'no errors after additions ' + JSON.stringify(p.errs.slice(0, 4)));
  /* ---------------- narrow desktop window ---------------- */
  await p.setViewportSize({ width: 1000, height: 800 }); await p.waitForTimeout(200); await p.screenshot({ path: OUT + 'd-narrow.png' });
  ok(await p.evaluate(() => getComputedStyle($('.mmnav')).display === 'none' && !!$('[data-act="mm-switch"]')), 'narrow window swaps the project column for Switch');
  /* ---------------- phone ---------------- */
  const q = await page(b, { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  await q.evaluate(() => { mm.screen = 'list'; render(); }); await q.waitForTimeout(150);
  await q.screenshot({ path: OUT + 'p-list.png' });
  ok(await q.evaluate(() => !document.body.classList.contains('desktop') && !!$('.mmplist')), 'phone: projects list');
  await q.tap('.mmprow'); await q.waitForTimeout(150); await q.screenshot({ path: OUT + 'p-project.png' });
  ok(await q.$('.mmpbar [data-act="mm-sheet"]'), 'phone: project with one Practise button');
  await q.tap('[data-act="mm-sec"][data-v="2"]'); await q.tap('[data-act="mm-sheet"]'); await q.waitForTimeout(250); await q.screenshot({ path: OUT + 'p-sheet.png' });
  ok(await q.$('.mmsheet .mmtiles'), 'phone: practise sheet with mode tiles');
  await q.tap('.mmsheet [data-act="mm-mode"][data-v="first"]'); await q.tap('.mmsheet [data-act="mm-diff"][data-v="1"]'); await q.tap('.mmsheet [data-act="mm-start"]'); await q.waitForTimeout(150);
  for (let i = 0; i < 6; i++){ const ch = await q.evaluate(() => mm.run.words[mm.run.pos].f); await q.focus('#mmin'); await q.keyboard.type(ch); }
  await q.screenshot({ path: OUT + 'p-run.png' });
  ok(await q.evaluate(() => getComputedStyle(document.querySelector('.toolbar nav')).display === 'none'), 'phone: bottom bar hidden while practising');
  await q.evaluate(() => { const r = mm.run; MM_RUN.first.done(r); }); await q.waitForTimeout(100); await q.screenshot({ path: OUT + 'p-result.png' });
  await q.tap('[data-act="mm-home"]'); await q.evaluate(() => { mm.tab = 'guide'; render(); }); await q.waitForTimeout(150); await q.screenshot({ path: OUT + 'p-guide.png' });
  await q.evaluate(() => { mm.tab = 'banks'; render(); }); await q.waitForTimeout(100); await q.screenshot({ path: OUT + 'p-banks.png' }); await q.evaluate(() => { mm.tab = 'projects'; mm.screen = 'project'; render(); });
  ok(q.errs.length === 0, 'phone: no errors ' + JSON.stringify(q.errs.slice(0, 5)));
  /* ---------------- iPad portrait ---------------- */
  const t = await page(b, { viewport: { width: 820, height: 1180 }, isMobile: true, hasTouch: true });
  await t.screenshot({ path: OUT + 't-home.png' });
  ok(t.errs.length === 0, 'iPad portrait: no errors ' + JSON.stringify(t.errs.slice(0, 5)));
  console.log(log.join('\n')); console.log(log.filter(x => x.startsWith('FAIL')).length + ' failures');
  await b.close(); srv.close();
})();
