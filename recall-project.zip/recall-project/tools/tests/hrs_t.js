const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]];
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8774);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ua = W > 700 ? 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, userAgent: ua }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message + ' @ ' + (e.stack || '').split('\n').slice(1, 3).join(' ')));
  const V = path.resolve(__dirname, '../../app/app/vendor') + '/';
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)|supabase\.co/, route => { const u = route.request().url(); if (u.includes('supabase.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(V + 'supabase.js') }); route.fulfill({ status: 200, body: '' }); });
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(lib => {
    if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib);
    // three weeks of fake sessions
    const S = ['Maths', 'Physics', 'Economics', 'English'], log = []; const now = Date.now();
    for (let d = 24; d >= 0; d--){ if (d % 6 === 5) continue; const base = new Date(now - d * 864e5); base.setHours(15, 30, 0, 0); let t = base.getTime() + (d % 3) * 40 * 60e3; const n = 2 + (d % 4);
      for (let i = 0; i < n; i++){ const len = (25 + ((d * 7 + i * 13) % 70)) * 60e3; if (t + len > now) break; log.push([t, t + len, S[(d + i) % 4]]); t += len + (10 + (i * 17 % 40)) * 60e3; } }
    localStorage.setItem('md-fsess', JSON.stringify(log));
  }, lib);
  await p.goto('http://127.0.0.1:8774/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), shot = async n => { await p.waitForTimeout(250); await p.screenshot({ path: `/tmp/hr_${TAG}_${n}.png`, fullPage: true }); };
  await E(() => { document.querySelector('#layer').innerHTML = ''; go('stats'); }); await shot('0cards');
  console.log('switch on cards page:', await E(() => !!document.querySelector('.hrsswitch')));
  await p.click('[data-act="hrs-open"]'); await p.waitForTimeout(200);
  await E(() => { hs.at = keyAdd(fDay(), -1); renderHours(); }); await shot('1day');
  console.log('day:', await E(() => [document.querySelector('.hrsstep h1').textContent, document.querySelector('.hrsbig b').textContent, [...document.querySelectorAll('.hrsfacts dd')].map(x => x.textContent).join(' | '), document.querySelectorAll('.hrsses li').length]));
  // add time
  await p.click('[data-act="hrs-add"]'); await p.fill('#hafrom', '09:00'); await p.fill('#hato', '10:15'); await p.click('[data-act="hrs-add-go"]'); await p.waitForTimeout(300);
  console.log('after add:', await E(() => [document.querySelector('.hrsbig b').textContent, document.querySelectorAll('.hrsses li').length, document.querySelector('#toast')?.textContent]));
  await p.click('.hrsses li:first-child .hx'); await p.waitForTimeout(300);
  console.log('after delete:', await E(() => [document.querySelector('.hrsbig b').textContent, document.querySelectorAll('.hrsses li').length]));
  await p.click('[data-act="hrs-mode"][data-v="week"]'); await shot('2week');
  console.log('week:', await E(() => [document.querySelector('.hrsstep h1').textContent, document.querySelector('.hrsbig b').textContent, [...document.querySelectorAll('.hrsfacts dd')].map(x => x.textContent).join(' | ')]));
  await p.click('[data-act="hrs-step"][data-v="-1"]'); console.log('prev week:', await E(() => document.querySelector('.hrsstep h1').textContent));
  await p.click('[data-act="hrs-mode"][data-v="month"]'); await shot('3month');
  console.log('month:', await E(() => [document.querySelector('.hrsstep h1').textContent, document.querySelector('.hrsbig b').textContent, [...document.querySelectorAll('.hrsfacts dd')].map(x => x.textContent).join(' | '), document.querySelectorAll('.hcd.l3,.hcd.l4,.hcd.l5').length]));
  await p.click('.hcalg .hcd.l2, .hcalg .hcd.l3'); console.log('clicked day ->', await E(() => [hs.mode, hs.at]));
  // live timer counts in today
  await E(() => { hs.at = fDay(); hs.mode = 'day'; focus = { ...focus, state: 'studying', subj: 'Maths', since: Date.now() - 30 * 60e3 }; renderHours(); });
  console.log('today live:', await E(() => [document.querySelector('.hrsbig b').textContent, document.querySelector('.hrsses li:last-child')?.textContent]));
  await E(() => fPause('you')); console.log('paused -> sessions in log today:', await E(() => hrsLocal(fDay()).length));
  console.log('hscroll:', await E(() => document.documentElement.scrollWidth > innerWidth + 1));
  console.log(TAG, 'errors:', errs); await b.close(); srv.close();
})();
