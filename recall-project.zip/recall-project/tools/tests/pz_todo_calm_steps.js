module.exports = async (p, E, shot) => {
  await E(() => { const t = Date.now(), maths = kids(null).find(n => n.name === 'Maths')?.id, phy = kids(null).find(n => n.name === 'Physics')?.id, eco = kids(null).find(n => n.name === 'Economics')?.id;
    const L = [['At school', null, 0, 'h'], ['Vranesavic optimisation + 1988 question', maths], ['Finish Proofs 2 homework', maths, 60], ['5.1 Pro Ed', phy], ['', null, 0, 'gap'], ['After school at the library', null, 0, 'h'], ['NSB 3U 2025 paper', maths, 120], ['Cog homework', phy, 30], ['Topic 3 economics notes', eco], ['', null, 0, 'gap'], ['At home', null, 0, 'h'], ['If time, grind decks', null]];
    S.settings = { ...S.settings, todos: L.map(([tx, s, m, k], i) => ({ id: 't' + i, t: tx, s, done: i === 3 ? t : 0, at: t + i, l: 'today', ...(m ? { m } : {}), ...(k ? { k } : {}) })) }; todoTab = 'today'; go('decks'); });
  await p.waitForTimeout(800); await E(() => { todoF = { at: $('#tdo').dataset.subj, v: 'all' }; todoRefresh(); }); await p.waitForTimeout(300);
  await E(() => document.querySelector('#tdo').scrollIntoView()); await p.waitForTimeout(300);
  const box = await p.$('#tdo'); await box.screenshot({ path: `pz_calm_${process.env.TAG || 'd'}_1.png` });
  if (!process.env.MOBILE){
    await p.hover('[data-tid="t2"] .tdt'); await p.waitForTimeout(250); await box.screenshot({ path: 'pz_calm_d_hover.png' });
    await p.click('[data-tid="t2"] .tdmore2'); await p.waitForTimeout(200); console.log('menu', await E(() => $('#menu').innerText.replace(/\n/g, ' | '))); await p.screenshot({ path: 'pz_calm_d_menu.png' });
    await p.click('#menu [data-act="todo-time"]'); await p.waitForTimeout(200); console.log('time menu', await E(() => $('#menu')?.innerText.slice(0, 40)));
    await p.keyboard.press('Escape');
    await p.click('.tdfbtn'); await p.waitForTimeout(200); console.log('fmenu', await E(() => $('#menu').innerText.replace(/\n/g, ' | ')));
    await p.click('#menu [data-act="todo-f"]:nth-of-type(2)'); await p.waitForTimeout(300); console.log('filtered', await E(() => [$('.tdfbtn').innerText, [...document.querySelectorAll('#tdo .tdr')].map(r => r.innerText.split('\n')[0]).join(' | '), !!$('#menu')]));
    await E(() => { todoF = { at: $('#tdo').dataset.subj, v: 'all' }; todoRefresh(); });
    await p.click('[data-tid="t5"] .tdfold'); await p.waitForTimeout(300);
    console.log('folded', await E(() => [...document.querySelectorAll('#tdo .tdr')].map(r => (r.classList.contains('tdh') ? 'H:' : '') + (r.innerText.split('\n')[0] || '[gap]')).join(' | ')));
    // drag folded heading to the top
    const h = await p.$('[data-tid="t5"]'), top = await p.$('[data-tid="t0"]'); const hb = await h.boundingBox(), tb = await top.boundingBox();
    await p.mouse.move(hb.x + 300, hb.y + hb.height / 2); await p.mouse.down(); await p.mouse.move(hb.x + 300, hb.y - 10, { steps: 3 }); await p.mouse.move(hb.x + 300, tb.y + 2, { steps: 10 }); await p.mouse.up(); await p.waitForTimeout(400);
    await p.click('[data-tid="t5"] .tdfold'); await p.waitForTimeout(300);
    console.log('dragged+unfolded', await E(() => [...document.querySelectorAll('#tdo .tdr')].map(r => (r.classList.contains('tdh') ? 'H:' : '') + (r.innerText.split('\n')[0] || '[gap]')).join(' | ')));
    await p.click('#tdoin'); await p.waitForTimeout(200); await (await p.$('#tdo')).screenshot({ path: 'pz_calm_d_add.png' });
    await p.click('[data-act="todo-hmode"]'); await p.waitForTimeout(150); console.log('hmode act', await E(() => [$('.tdadd').className, document.activeElement.id]));
  }
};
