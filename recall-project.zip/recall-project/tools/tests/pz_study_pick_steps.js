module.exports = async (p, E, shot) => {
  const log = (...a) => console.log(...a);
  // a topic with at least 2 subtopics that have cards
  const t = await E(() => { for (const s of kids(null)) for (const tp of kids(s.id)){ const ks = kids(tp.id).filter(k => cardsIn(k.id).length); if (ks.length >= 2) return { id: tp.id, name: tp.name, kids: ks.map(k => ({ id: k.id, name: k.name, n: cardsIn(k.id).length })), total: cardsIn(tp.id).length, own: Object.values(S.cards).filter(c => c.nodeId === tp.id).length }; } });
  log('topic', t.name, '| total', t.total, '| own', t.own, '| subtopics', t.kids.map(k => k.name + ' ' + k.n).join(', '));
  await E(id => go('overview', id), t.id); await p.waitForTimeout(500);
  log('button', await E(() => $('[data-act="study-pick"]')?.innerText)); await shot('page');
  await p.click('.ovb[data-act="study-pick"]'); await p.waitForTimeout(300);
  const dlg = () => E(() => ({ h: $('#sah').innerText, rows: [...document.querySelectorAll('.sarow')].map(r => r.querySelector('.san').innerText + (r.querySelector('input').checked ? ' ✓' : ' ✗')).join(' | '), foot: $('.sadlg footer').innerText.replace(/\n+/g, ' | ') }));
  log('dialog', JSON.stringify(await dlg())); 
  await p.click(`.sarow input[data-sa="${t.kids[0].id}"]`); await p.waitForTimeout(250); log('unticked', JSON.stringify(await dlg())); await shot('dlg');
  const mode = await E(() => $('.sadlg .btn.primary[data-act="sa-go"]').dataset.mode);
  await p.click('.sadlg .btn.primary[data-act="sa-go"]'); await p.waitForTimeout(600);
  log('session', mode, JSON.stringify(await E(([root, ex]) => { const ids = [study.cur, ...study.queue].filter(Boolean), bad = new Set(subtree(ex)); return { node: study.node === root, n: ids.length, anyExcluded: ids.some(i => bad.has(S.cards[i].nodeId)), view: view.name }; }, [t.id, t.kids[0].id])));
  // rate through a few: nothing excluded sneaks back in
  for (let i = 0; i < 4; i++){ if (!(await E(() => study?.cur))) break; await E(() => showAnswer()); await p.waitForTimeout(150); await E(() => rate(1)); await p.waitForTimeout(450); }
  log('after ratings', JSON.stringify(await E(ex => { const ids = [study?.cur, ...(study?.queue || [])].filter(Boolean), bad = new Set(subtree(ex)); return { n: ids.length, anyExcluded: ids.some(i => bad.has(S.cards[i].nodeId)) }; }, t.kids[0].id)));
  // remembered, shown on the button, plain Study still everything, Study all untouched
  await E(id => go('overview', id), t.id); await p.waitForTimeout(400);
  log('remembered', await E(id => [JSON.stringify(ls.get('md-study-exn', {})[id]?.length), $('.ovb[data-act="study-pick"]').classList.contains('on'), JSON.stringify(ls.get('md-study-ex', []))], t.id));
  await E(id => startStudy(id, true), t.id); await p.waitForTimeout(400); log('plain practise all', await E(() => study.queue.length + 1), 'of', t.total);
  await E(id => go('overview', id), t.id); await p.waitForTimeout(300);
  await p.click('.ovb[data-act="study-pick"]'); await p.waitForTimeout(300); log('reopen', (await dlg()).rows);
  await p.click('[data-act="sa-none"]'); await p.waitForTimeout(200); log('clear', JSON.stringify(await dlg()));
  await p.click('[data-act="sa-all"]'); await p.waitForTimeout(200); log('pick all', (await dlg()).foot, '| stored', await E(id => JSON.stringify(ls.get('md-study-exn', {})[id] || null), t.id));
  await p.keyboard.press('Escape'); await p.waitForTimeout(200);
  // Study all dialog still works on its own
  await E(() => studyAllDialog('study')); await p.waitForTimeout(300); log('study all', JSON.stringify(await dlg()).slice(0, 160));
};
