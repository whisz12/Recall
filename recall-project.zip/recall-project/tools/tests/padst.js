const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
const R = '/home/claude/w/recall-project', W = +process.argv[2] || 1180, H = +process.argv[3] || 820, TAG = process.argv[4] || 'i';
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: true, isMobile: true, deviceScaleFactor: 1, userAgent: 'Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await ctx.route(/raw\.githubusercontent\.com|api\.github\.com|jsdelivr|fonts\./, r => r.fulfill({ status: 404, body: '' }));
  const lib = fs.readFileSync(R + '/tools/tests/lib20.json', 'utf8');
  const http = require('http'), root = R + '/web';
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); fs.createReadStream(f).pipe(r); }).listen(8773);
  await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
  await p.goto('http://127.0.0.1:8773/'); await p.waitForTimeout(1500);
  const E = (f, a) => p.evaluate(f, a), shot = n => p.screenshot({ path: `${TAG}_${n}.png` });
  const script = process.env.STEPS ? require(path.resolve(process.env.STEPS)) : null;
  if (script) await script(p, E, shot, ctx);
  console.log(JSON.stringify({ errs })); await b.close(); srv.close(); process.exit(0);
})();
