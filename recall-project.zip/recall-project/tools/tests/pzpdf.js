const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await b.newPage();
  let h = '<style>body{font:14px Times;margin:0} .pg{page-break-after:always;padding:60px 70px;height:950px;box-sizing:border-box} h1{font-size:20px} .q{margin:0 0 26px} small{font-size:9px}</style>';
  h += '<div class="pg"><h1>North Sydney Boys High School<br>2023 Trial HSC Examination<br>Physics</h1><p>General Instructions: Reading time 5 minutes. Working time 3 hours.</p></div>';
  let n = 1;
  for (let pg = 0; pg < 5; pg++){ h += '<div class="pg">'; for (let k = 0; k < 3; k++, n++) h += `<div class="q"><b>Question ${n}</b> (${(n % 4) + 2} marks)<br>A ball is projected at ${10 + n} m s<sup>-1</sup> at 30° to the horizontal from a cliff ${20 + n} m high. Calculate the time of flight, the range, and the final velocity. <small>Use g = 9.8 m s⁻² and ignore air resistance. This small print is here to test zooming in on tiny text in a past paper.</small><br><br>..........................................................................................<br>..........................................................................................</div>`; h += '</div>'; }
  await p.setContent(h); await p.pdf({ path: 'paper.pdf', format: 'A4' }); await b.close(); console.log('ok');
})();
