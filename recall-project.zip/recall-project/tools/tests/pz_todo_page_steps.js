module.exports = async (p, E, shot) => {
  await E(() => { const t = Date.now(), maths = kids(null).find(n => n.name === 'Maths')?.id, phy = kids(null).find(n => n.name === 'Physics')?.id;
    const L = [['At school', null, 0, 'h'], ['Vranesavic optimisation + 1988 question', maths], ['Finish Proofs 2 homework', maths, 60], ['5.1 Pro Ed', phy, 45], ['', null, 0, 'gap'], ['After school at the library', null, 0, 'h'], ['NSB 3U 2025 paper', maths, 120], ['Cog homework', phy, 30], ['Counting in a line combinatorics', maths], ['', null, 0, 'gap'], ['At home', null, 0, 'h'], ['If time, grind decks', null]];
    S.settings = { ...S.settings, todos: L.map(([tx, s, m, k], i) => ({ id: 't' + i, t: tx, s, done: 0, at: t + i, l: 'today', ...(m ? { m } : {}), ...(k ? { k } : {}) })) }; todoTab = 'today'; go('decks'); });
  await p.waitForTimeout(500);
  console.log('decks page has to-do:', await E(() => !!$('#tdo')), '| nav To-do:', await E(() => !!$('nav [data-nav="todo"]')));
  await p.keyboard.press('t'); await p.waitForTimeout(600);
  const rows = () => E(() => [...document.querySelectorAll('#tdo .tdl > .tdr')].map(r => (r.classList.contains('tdh') ? 'H:' : r.classList.contains('tdgap') ? '[gap]' : '') + (r.querySelector('.tdtx')?.textContent || '') + (r.classList.contains('tdsel') ? '*' : '') + (r.querySelector('.tdsubn') ? '(' + r.querySelector('.tdsubn').textContent + ')' : '')).join(' | '));
  console.log('view', await E(() => [view.name, $('nav [aria-current="true"]')?.dataset.nav, $('.tdfbtn')?.innerText]));
  await shot('page');
  // shift-click range, cmd-click add
  await p.click('[data-tid="t6"] .tdt'); await p.waitForTimeout(100); await E(() => document.activeElement.blur?.());
  await p.keyboard.press('Escape');
  await p.click('[data-tid="t6"] .tdselb'); await p.click('[data-tid="t8"] .tdt', { modifiers: ['Shift'] }); await p.click('[data-tid="t1"] .tdt', { modifiers: ['Meta'] }); await p.waitForTimeout(200);
  console.log('selected', await E(() => [...todoSel].join(',')), await E(() => $('.tdselbar')?.innerText.replace(/\n/g, ' | ')));
  await shot('sel');
  // drag the selection under "At home"
  const r6 = await (await p.$('[data-tid="t6"]')).boundingBox(), hh = await (await p.$('[data-tid="t10"]')).boundingBox();
  await p.mouse.move(r6.x + 400, r6.y + r6.height / 2); await p.mouse.down(); await p.mouse.move(r6.x + 400, r6.y + 30, { steps: 4 });
  console.log('carry hidden', await E(() => document.querySelectorAll('.tdcarry').length), await E(() => $('.tdmulti')?.dataset.n));
  const hh2 = await (await p.$('[data-tid="t10"]')).boundingBox(); await p.mouse.move(r6.x + 400, hh2.y + hh2.height + 10, { steps: 14 }); await p.waitForTimeout(150); await p.mouse.up(); await p.waitForTimeout(500);
  console.log('after drag', await rows());
  await p.keyboard.press('Escape'); await p.waitForTimeout(150); console.log('esc clears', await E(() => todoSel.size));
  // subtopics
  await p.click('.tdfbtn[data-act="todo-fmenu"]'); await p.waitForTimeout(200); await p.screenshot({ path: 'pz_td_fmenu.png' });
  await p.click('[data-act="todo-catnew"]'); await p.waitForTimeout(300);
  await p.fill('#tdcatn', '3U Maths'); await p.selectOption('#tdcatp', { label: 'Maths' }); await p.click('.tdcatsw[data-c="#d4a72c"]'); await (await p.$('.dialog.tdcatd')).screenshot({ path: 'pz_td_catdlg.png' });
  await p.click('[data-act="todo-catsave"]'); await p.waitForTimeout(300);
  console.log('after cat', await E(() => [JSON.stringify(S.settings.todoCats), todoF.v, $('.tdfbtn[data-act="todo-fmenu"]').innerText, $('#tdoin').placeholder]));
  await p.fill('#tdoin', 'Ex 5.3 Q1-12'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('3U view', await rows());
  await E(() => { todoF = { at: null, v: kids(null).find(n => n.name === 'Maths').id }; todoRefresh(); }); console.log('Maths view', await rows());
  await E(() => { todoF = { at: null, v: 'all' }; todoRefresh(); }); console.log('All view', await rows());
  // move a task into the subtopic via ⋯
  await p.hover('[data-tid="t2"] .tdt'); await p.click('[data-tid="t2"] .tdmore2'); await p.waitForTimeout(150);
  await p.click('#menu .tdcatm'); await p.waitForTimeout(200); console.log('t2 now', await E(() => JSON.stringify(todoAll().find(x => x.id === 't2'))));
  // edit + delete subtopic
  await p.click('.tdfbtn[data-act="todo-fmenu"]'); await p.waitForTimeout(150); await p.click('#menu .tdcated'); await p.waitForTimeout(200);
  console.log('edit dlg', await E(() => [$('#tdcatn').value, $('#tdcatp').selectedOptions[0].text]));
  await p.click('[data-act="todo-catdel"]'); await p.waitForTimeout(300);
  console.log('after del', await E(() => [JSON.stringify(S.settings.todoCats), JSON.stringify(todoAll().find(x => x.id === 't2')), $('#toast').innerText]));
  await shot('final');
};
