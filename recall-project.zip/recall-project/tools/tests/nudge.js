// The "new app version" bar: shows on an older shell once GitHub has a newer release; Later hides it.
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const out = {};
  for (const shell of ['1.27.0', '1.28.0']){
    const ctx = await b.newContext({ viewport: { width: 1400, height: 900 } }), p = await ctx.newPage(), errs = [];
    p.on('pageerror', e => errs.push(e.message));
    await ctx.route(/api\.github\.com/, r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ tag_name: 'v1.28.0', assets: [{ name: 'Recall-mac.zip' }, { name: 'Recall-windows.zip' }] }) }));
    const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
    await p.addInitScript(([lib, shell]) => { const db = JSON.parse(lib); window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell, build: '1', updated: true }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async () => true, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, [lib, shell]);
    await p.goto('file://' + path.resolve(__dirname, '../../app/app/index.html')); await p.waitForTimeout(1200);
    await p.evaluate(() => shellNudge()); await p.waitForTimeout(400);
    out[shell] = await p.evaluate(() => ({ bar: $('.shellbar')?.innerText.replace(/\n+/g, ' | '), href: $('.shellbar a')?.href }));
    if (shell === '1.27.0'){ await p.screenshot({ path: 'nudge.png' }); await p.click('[data-act="shell-later"]'); await p.evaluate(() => shellNudge()); await p.waitForTimeout(300); out.afterLater = await p.evaluate(() => !!$('.shellbar')); }
    out[shell + ' errors'] = errs; await ctx.close();
  }
  console.log(JSON.stringify(out, null, 1)); await b.close();
})();
