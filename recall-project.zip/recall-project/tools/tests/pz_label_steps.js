// a drawn box's name sticks while you mark it (Wrong, marks +/-, why), through click-off, and onto the card
module.exports = async (p, E, shot) => {
  await E(() => ls.set('md-pp-cardpos', { r: innerWidth - 250, t: innerHeight - 140 }));   // the marking card out of the way, bottom left
  await E(() => { const node = Object.values(S.nodes).find(n => n.parentId && !kids(n.id).length) || Object.values(S.nodes).find(n => !kids(n.id).length) || Object.values(S.nodes)[0]; ppm.node = node.id; });
  await E(() => { ppm.draw = 'q'; ppmSide(); }); await p.waitForTimeout(200);
  const r = await E(() => { const o = $('#pppages .ppov[data-p="1"]').getBoundingClientRect(); return { x: o.left + o.width * .55, y: o.top + o.height * .45 }; });
  await p.mouse.move(r.x, r.y); await p.mouse.down(); await p.mouse.move(r.x + 120, r.y + 60, { steps: 6 }); await p.mouse.up(); await p.waitForTimeout(800);
  const st = () => E(() => ({ input: $('#pplabel')?.value, sel: ppm.sel, rail: ppm.items[ppm.sel]?.label }));
  console.log('drawn', JSON.stringify(await st()));
  await p.fill('#pplabel', ''); await p.keyboard.type('Q3 projectile 2b'); await p.waitForTimeout(100);
  await p.click('[data-act="pp-res"][data-v="bad"]'); await p.waitForTimeout(300); console.log('after Wrong', JSON.stringify(await st()));
  await p.click('[data-act="pp-of"][data-d="1"]'); await p.click('[data-act="pp-of"][data-d="1"]'); await p.click('[data-act="pp-got"][data-d="1"]').catch(() => {}); await p.waitForTimeout(300); console.log('after marks', JSON.stringify(await st()));
  await p.click('#ppwhy'); await p.keyboard.type('forgot components'); await p.waitForTimeout(100);
  // click off and back
  await E(() => ppmUnpick()); await p.waitForTimeout(200); const i = await E(() => ppm.items.findIndex(x => x.man)); await E(i => ppmPick(i), i); await p.waitForTimeout(300);
  console.log('after off+back', JSON.stringify(await st()), await E(() => $('#ppwhy')?.value));
  // typing 3 in the name doesn't mark it; Enter just finishes typing
  await p.click('#pplabel'); await p.keyboard.press('End'); await p.keyboard.type(' (3)'); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  console.log('typed 3 + Enter', JSON.stringify(await st()), await E(() => [ppm.res, document.activeElement?.id]));
  await shot('label');
  await p.click('.ppsave'); await p.waitForTimeout(1500);
  console.log('saved', await E(() => { const pp = ppmP(), it = pp.man?.[0], q = pp.q?.[it?.key], c = q && S.cards[q.card]; return JSON.stringify({ man: it?.label, card: c?.label, src: c?.source, rail: [...document.querySelectorAll('#pprail .ppsq span:first-child')].map(x => x.textContent).filter(t => /Q3 proj/.test(t)) }); }));
};
