import os as _o
ROOT = _o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))
s=open(ROOT + '/src/mistake-deck.html').read()
def rep(a,b,count=1):
    global s
    n=s.count(a); assert n==count, (n,a[:70]); s=s.replace(a,b)
FONTS = '''<style>
@font-face{font-family:"Inter";font-style:normal;font-weight:400;font-display:swap;src:url(fonts/inter-latin-400-normal.woff2) format("woff2")}
@font-face{font-family:"Inter";font-style:normal;font-weight:500;font-display:swap;src:url(fonts/inter-latin-500-normal.woff2) format("woff2")}
@font-face{font-family:"Inter";font-style:normal;font-weight:600;font-display:swap;src:url(fonts/inter-latin-600-normal.woff2) format("woff2")}
@font-face{font-family:"Inter";font-style:normal;font-weight:700;font-display:swap;src:url(fonts/inter-latin-700-normal.woff2) format("woff2")}
@font-face{font-family:"Inter";font-style:normal;font-weight:800;font-display:swap;src:url(fonts/inter-latin-800-normal.woff2) format("woff2")}
@font-face{font-family:"Source Serif 4";font-style:normal;font-weight:400;font-display:swap;src:url(fonts/source-serif-4-latin-400-normal.woff2) format("woff2")}
@font-face{font-family:"Source Serif 4";font-style:normal;font-weight:600;font-display:swap;src:url(fonts/source-serif-4-latin-600-normal.woff2) format("woff2")}
[hidden]{display:none!important} img{max-width:100%}
body.desktop .toolbar{padding-left:max(84px,env(safe-area-inset-left,0px))}
body.desktop .toolbar::before{content:"";position:absolute;top:0;left:0;right:0;height:52px;-webkit-app-region:drag;pointer-events:none}
body.desktop .toolbar button{-webkit-app-region:no-drag}
body.desktop{user-select:none;-webkit-user-select:none}
body.desktop input,body.desktop textarea,body.desktop .qa,body.desktop .stext,body.desktop .qtext{user-select:text;-webkit-user-select:text}
</style>'''
start = s.index('<link rel="preconnect" href="https://fonts.googleapis.com">')
end = s.index('&display=swap">') + len('&display=swap">')
s = s[:start] + FONTS + s[end:]
rep('<script src="https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js" async></script>', '<script src="mathjax/tex-svg.js" async></script>')
rep("function imgSrc(o){ return o ? (o.file ? cloudImg(o.file) : (o.url || (o.id ? '/_blob/' + o.id : o.data))) : ''; }",
    "function imgSrc(o){ return o ? (o.file ? 'errimg://img/' + encodeURIComponent(o.file) : (o.url || (o.id ? '/_blob/' + o.id : o.data))) : ''; }")
rep("async function initStore(){\n", """async function initStore(){
  if (window.desktop){
    S.mode = 'desktop'; document.body.classList.add('desktop'); document.documentElement.classList.add('desktop'); if (ls.get('md-sidebar-hidden', false)) document.body.classList.add('sidebar-hidden'); window.desktop.onToggleSidebar?.(() => toggleSidebar()); if (window.desktop.platform === 'win32') winSetup(); window.desktop.onImportFile?.(p => startImport(new File([p.bytes], p.name))); window.desktop.onMenu?.(k => k === 'import' ? pickImportFile() : exportDialog(null)); window.desktop.onUndo?.(() => { if (isTyping(document.activeElement)) document.execCommand('undo'); else if (!cleanerOpen()){ undoTx = null; appUndo(); } }); window.desktop.onRedo?.(() => { if (isTyping(document.activeElement)) document.execCommand('redo'); else if (!cleanerOpen()){ undoTx = null; appRedo(); } });
    window.desktop.onLibraryChanged?.(async () => { try { const d = await window.desktop.load(); const oN = S.nodes, oC = S.cards; S.nodes = d.nodes || {}; S.cards = d.cards || {}; cloudDiff(oN, oC); if (d.settings) S.settings = { ...S.settings, ...d.settings }; if (view.name === 'study' && study){ if (study.cur && !S.cards[study.cur]) nextCard(); renderStudy(); } else if (!dialogOpen()) render(); toast('Library updated'); } catch (e) { console.error(e); } });
    try { const d = await window.desktop.load(); S.nodes = d.nodes || {}; S.cards = d.cards || {}; if (d.settings) S.settings = { ...S.settings, ...d.settings }; }
    catch { toast('Could not open your library.', 5000); }
    S.ready = true; render(); return;
  }
""")
rep("""  if (S.mode === 'db'){ try { await S.db.collection(coll).doc(id).set(body); return true; } catch (e) { writeFail(e); return false; } }
  saveLocal(); return true;""", """  if (S.mode === 'db'){ try { await S.db.collection(coll).doc(id).set(body); return true; } catch (e) { writeFail(e); return false; } }
  if (S.mode === 'desktop'){ try { await window.desktop.put(coll, id, body); return true; } catch { toast('Could not save that change to disk.', 4000); return false; } }
  saveLocal(); return true;""")
rep("""  if (S.mode === 'db'){ try { await S.db.collection(coll).doc(id).delete(); } catch (e) { writeFail(e); } } else saveLocal();
}""", """  if (S.mode === 'db'){ try { await S.db.collection(coll).doc(id).delete(); } catch (e) { writeFail(e); } }
  else if (S.mode === 'desktop'){ try { await window.desktop.del(coll, id); } catch { toast('Could not save that change to disk.', 4000); } }
  else saveLocal();
}
async function dropImages(c){
  for (const im of [c.qImg, ...(c.solImgs||[])]){
    if (!im) continue;
    if (im.file && S.mode === 'desktop'){ try { await window.desktop.deleteImage(im.file); } catch {} }
    else if (im.id && S.assets){ try { await S.assets.delete(im.id); } catch {} }
  }
}""")
rep("async function saveSettings(){ if (S.mode === 'db'){ try { await S.db.doc('meta/settings').set(S.settings); } catch (e) { writeFail(e); } } else saveLocal(); }",
    "async function saveSettings(){ if (S.mode === 'db'){ try { await S.db.doc('meta/settings').set(S.settings); } catch (e) { writeFail(e); } } else if (S.mode === 'desktop'){ try { await window.desktop.settings(S.settings); } catch {} } else saveLocal(); }")
s = s.replace("if (S.assets) for (const im of [c.qImg, ...(c.solImgs||[])]) if (im?.id) { try { await S.assets.delete(im.id); } catch {} }", "await dropImages(c);")
rep("""  try {
    if (S.assets){""", """  try {
    if (S.mode === 'desktop'){
      const c = draw(im, keepPng ? 3200 : 2200);
      let blob = keepPng ? null : await new Promise(r => c.toBlob(r, 'image/webp', 0.92)), ext = 'webp';
      if (!blob || blob.type !== 'image/webp'){ blob = await new Promise(r => c.toBlob(r, 'image/png')); ext = 'png'; }
      const r = await window.desktop.saveImage(await blob.arrayBuffer(), ext); return { file: r.file };
    }
    if (S.assets){""")
rep("""case 'del-card': { const c = ed.card;""", """case 'del-card': { const c = ed.card;""")
s = '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<meta http-equiv="Content-Security-Policy" content="default-src \'self\'; img-src \'self\' errimg: data: blob:; style-src \'self\' \'unsafe-inline\'; script-src \'self\' \'unsafe-inline\' \'unsafe-eval\' blob: https://cdn.jsdelivr.net; worker-src \'self\' blob: https://cdn.jsdelivr.net; font-src \'self\' data:; connect-src \'self\' blob: data: errimg: https://*.supabase.co wss://*.supabase.co https://cdn.jsdelivr.net https://raw.githubusercontent.com https://api.github.com">\n</head>\n<body>\n' + s + '\n</body>\n</html>\n'
import json as _j
_FAM = {'space-grotesk':'Space Grotesk','dm-sans':'DM Sans','atkinson-hyperlegible':'Atkinson Hyperlegible','lora':'Lora','quicksand':'Quicksand','lexend':'Lexend','poppins':'Poppins','outfit':'Outfit','ibm-plex-sans':'IBM Plex Sans','nunito':'Nunito','merriweather':'Merriweather','jetbrains-mono':'JetBrains Mono','plus-jakarta-sans':'Plus Jakarta Sans','source-sans-3':'Source Sans 3','cmu-serif':'CMU Serif'}
_man = _j.load(open(ROOT + '/tools/fonts.json'))
s = s.replace('</style>', ''.join("@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:swap;src:url(fonts/%s-%d.woff2) format('woff2')}\n" % (_FAM[k], w, k, w) for k, ws in sorted(_man.items()) for w in ws) + '</style>', 1)
import os as _os, json as _js
_cf = ROOT + '/tools/cloud.json'
if _os.path.exists(_cf):
    _c = _js.load(open(_cf)); s = s.replace("'__CLOUD_URL__'", "'" + _c['url'] + "'").replace("'__CLOUD_KEY__'", "'" + _c['key'] + "'")
open(ROOT + '/app/app/index.html','w').write(s)
import re
print('ok')
