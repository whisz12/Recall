// Back with Esc / Alt+← / ⌘←, forward with ⌘→. node navk_t.js
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8793);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport: { width: 1400, height: 900 } }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
  await p.goto('http://127.0.0.1:8793/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), where = () => E(() => view.name + (view.node ? ':' + nodeOf(view.node)?.name : ''));
  const ids = await E(() => { const s = kids(null)[0], t = kids(s.id)[0], u = t && kids(t.id)[0]; return [s.id, t?.id, u?.id]; });
  await E(([s, t, u]) => { go('overview', s); go('overview', t); if (u) go('overview', u); }, ids);
  console.log('at', await where());
  await p.keyboard.press('Escape'); console.log('Esc ->', await where());
  await p.keyboard.press('Alt+ArrowLeft'); console.log('Alt+Left ->', await where());
  await p.keyboard.press('Meta+ArrowRight'); console.log('Cmd+Right ->', await where());
  await p.keyboard.press('Meta+ArrowLeft'); console.log('Cmd+Left ->', await where());
  await E(() => { navH.back = []; navH.fwd = []; }); await E(id => go('overview', id), ids[2] || ids[1]); await E(() => { navH.back = []; });
  await p.keyboard.press('Escape'); console.log('no history, Esc goes up ->', await where());
  await E(() => go('decks')); await E(() => { navH.back = []; }); await p.keyboard.press('Escape'); console.log('Today, Esc stays ->', await where());
  await E(() => go('browse')); await p.click('#sidesq').catch(() => {}); await p.keyboard.press('Meta+ArrowLeft'); console.log('typing, Cmd+Left stays ->', await where());
  console.log('errors:', errs.length ? errs : 'none'); await b.close(); srv.close();
})();
