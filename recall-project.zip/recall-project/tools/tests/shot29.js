const { chromium } = require('playwright'); const fs=require('fs');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1400, height: 950 } });
  const errs=[]; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type()==='error' && !/errimg|ERR_UNKNOWN|supabase|net::/.test(m.text())) errs.push(m.text()); });
  const lib = fs.readFileSync(require('path').join(__dirname, 'lib20.json'),'utf8');
  await p.addInitScript(lib => { const db = JSON.parse(lib); window.desktop = { platform:'darwin', load: async()=>db, put: async()=>true, del: async()=>{}, settings: async()=>{}, saveImage: async()=>({file:'x.png'}), deleteImage: async()=>{}, onToggleSidebar(){}, onLibraryChanged(){} }; window.supabase = { createClient(){ return { auth: { async getSession(){ return { data: { session: null } }; }, onAuthStateChange(){} } }; } }; }, lib);
  await p.goto('file://' + require('path').resolve(__dirname, '../../app/app/index.html')); await p.waitForTimeout(1200);
  const E = (f, a) => p.evaluate(f, a);
  // ---- browse nav
  await E(() => go('browse')); await p.waitForTimeout(300);
  await p.click('.btable tbody tr:nth-child(1) td:nth-child(3)'); await p.waitForTimeout(300);
  const ids = await E(() => browse.ids.slice(0, 3));
  console.log('opened', await E(() => ed.card.id) === ids[0], 'nav:', await p.textContent('.ednavn'));
  await p.keyboard.press('ArrowDown'); await p.waitForTimeout(200);
  console.log('after ↓ on 2nd:', await E(() => ed.card.id) === ids[1], await p.textContent('.ednavn'));
  await p.screenshot({ path: 'nav1.png' });
  await p.fill('#elabel', 'EDITED-X'); await p.locator('#elabel').blur?.(); await E(() => document.activeElement.blur());
  await p.keyboard.press('ArrowDown'); await p.waitForTimeout(300);
  console.log('autosaved label:', await E(i => S.cards[i].label, ids[1]), '| now on 3rd:', await E(() => ed.card.id) === ids[2]);
  await p.click('[data-act="ednav"][data-dir="-1"]'); await p.waitForTimeout(200);
  console.log('header ↑ back to 2nd:', await E(() => ed.card.id) === ids[1]);
  await p.click('#eq'); await p.keyboard.press('ArrowDown'); console.log('arrow inside textbox stays:', await E(() => ed.card.id) === ids[1]);
  await p.keyboard.press('Escape'); await p.waitForTimeout(200); console.log('closed:', await E(() => !ed));
  // ---- pad
  const cid = await E(() => Object.values(S.cards).find(c => c.qImg && c.qText)?.id || Object.values(S.cards).find(c => c.qImg).id);
  await E(i => { startStudy(null, true, i); padToggle(true); }, cid); await p.waitForTimeout(400);
  const box = await p.locator('#pad').boundingBox();
  const draw = async pts => { await p.mouse.move(box.x + pts[0][0], box.y + pts[0][1]); await p.mouse.down(); for (const q of pts.slice(1)) await p.mouse.move(box.x + q[0], box.y + q[1], { steps: 2 }); await p.mouse.up(); };
  await draw([[60, 80], [120, 90], [180, 75], [240, 85]]);
  await draw([[60, 160], [100, 140], [140, 165], [180, 150], [220, 160]]);  // wavy writing, should stay
  console.log('strokes after writing:', await E(() => pad.strokes.length));
  const scr = []; for (let k = 0; k < 8; k++) scr.push([50 + (k % 2) * 200 + k * 3, 70 + k * 3]); await draw(scr);
  console.log('after scribble over first line:', await E(() => pad.strokes.length), 'last op:', await E(() => pad.hist[pad.hist.length - 1].t));
  await E(() => padUndo()); console.log('undo scribble ->', await E(() => pad.strokes.length));
  const scr2 = []; for (let k = 0; k < 8; k++) scr2.push([400 + (k % 2) * 150, 250 + k * 4]); await draw(scr2);
  console.log('scribble on empty paper kept as ink:', await E(() => pad.strokes.length));
  await p.mouse.move(box.x + 300, box.y + 120);
  await p.click('[data-pad="eraser"]'); await p.mouse.move(box.x + 310, box.y + 125);
  console.log('ring:', await E(() => { const r = $('#padcur'); return r.style.display + ' ' + r.style.width; }), 'bg:', await E(() => getComputedStyle($('#pad')).backgroundColor));
  await p.screenshot({ path: 'pad1.png' });
  // finger double-tap swap
  await E(() => { pad.penSeen = true; const cv = $('#pad'), r = cv.getBoundingClientRect(); const ev = (t, id) => cv.dispatchEvent(new PointerEvent(t, { pointerType: 'touch', pointerId: id, clientX: r.left + 200, clientY: r.top + 200, bubbles: true }));
    ev('pointerdown', 11); ev('pointerup', 11); ev('pointerdown', 12); ev('pointerup', 12); });
  console.log('double tap -> tool:', await E(() => pad.tool));
  await E(() => { pad.penSeen = false; });
  // full screen
  await p.click('[data-pad="full"]'); await p.waitForTimeout(400);
  console.log('full:', await E(() => !!$('#padwrap.full')), 'q imgs in panel:', await p.$$eval('#padq img', i => i.length), 'strokes kept:', await E(() => pad.strokes.length));
  await p.screenshot({ path: 'full1.png' });
  await p.keyboard.press('Space'); await p.waitForTimeout(400);
  console.log('answer in panel:', await E(() => !!$('#padq .answer')), 'rate btns:', await p.$$eval('.padfoot [data-act="rate"]', b => b.length));
  await p.screenshot({ path: 'full2.png' });
  await p.setViewportSize({ width: 820, height: 1180 }); await p.waitForTimeout(400); await p.screenshot({ path: 'full3.png' });
  await p.setViewportSize({ width: 1400, height: 950 }); await p.waitForTimeout(200);
  await p.keyboard.press('Escape'); await p.waitForTimeout(300); console.log('esc exits full:', await E(() => !$('#padwrap.full') && !!$('#padwrap')), 'still study:', await E(() => view.name));
  console.log('errors', errs); await b.close();
})();
