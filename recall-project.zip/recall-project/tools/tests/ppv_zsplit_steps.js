// side by side: each side zooms on its own (pinch/ctrl-wheel over it, the bar's +/−/0 and keys work on the side last touched)
module.exports = async (p, E, shot) => {
  const sol = [...require('fs').readFileSync('/home/claude/papers/p01sol.pdf')];
  const pid = await E(() => ppm.pid);
  await E(async ([pid, sol]) => { const f = new File([new Uint8Array(sol)], 'Premiere X2 Solutions.pdf', { type: 'application/pdf' }); const q = await ppSolStore(ppPapers()[pid], f); await ppSavePaper(q, 'add solutions'); ppm = null; go('papers'); setTimeout(() => go('ppmark', pid), 50); }, [pid, sol]);
  await p.waitForFunction(() => ppm?.items?.length > 0 && !ppm.busy, null, { timeout: 120000 });
  await E(() => ppSplitSet(true)); await p.waitForTimeout(800);
  const st = () => E(() => ({ q: ppz, s: ppzS, wq: $('#pppages .pppage').clientWidth, ws: $('#ppsolpages .pppage').clientWidth, label: $('#ppzl').textContent }));
  const log = async n => console.log(JSON.stringify([n, await st()]));
  await log('start');
  const box = async sel => { const r = await (await p.$(sel)).boundingBox(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; };
  const a = await box('#ppscroll'), b = await box('#ppsolscroll');
  await p.mouse.move(a.x, a.y); for (let i = 0; i < 4; i++){ await p.keyboard.down('Control'); await p.mouse.wheel(0, -60); await p.keyboard.up('Control'); } await p.waitForTimeout(500); await log('pinch paper');
  await p.mouse.move(b.x, b.y); for (let i = 0; i < 6; i++){ await p.keyboard.down('Control'); await p.mouse.wheel(0, -60); await p.keyboard.up('Control'); } await p.waitForTimeout(500); await log('pinch solutions');
  await p.mouse.click(a.x, a.y); await E(() => document.activeElement?.blur()); await p.keyboard.press('-'); await p.waitForTimeout(400); await log('click paper, minus key');
  await p.mouse.click(b.x, b.y); await p.click('#ppzbar [data-act="pp-zoom"][data-d="0"]'); await p.waitForTimeout(400); await log('click solutions, fit button');
  await shot('zsplit');
  await E(() => ppSplitSet(false)); await p.waitForTimeout(500); console.log(JSON.stringify(['split off', await E(() => ({ q: ppz, label: $('#ppzl').textContent, wq: $('#pppages .pppage').clientWidth }))]));
  await p.keyboard.press('='); await p.waitForTimeout(300); console.log(JSON.stringify(['plus key, not split', await E(() => ({ q: ppz, s: ppzS }))]));
  await E(() => ppSplitSet(true)); await p.waitForTimeout(500); await log('split back on (remembered)');
};
