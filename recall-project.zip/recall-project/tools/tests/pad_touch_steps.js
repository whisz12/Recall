module.exports = async (p, E, shot, ctx) => {
  await E(() => { document.documentElement.classList.add('iosapp'); document.documentElement.style.setProperty('--sat', '56px'); });
  await E(() => { undoMute = true; saveTheme({ ...themeSettings(), base: 'harness', mode: 'fixed' }); undoMute = false; render(); });
  await E(() => { const id = Object.keys(S.cards)[0]; startStudy(null, true, null, [id]); }); await p.waitForTimeout(800);
  await E(() => padToggle(true)); await p.waitForTimeout(600);
  await E(() => padAction('more')); await E(() => padAction('more')); await p.waitForTimeout(300);
  await shot('a');
  await E(() => window.scrollTo(0, 700)); await p.waitForTimeout(300);
  console.log('after scroll', await E(() => ({ y: scrollY, bar: $('#padwrap .padbar').getBoundingClientRect().top, padtop: $('#padwrap').style.getPropertyValue('--padtop'), ab: $('#answerbar') ? getComputedStyle($('#answerbar')).display : 'none' })));
  await shot('b');
  // two-finger pan on the canvas (finger mode)
  const cdp = await ctx.newCDPSession(p); const r = await (await p.$('#pad')).boundingBox();
  const x = r.x + 200, y = Math.min(r.y + r.height - 100, 600);
  const T = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((q, i) => ({ x: q[0], y: q[1], id: i })) });
  const before = await E(() => [scrollY, pad.strokes.length]);
  await T('touchStart', [[x, y]]); await T('touchMove', [[x, y + 5]]); await T('touchStart', [[x, y + 5], [x + 80, y]]);
  for (let i = 1; i <= 10; i++) await T('touchMove', [[x, y + 5 - i * 20], [x + 80, y - i * 20]]);
  await T('touchEnd', []); await p.waitForTimeout(200);
  console.log('2-finger', before, await E(() => [scrollY, pad.strokes.length]));
  // one finger still draws
  await T('touchStart', [[x, y]]); for (let i = 1; i <= 5; i++) await T('touchMove', [[x + i * 20, y]]); await T('touchEnd', []);
  console.log('1-finger draw', await E(() => [scrollY, pad.strokes.length]));
  // full screen
  await E(() => padAction('full')); await p.waitForTimeout(500); await shot('c');
  const r2 = await (await p.$('#pad')).boundingBox(); const fx = r2.x + 150, fy = r2.y + 300;
  const b2 = await E(() => [$('#padscroll').scrollTop, $('#padscroll').scrollHeight, $('#padscroll').clientHeight]);
  await T('touchStart', [[fx, fy], [fx + 80, fy]]); for (let i = 1; i <= 10; i++) await T('touchMove', [[fx, fy - i * 20], [fx + 80, fy - i * 20]]); await T('touchEnd', []);
  console.log('full 2-finger', b2, await E(() => $('#padscroll').scrollTop));
  console.log('fullrect', await E(() => JSON.stringify($('#padwrap').getBoundingClientRect())), await E(() => getComputedStyle($('#padwrap .padbar')).paddingTop));
};
