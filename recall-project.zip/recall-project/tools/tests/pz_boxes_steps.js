// more than one box per question: Add a box (next page), Redraw (just the hard part), remove one box, solution extra box, card pictures
module.exports = async (p, E, shot) => {
  await E(() => ls.set('md-pp-cardpos', { r: innerWidth - 250, t: innerHeight - 140 }));
  const st = () => E(() => { const it = ppm.items[ppm.sel], pp = ppmP(); return { sel: ppm.sel, label: it?.label, segs: it?.segs?.map(g => g.p).join(','), draw: ppm.draw, mseg: (pp.mseg?.[it?.key] || []).length, row: $('.ppboxrow')?.innerText.replace(/\n/g, ' | '), x: document.querySelectorAll('[data-act="pp-segdel"]').length }; });
  const log = async n => console.log(JSON.stringify([n, await st()]));
  const drag = async (page, fx, fy, w = 140, h = 50) => { const r = await E(([pg, fx, fy]) => { const o = $(`#pppages .ppov[data-p="${pg}"]`); o.scrollIntoView({ block: 'center' }); const b = o.getBoundingClientRect(); return { x: b.left + b.width * fx, y: b.top + b.height * fy }; }, [page, fx, fy]); await p.waitForTimeout(300);
    const r2 = await E(([pg, fx, fy]) => { const b = $(`#pppages .ppov[data-p="${pg}"]`).getBoundingClientRect(); return { x: b.left + b.width * fx, y: b.top + b.height * fy }; }, [page, fx, fy]);
    await p.mouse.move(r2.x, r2.y); await p.mouse.down(); await p.mouse.move(r2.x + w, r2.y + h, { steps: 6 }); await p.mouse.up(); await p.waitForTimeout(600); };
  await p.click('#pprail .ppsq[data-i="0"]'); await p.waitForTimeout(500); await log('picked');
  await shot('box0');
  await p.click('#pppanel [data-act="pp-draw"][data-v="a"]'); await p.waitForTimeout(200); await log('add mode');
  await drag(2, .2, .3); await log('added page 2');
  await drag(2, .2, .6); await log('added another');
  await shot('box1');
  await p.click('#pppanel [data-act="pp-draw"][data-v="a"]'); await p.waitForTimeout(200); await log('done');
  await p.waitForTimeout(200); await shot('box2');
  await p.click('[data-act="pp-segdel"] >> nth=1'); await p.waitForTimeout(400); await log('removed one box');
  await p.click('#pppanel [data-act="pp-draw"][data-v="r"]'); await drag(1, .3, .5, 160, 40); await log('redrawn');
  console.log('done btn:', await E(() => { const b = $('.ppboxrow .btn'); if (!b) return 'none'; const r = b.getBoundingClientRect(); return [b.dataset.v, Math.round(r.top), Math.round(r.bottom), innerHeight, getComputedStyle(b).visibility]; }));
  await drag(2, .3, .2, 160, 40); await E(() => { ppm.draw = null; ppmSide(); }); await log('redraw + one more');
  // mark wrong and save: card gets one picture per box
  await E(() => document.activeElement?.blur()); await p.keyboard.press('3'); await p.waitForTimeout(200);
  await E(() => { ppm.node = kids(null)[1].id; });
  await p.click('#pppanel [data-act="pp-save"]'); await p.waitForTimeout(2500);
  console.log(JSON.stringify(['card', await E(() => { const pp = ppmP(), q = Object.values(pp.q || {})[0], c = q && S.cards[q.card]; return c ? { imgs: (c.qImgs || [c.qImg]).filter(Boolean).length } : 'none'; })]));
  // change boxes after the card exists: re-saving updates the pictures
  await E(() => ppmPick(0)); await p.waitForTimeout(400); await p.click('#pppanel [data-act="pp-draw"][data-v="a"]'); await drag(1, .3, .8, 160, 40); await E(() => { ppm.draw = null; ppmSide(); });
  await p.click('#pppanel [data-act="pp-save"]'); await p.waitForTimeout(2500);
  console.log(JSON.stringify(['card updated', await E(() => { const pp = ppmP(), q = Object.values(pp.q || {})[0], c = q && S.cards[q.card]; return c ? { imgs: (c.qImgs || [c.qImg]).filter(Boolean).length } : 'none'; })]));
  // reopen keeps the boxes
  const pid = await E(() => ppm.pid); await E(() => go('papers')); await p.waitForTimeout(400); await E(pid => { ppm = null; go('ppmark', pid); }, pid);
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(900); await E(() => ppmPick(ppm.items.findIndex(x => x.label === 'Q1'))); await p.waitForTimeout(300); await log('reopened'); await shot('box3');
};
