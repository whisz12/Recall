module.exports = async (p, E, shot) => {
  const M = !!process.env.MOBILE;
  await E(() => startStudy(kids(null)[0].id, true)); await p.waitForTimeout(800);
  const st = () => E(() => ({ cur: study.cur, n: Object.keys(S.cards).length, left: study.queue.length, shown: study.shown, dlg: !!document.querySelector('#layer .dialog') }));
  const a = await st(); console.log('start', JSON.stringify(a)); await shot('bar');
  const btn = M ? '#answerbar [data-act="study-del"]' : '#appbar [data-act="study-del"]';
  console.log('button', await E(s => { const b = document.querySelector(s), r = b?.getBoundingClientRect(); return b ? [Math.round(r.width), Math.round(r.height), getComputedStyle(b).display] : null; }, btn));
  // cancel keeps it
  await p.click(btn); await p.waitForTimeout(300); await shot('dlg'); await p.click('#layer [data-act="close"]'); await p.waitForTimeout(200);
  console.log('cancel', JSON.stringify(await st()), 'same', (await st()).cur === a.cur);
  // delete after showing the answer
  await E(() => showAnswer()); await p.waitForTimeout(400);
  await p.click(btn); await p.waitForTimeout(300); await p.click('#layer [data-act="do-del-card"]'); await p.waitForTimeout(600);
  const b = await st(); console.log('deleted', JSON.stringify(b), 'gone', await E(id => !S.cards[id], a.cur), 'moved on', b.cur !== a.cur, 'toast', await E(() => $('#toast').textContent));
  await shot('after');
  if (!M){
    await p.keyboard.press('Meta+z'); await p.waitForTimeout(600);
    const c = await st(); console.log('undo', JSON.stringify(c), 'back as current', c.cur === a.cur, 'next kept', await E(id => study.queue[0] === id, b.cur));
    // X key, Enter confirms; then rate next card; ⌘Z now is plain back, card stays deleted
    await p.keyboard.press('x'); await p.waitForTimeout(300); await p.keyboard.press('Enter'); await p.waitForTimeout(600);
    const d = await st(); console.log('x+enter', JSON.stringify(d), 'gone', await E(id => !S.cards[id], a.cur));
    await E(() => showAnswer()); await p.waitForTimeout(300); await E(() => rate(3)); await p.waitForTimeout(800);
    await p.keyboard.press('Meta+z'); await p.waitForTimeout(600);
    console.log('after rating, undo = back', JSON.stringify(await st()), 'still gone', await E(id => !S.cards[id], a.cur));
  }
  // delete every card left: ends cleanly
  for (let i = 0; i < 400; i++){ const id = await E(() => study?.cur); if (!id) break; await E(async id => { await del('cards', id); studyAfterDel(id); }, id); }
  await p.waitForTimeout(400); console.log('end', JSON.stringify(await E(() => ({ view: view.name, cur: study?.cur, txt: $('#root').innerText.slice(0, 80).replace(/\n+/g, ' | ') })))); await shot('end');
};
