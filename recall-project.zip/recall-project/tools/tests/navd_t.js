// Back/forward group beside the sidebar button: Mac app (file://) and iPad web, sidebar showing and hidden. node navd_t.js
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
(async () => {
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8794);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  for (const kind of ['mac', 'ipad']){
    const ctx = await b.newContext(kind === 'mac' ? { viewport: { width: 1400, height: 900 }, deviceScaleFactor: 2, colorScheme: 'dark' } : { viewport: { width: 1180, height: 820 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true, colorScheme: 'dark' });
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
    if (kind === 'mac'){ await p.addInitScript(lib => { const db = JSON.parse(lib); window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.27.0', build: '20261102003633', updated: false }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async () => true, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, lib);
      await p.goto('file://' + path.resolve(__dirname, '../../app/app/index.html')); }
    else { await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib); await p.goto('http://127.0.0.1:8794/'); }
    await p.waitForTimeout(1500);
    const E = (f, a) => p.evaluate(f, a), st = () => E(() => [view.name + (view.node ? ':' + nodeOf(view.node)?.name : ''), $('[data-act="hist-back"]').disabled, $('[data-act="hist-fwd"]').disabled]);
    console.log(kind, 'classes', await E(() => document.documentElement.className + ' | ' + document.body.className));
    console.log(kind, 'start', await st());
    await E(() => { const s = kids(null)[0], t = kids(s.id)[0]; go('overview', s.id); go('overview', t.id); });
    console.log(kind, 'two deep', await st()); await p.screenshot({ path: `/tmp/navd_${kind}_s.png`, clip: { x: 0, y: 0, width: 800, height: 140 } });
    await p.click('[data-act="hist-back"]'); console.log(kind, 'back', await st());
    await p.click('[data-act="hist-fwd"]'); console.log(kind, 'fwd', await st());
    await p.click('#navcl [data-act="toggle-sidebar"]'); await p.waitForTimeout(400); await p.screenshot({ path: `/tmp/navd_${kind}_h.png`, clip: { x: 0, y: 0, width: 800, height: 140 } });
    const ov = await E(() => { const a = $('#navcl').getBoundingClientRect(), t = $('#abt').getBoundingClientRect(); return [Math.round(a.right), Math.round(t.left)]; }); console.log(kind, 'hidden: group ends / title starts', ov);
    await p.click('#navcl [data-act="toggle-sidebar"]'); await p.waitForTimeout(300);
    console.log(kind, 'errors', errs.length ? errs : 'none'); await ctx.close();
  }
  await b.close(); srv.close();
})();
