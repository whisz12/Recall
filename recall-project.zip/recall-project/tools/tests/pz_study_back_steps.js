module.exports = async (p, E, shot) => {
  await E(() => startStudy(kids(null)[0].id, true)); await p.waitForTimeout(800);
  const st = () => E(() => ({ cur: study.cur, shown: study.shown, done: study.done, hist: study.hist.length, back: (() => { const b = $('#answerbar .lhback'); const r = b.getBoundingClientRect(); return [b.disabled, Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)]; })(), bar: $('#answerbar').innerText.replace(/\n+/g, ' | ') }));
  const c0 = await st(); console.log('start', JSON.stringify(c0));
  await E(() => showAnswer()); await p.waitForTimeout(400); await E(() => rate(1)); await p.waitForTimeout(800);
  const c1 = await st(); console.log('after rating', JSON.stringify(c1)); await shot('q2');
  await p.tap('#answerbar .lhback'); await p.waitForTimeout(700);
  const c2 = await st(); console.log('after back', JSON.stringify(c2), 'same card as first:', c2.cur === c0.cur); await shot('back');
};
