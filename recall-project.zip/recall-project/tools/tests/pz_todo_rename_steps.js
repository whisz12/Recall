module.exports = async (p, E, shot) => {
  await E(() => { S.settings = { ...S.settings, todos: [{ id: 'a1', t: 'Task', s: null, done: 0, at: 1, l: 'today' }] }; todoTab = 'today'; go('todo'); }); await p.waitForTimeout(500);
  const tabs = () => E(() => [...document.querySelectorAll('#tdo .tdtabs > *')].map(b => (b.tagName === 'INPUT' ? '[' + b.value + ']' : b.classList.contains('tdtabadd') ? '+' : b.innerText.replace(/\n/g, ' ')) + (b.getAttribute('aria-selected') === 'true' ? '*' : '')).join(' | '));
  const T = k => `[data-act="todo-tab"][data-v="${k}"]`;
  await p.click(T('today')); await p.waitForTimeout(150); console.log('menu', await E(() => $('#menu')?.innerText.replace(/\n/g, ' / ')));
  await p.click('#menu [data-act="todo-tabren"]'); await p.waitForTimeout(150); await shot('ren'); await p.keyboard.type('Tonight <b>'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('renamed', await tabs(), JSON.stringify(await E(() => S.settings.todoNames)), 'tasks kept', await E(() => todoAll()[0].l));
  await p.click(T('all')); await p.waitForTimeout(100); await p.click(T('all'), { button: 'right' }); await p.waitForTimeout(150); await p.click('#menu [data-act="todo-tabren"]'); await p.waitForTimeout(100); await p.keyboard.type('Past papers'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('renamed 2', await tabs());
  await p.click(T('today')); await p.waitForTimeout(150); await p.hover('[data-tid="a1"] .tdt'); await p.click('[data-tid="a1"] .tdmore2'); await p.waitForTimeout(150);
  console.log('move menu', await E(() => $('#menu').innerText.split('\n').slice(0, 6).join(' / '))); await p.keyboard.press('Escape');
  await p.click(T('today')); await p.waitForTimeout(150); console.log('menu 2', await E(() => $('#menu')?.innerText.replace(/\n/g, ' / ')));
  await p.click('#menu [data-act="todo-tabreset"]'); await p.waitForTimeout(200); console.log('reset', await tabs(), JSON.stringify(await E(() => S.settings.todoNames)));
  await p.keyboard.press('Meta+z'); await p.waitForTimeout(300); console.log('undo', await tabs());
  // typing the original name clears the override; empty keeps the name
  await p.click(T('all')); await p.waitForTimeout(100); await p.click(T('all')); await p.waitForTimeout(100); await p.click('#menu [data-act="todo-tabren"]'); await p.keyboard.type('Revision'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  console.log('typed original', await tabs(), JSON.stringify(await E(() => S.settings.todoNames)));
  await p.dblclick('[data-act="todo-tab"][data-v="hw"]'); await p.waitForTimeout(250); await p.keyboard.type('Due this week'); await p.keyboard.press('Enter'); await p.waitForTimeout(200); console.log('dblclick', await tabs());
  await shot('end');
};
