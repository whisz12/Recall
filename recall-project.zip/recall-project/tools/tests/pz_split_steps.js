// NESA one-click papers with a mocked desktop.nesaGet (structure copied from NESA's real pages, 10 Nov 2026)
const fs = require('fs');
module.exports = async (p, E, shot) => {
  const exam = [...fs.readFileSync(__dirname + '/paper.pdf')], mg = [...fs.readFileSync(__dirname + '/NSB 2023 Physics Trial Solutions.pdf')];
  await E(({ exam, mg }) => {
    const B = 'https://www.nsw.gov.au/education-and-training/nesa/curriculum/hsc-exam-papers/', F = '/sites/default/files/noindex/2025-05/';
    const page = links => `<html><body><nav><a href="/x/2001">nav 2001</a></nav><main>${links.map(([t, h]) => `<p><a href="${h}">${t}</a></p>`).join('')}</main></body></html>`;
    const P = {
      'mathematics-advanced': page([['Mathematics HSC exam papers archive', '/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-archive'], ...[2026, 2025, 2024, 2023, 2022, 2021, 2020].map(y => [`Mathematics Advanced ${y} HSC exam pack`, `/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-advanced/${y}`])]),
      'mathematics-advanced/2024': page([['Mathematics Advanced HSC exam 2024 (PDF 2.14MB)', F + '2024-hsc-maths-adv.pdf'], ['Mathematics Advanced HSC marking guidelines 2024 (PDF 707.9KB)', F + '2024-hsc-maths-adv-mg.pdf'], ['Mathematics Advanced HSC marking feedback 2024 – Section II (PDF 340KB)', F + '2024-hsc-mathematics-adv-marking-feedback.pdf'], ['2026', B + 'mathematics-advanced/2026']]),
      'mathematics-advanced/2023': page([['Mathematics Advanced HSC exam 2023 (PDF 2MB)', F + '2023-hsc-maths-adv.pdf'], ['Mathematics Advanced HSC marking guidelines 2023 (PDF 700KB)', F + '2023-hsc-maths-adv-mg.pdf']]),
      'mathematics-advanced/2026': page([['Mathematics Advanced HSC exam paper 2026 (PDF 1.37MB)', '/sites/default/files/noindex/2026-10/2026-hsc-maths-advanced.pdf']]),
      'mathematics-archive': page([...[2019, 2018, 2017, 2016, 2015].map(y => [`Mathematics ${y} HSC exam pack (archive)`, `/education-and-training/nesa/curriculum/hsc-exam-papers/mathematics-archive/${y}`])]),
      'mathematics-archive/2019': page([['Mathematics HSC exam 2019 (PDF 1.62MB)', F + '2019-hsc-mathematics.pdf'], ['Mathematics HSC marking guidelines 2019 (PDF 982KB)', F + '2019-hsc-maths-mg.pdf']]),
      'english-advanced': page([['English Advanced HSC exam papers archive', B + 'english-advanced-archive'], ['English Advanced 2024 HSC exam pack', B + 'english-advanced/2024']]),
      'english-advanced/2024': page([['English Advanced HSC exam 2024 – Paper 1 (PDF 1.27MB)', '/sites/default/files/noindex/2025-07/2024-hsc-english-adv-paper-1-cc.pdf'], ['English Advanced HSC exam 2024 – Paper 2 (PDF 166KB)', F + '2024-hsc-english-adv-paper-2.pdf'], ['English Advanced HSC marking guidelines 2024 – Paper 1 (PDF 251KB)', F + '2024-hsc-english-adv-paper-1-mg.pdf'], ['English Advanced HSC marking guidelines 2024 – Paper 2 (PDF 203KB)', F + '2024-hsc-english-adv-paper-2-mg.pdf']]),
    };
    window.__nesa = []; window.__nesaFail = null;
    window.desktop.nesaGet = async url => {
      window.__nesa.push(url.replace(B, '~/').replace('https://www.nsw.gov.au', ''));
      if (window.__nesaFail && url.includes(window.__nesaFail)) throw new Error("Error invoking remote method 'nesa-get': Error: NESA replied 503");
      if (/\.pdf$/.test(url)) return { url, name: url.split('/').pop(), bytes: new Uint8Array(/-mg\.pdf$/.test(url) ? mg : exam) };
      const k = url.replace(B, '').replace(/\/$/, ''); if (!P[k]) throw new Error("Error invoking remote method 'nesa-get': Error: NESA replied 404");
      return { url, html: P[k] };
    };
    undoMute = true; S.settings = { ...S.settings, ppSubj: { ...(S.settings.ppSubj || {}), maths: true, english: true } }; undoMute = false;
    pp.s = 'maths'; pp.c = { ...(pp.c || {}), maths: 'adv' }; go('papers');
  }, { exam, mg });

  await p.waitForTimeout(700);
  await p.click('[data-act="pp-open"][data-k="n:adv:2024"]');
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(600);
  // a running exam timer no longer hides the solutions
  await E(async () => { ppTmMenu($('#pptm')); await new Promise(r => setTimeout(r, 200)); document.querySelector('[data-act="pp-tm-start"]')?.click(); ppmLockCheck(); });
  await p.waitForTimeout(300);
  console.log(JSON.stringify(['lock', await E(() => ({ locked: ppm.locked, tm: !!ppTmOf(ppm.pid), covers: document.querySelectorAll('.pplock').length, btn: !document.querySelector('#ppzsplit').hidden }))]));
  await p.click('#ppzsplit'); await p.waitForTimeout(700);
  console.log(JSON.stringify(['split', await E(() => ({ split: $('#ppstage').classList.contains('split'), left: $('#pppages').querySelectorAll('.pppage').length, right: $('#ppsolpages').querySelectorAll('.pppage').length, total: ppm.R.pages.length, cutP: ppm.cutP, lw: $('#ppscroll').clientWidth, rw: $('#ppsolscroll').clientWidth, drawn: [...document.querySelectorAll('#ppsolpages .pppage')].filter(e => e._sc).length }))]));
  await shot('split');
  // picking a question brings its solution up on the right
  const qi = await E(() => ppm.items.findIndex((it, i) => i > 2 && it.sol?.length));
  await E(i => ppmPick(i), qi); await p.waitForTimeout(900);
  console.log(JSON.stringify(['pick', qi, await E(() => ({ solTop: $('#ppsolscroll').scrollTop, solBox: !!document.querySelector('#ppsolpages .ppbox.sol'), label: ppm.items[ppm.sel].label }))]));
  await shot('splitpick');
  // S toggles it off
  await E(() => { document.activeElement?.blur(); }); await p.keyboard.press('s'); await p.waitForTimeout(400);
  console.log(JSON.stringify(['S off', await E(() => ({ split: $('#ppstage').classList.contains('split'), hidden: $('#ppsolscroll').hidden, left: $('#pppages').querySelectorAll('.pppage').length }))]));
  await p.keyboard.press('s'); await p.waitForTimeout(300);
  // your mark
  await p.click('.ppabsb'); await p.waitForTimeout(300);
  console.log(JSON.stringify(['focus', await E(() => document.activeElement?.id)]));
  await p.fill('#ppmkg', '41'); await p.click('#ppmko'); await p.waitForTimeout(200); await p.keyboard.type('50'); await p.keyboard.press('Enter'); await p.waitForTimeout(400);
  console.log(JSON.stringify(['mark', await E(() => ({ score: ppmP().score, pct: $('#ppmkp').textContent, note: $('#ppmkn').textContent, bar: $('.ppabsb').textContent }))]));
  await shot('mark');
  await p.fill('#ppmkg', '60'); await p.press('#ppmkg', 'Enter'); await p.waitForTimeout(300);
  console.log(JSON.stringify(['too big', await E(() => ({ score: ppmP().score, note: $('#ppmkn').textContent }))]));
  await p.fill('#ppmkg', '38'); await p.fill('#ppmko', ''); await p.press('#ppmko', 'Tab'); await p.waitForTimeout(300);
  console.log(JSON.stringify(['no total', await E(() => ({ score: ppmP().score, of: $('#ppmko').value }))]));
  await p.click('[data-act="pp-mkclr"]'); await p.waitForTimeout(300);
  console.log(JSON.stringify(['cleared', await E(() => ({ score: ppmP().score ?? null, bar: $('.ppabsb')?.textContent }))]));
  // narrow window: one column, no side-by-side button
  await p.setViewportSize({ width: 820, height: 1000 }); await p.waitForTimeout(700);
  console.log(JSON.stringify(['narrow', await E(() => ({ split: $('#ppstage').classList.contains('split'), btn: $('#ppzsplit').hidden, left: $('#pppages').querySelectorAll('.pppage').length }))]));
  await p.setViewportSize({ width: 1400, height: 900 }); await p.waitForTimeout(700);
  console.log(JSON.stringify(['wide again', await E(() => ({ split: $('#ppstage').classList.contains('split') }))]));
  await E(() => ppFullSet(true)); await p.waitForTimeout(600); await shot('full'); await E(() => ppFullSet(false));
};
