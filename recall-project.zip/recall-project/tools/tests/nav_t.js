// Sidebar (six places + group bar + settings row), Sit it timed in Papers, ⌘K. node nav_t.js W H tag [light]
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]]; const LIGHT = process.argv[5] === 'light';
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8789);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const mob = W < 700;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, colorScheme: LIGHT ? 'light' : 'dark', hasTouch: mob, isMobile: mob }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message + ' ' + (e.stack || '').split('\n')[1]));
  await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
  await p.goto('http://127.0.0.1:8789/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), shot = async n => { await p.waitForTimeout(250); await p.screenshot({ path: `/tmp/nav_${TAG}_${n}.png` }); };
  console.log('visible nav:', await E(() => [...document.querySelectorAll('.toolbar nav [data-nav]')].filter(x => x.offsetParent).map(x => x.dataset.nav).join(',')));
  console.log('bar:', await E(() => $('#gbar') && $('#gbar').offsetParent ? $('#gbar').innerText.replace(/\n/g, ' | ') : 'hidden'), 'footer:', await E(() => $('.sidefoot')?.offsetParent ? $('.sidefoot').innerText.replace(/\n/g, ' | ') : 'hidden'), 'fpill shown:', await E(() => !!$('#fpill')?.offsetParent));
  await shot('0side');
  if (!mob){
    // group bar → panel → start timer from it
    await p.click('#gbar'); await p.waitForTimeout(200); console.log('panel:', await E(() => $('#gbpop')?.innerText.replace(/\n/g, ' | ')));
    await shot('1panel');
    await p.click('#gbpop [data-act="gb-go"]'); await p.waitForTimeout(400); console.log('after start:', await E(() => [focus.state, focus.subj, $('#gbar').innerText.replace(/\n/g, ' | '), view.name]));
    await p.waitForTimeout(1200); console.log('ticks:', await E(() => $('#gbar [data-ftick]')?.textContent));
    await p.click('#gbpop [data-act="gb-pause"]'); await p.waitForTimeout(150); console.log('after pause:', await E(() => [focus.state, $('#gbar').innerText.replace(/\n/g, ' | ')]));
    await p.click('#root', { position: { x: 600, y: 600 } }).catch(() => {}); await p.waitForTimeout(150); console.log('closed by outside click:', await E(() => !$('#gbpop')));
    await p.click('#gbar'); await p.keyboard.press('Escape'); console.log('closed by Esc:', await E(() => !$('#gbpop')));
    await E(() => { fStop(); });
    // with a group (fake data)
    await E(() => { gbGroup = () => gr.groups[0]; cloud.user = cloud.user || { id: 'me' }; gr.loaded = true; gr.groups = [{ id: 'g1', name: 'Year 12 study group', owner: 'u1' }]; gr.cur = 'g1'; const me = grUid();
      gr.members = [me, 'u1', 'u2', 'u3'].map(u => ({ group_id: 'g1', user_id: u })); gr.names = { [me]: 'Jeremy', u1: 'Alex', u2: 'Mia', u3: 'Sam' };
      const now = new Date().toISOString(); gr.status = { u1: { user_id: 'u1', state: 'studying', subject: 'Maths', since: new Date(Date.now() - 4300e3).toISOString(), today_secs: 0, day: fDay(), updated_at: now }, u2: { user_id: 'u2', state: 'studying', subject: 'Physics', since: new Date(Date.now() - 2280e3).toISOString(), today_secs: 0, day: fDay(), updated_at: now }, u3: { user_id: 'u3', state: 'paused', today_secs: 3100, day: fDay(), updated_at: now } }; gr.rooms = []; gr.lastLoad = Date.now(); grLoad = async () => {}; gbPaint(); });
    console.log('bar with group:', await E(() => $('#gbar').innerText.replace(/\n/g, ' | ')));
    await p.click('#gbar'); await p.waitForTimeout(200); console.log('group panel:', await E(() => $('#gbpop').innerText.replace(/\n/g, ' | ')));
    await shot('2group');
    await p.click('#gbpop [data-act="gb-group"]'); await p.waitForTimeout(300); console.log('open group ->', await E(() => view.name));
    // papers: sit it timed
    await E(() => go('papers')); await p.waitForTimeout(800); await p.click('text=2025 HSC').catch(() => {}); await p.waitForTimeout(300);
    console.log('sit box:', await E(() => $('.ppsit')?.innerText.replace(/\n/g, ' | ')));
    await shot('3papers');
    await p.click('[data-act="sit-paper"]'); await p.waitForTimeout(500); console.log('exam started:', await E(() => [view.name, exOn(), exS?.name, exS?.read, exS?.work, exS?.lock]));
    await E(() => { exFinish(true); }); await p.waitForTimeout(300); await p.click('text=Done').catch(() => {}); await p.waitForTimeout(300); await E(() => go('decks')); await p.waitForTimeout(300);
    // ⌘K
    await p.keyboard.press('Meta+k'); await p.waitForTimeout(150); console.log('palette empty:', await E(() => [...document.querySelectorAll('#cklist .ckg, #cklist .ckr span')].map(x => x.textContent).join(' / ')));
    await p.keyboard.type('ex'); await p.waitForTimeout(100); console.log('palette "ex":', await E(() => [...document.querySelectorAll('#cklist .ckg, #cklist .ckr')].map(x => x.innerText.replace(/\n/g, ' ')).join(' / ')));
    await shot('4cmdk');
    await p.keyboard.press('Enter'); await p.waitForTimeout(300); console.log('enter ->', await E(() => [view.name, !!$('#cmdk')]));
    await E(() => go('decks')); await p.keyboard.press('Control+k'); await p.keyboard.type('poly'); await p.keyboard.press('ArrowDown'); await p.keyboard.press('ArrowUp'); console.log('poly:', await E(() => $('.ckr[aria-selected="true"]')?.innerText.replace(/\n/g, ' ')));
    await p.keyboard.press('Enter'); await p.waitForTimeout(300); console.log('-> deck:', await E(() => [view.name, nodeOf(view.node)?.name]));
    await p.keyboard.press('Meta+k'); await p.keyboard.type('log a'); await p.keyboard.press('Enter'); await p.waitForTimeout(200); console.log('log a mistake ->', await E(() => $('#mklh')?.textContent)); await E(() => closeDialog());
    await p.keyboard.press('Meta+k'); await p.keyboard.press('Escape'); console.log('esc closes:', await E(() => !$('#cmdk')));
    await p.keyboard.press('Meta+f'); console.log('⌘F focuses search:', await E(() => document.activeElement?.id));
  }
  console.log('h-scroll:', await E(() => document.documentElement.scrollWidth > innerWidth + 1), 'errors:', errs.length ? errs : 'none');
  await b.close(); srv.close();
})();
