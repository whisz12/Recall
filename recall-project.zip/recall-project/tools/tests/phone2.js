const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG, UA] = [+process.argv[2], +process.argv[3], process.argv[4], process.argv[5] || 'iPhone'];
(async () => {
  const root = require('path').resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8771);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ua = UA === 'iPad' ? 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: true, deviceScaleFactor: 2, userAgent: ua }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  const V = require('path').resolve(__dirname, '../../app/app/vendor') + '/';
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)/, route => { const u = route.request().url(); const m = u.includes('supabase') ? V + 'supabase.js' : null; if (m) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(m) }); route.fulfill({ status: 200, body: '' }); });
  const lib = fs.readFileSync(require('path').join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
  await p.goto('http://127.0.0.1:8771/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a);
  const ov = async l => { const o = await E(() => document.documentElement.scrollWidth > innerWidth + 1); if (o) errs.push('h-scroll on ' + l); };
  await p.screenshot({ path: `ph_${TAG}_home.png` }); await ov('home');
  await E(() => go('browse')); await p.waitForTimeout(300); await p.screenshot({ path: `ph_${TAG}_browse.png` }); await ov('browse');
  const t = await E(() => kids(kids(null)[0].id)[0].id);
  for (const l of ['harness', 'classic']) { await E(l => saveTheme({ ...themeSettings(), layout: l }), l); await E(t => startStudy(t, true), t); await p.waitForTimeout(300); await p.screenshot({ path: `ph_${TAG}_study_${l}.png` }); await ov('study ' + l);
    await E(() => padToggle(true)); await p.waitForTimeout(200); await ov('pad ' + l); await E(() => padAction('full')); await p.waitForTimeout(250); await p.screenshot({ path: `ph_${TAG}_full_${l}.png` }); await ov('full ' + l); await E(() => { padAction('full'); padToggle(false); }); }
  await E(() => saveTheme({ ...themeSettings(), layout: 'harness' }));
  await E(() => go('stats')); await p.waitForTimeout(300); await p.screenshot({ path: `ph_${TAG}_stats.png` }); await ov('stats');
  console.log(TAG, 'desktop class:', await E(() => document.body.classList.contains('desktop')), 'issues:', errs);
  await b.close(); srv.close();
})();
