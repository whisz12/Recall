const fs = require('fs');
module.exports = async (p, E, shot) => {
  const src = 'data:image/png;base64,' + fs.readFileSync('/mnt/user-data/uploads/5aa431a4-image.png').toString('base64');
  await E(src => openGallery([{ src, label: 'Worked solution 1' }, { src, label: 'Worked solution 2' }], 0), src); await p.waitForTimeout(600); await shot('fit');
  const r = await p.locator('.lightbox figure img').boundingBox();
  await p.mouse.dblclick(r.x + r.width * .55, r.y + r.height * .55); await p.waitForTimeout(400); await shot('zoom');
  await p.click('[data-lbz="in"]'); await p.waitForTimeout(300); await p.mouse.move(700, 450); await p.mouse.down(); await p.mouse.move(500, 300, { steps: 8 }); await p.mouse.up(); await p.waitForTimeout(200); await shot('zoom2');
  console.log(JSON.stringify(await E(() => ({ s: lbz.s, x: Math.round(lbz.x), y: Math.round(lbz.y), open: !!$('.lightbox') }))));
};
