// bar hidden: the handle shows the time left while a timer runs; pause, warn, stop; full screen; bring the bar back
module.exports = async (p, E, shot) => {
  const st = () => E(() => { const h = $('#ppzshow'), r = h.getBoundingClientRect(); return { cls: h.className, txt: h.innerText.trim(), vis: getComputedStyle(h).display !== 'none' && r.width > 0, w: Math.round(r.width), bar: ppBar }; });
  const log = async n => console.log(JSON.stringify([n, await st()]));
  await E(() => { if (!ppBar) ppBarSet(true); }); await p.waitForTimeout(200);
  await E(() => ppBarSet(false)); await p.waitForTimeout(300); await log('hidden, no timer');
  await E(() => { const p0 = ppmP(); ppTmPut(p0.id, { t0: Date.now(), dur: 90 * 60000, read: 0, pm: 0, pa: 0, al: {} }); }); await p.waitForTimeout(1300); await log('running');
  await shot('mini');
  await E(() => ppTmAct('pp-tm-pause')); await p.waitForTimeout(400); await log('paused');
  await E(() => ppTmAct('pp-tm-pause')); await E(() => { const p0 = ppmP(), t = ppTmOf(p0.id); t.t0 = Date.now() - 87 * 60000; ppTmPut(p0.id, t); }); await p.waitForTimeout(1200); await log('3 min left');
  await E(() => ppFullSet(true)); await p.waitForTimeout(600); await log('full screen'); await shot('mini_full'); await E(() => ppFullSet(false)); await p.waitForTimeout(400);
  await p.click('#ppzshow'); await p.waitForTimeout(400); await log('clicked: bar back');
  await E(() => ppBarSet(false)); await E(() => ppTmAct('pp-tm-reset')); await p.waitForTimeout(400); await log('reset');
  await E(() => ppBarSet(true));
};
