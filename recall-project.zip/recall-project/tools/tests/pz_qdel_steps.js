// remove question boxes: x on the page, ⌫ key, panel link; found and drawn boxes; undo/redo; stays removed on reopen
module.exports = async (p, E, shot) => {
  await E(() => ls.set('md-pp-cardpos', { r: innerWidth - 250, t: innerHeight - 140 }));   // the marking card out of the way, bottom left
  const st = () => E(() => { const pp = ppmP(); return { n: ppm.items.length, sel: ppm.sel, labels: ppm.items.map(x => x.label).join(','), hid: pp.hid || [], man: (pp.man || []).length, qs: (pp.qs || []).length, x: document.querySelectorAll('.ppx').length, toast: $('#toast').hidden ? '' : $('#toast').textContent }; });
  const log = async n => console.log(JSON.stringify([n, await st()]));
  await log('start');
  // x on the picked box
  await p.click('#pprail .ppsq[data-i="1"]'); await p.waitForTimeout(500); await log('picked 1');
  await shot('xbtn');
  await p.click('.ppx'); await p.waitForTimeout(500); await log('x removed');
  // undo brings it back, redo removes again
  await E(() => document.activeElement?.blur()); await p.keyboard.press('Meta+z'); await p.waitForTimeout(600); await log('undo');
  await p.keyboard.press('Meta+Shift+z'); await p.waitForTimeout(600); await log('redo');
  // ⌫ key
  await p.click('#pprail [data-act="pp-q"][data-i="0"]'); await p.waitForTimeout(300); await E(() => document.activeElement?.blur());
  await p.keyboard.press('Backspace'); await p.waitForTimeout(500); await log('backspace');
  // ⌫ while typing in why box doesn't remove
  await p.click('#pprail [data-act="pp-q"][data-i="0"]'); await p.waitForTimeout(300); await p.keyboard.press('3'); await p.waitForTimeout(300);
  await p.click('#ppwhy'); await p.keyboard.type('ab'); await p.keyboard.press('Backspace'); await p.waitForTimeout(200);
  console.log(JSON.stringify(['typing bksp', await E(() => ({ n: ppm.items.length, why: $('#ppwhy').value }))]));
  // draw a box, then remove it with the panel link
  await E(() => { ppm.draw = 'q'; ppmSide(); }); await p.waitForTimeout(200);
  const r = await E(() => { const o = $('#pppages .ppov[data-p="1"]').getBoundingClientRect(); return { x: o.left + o.width * .55, y: o.top + o.height * .80 }; });
  await p.mouse.move(r.x, r.y); await p.mouse.down(); await p.mouse.move(r.x + 120, r.y + 60, { steps: 6 }); await p.mouse.up(); await p.waitForTimeout(700); await log('drew box');
  await p.waitForTimeout(500);
  await p.click('#pppanel [data-act="pp-qdel"]'); await p.waitForTimeout(500); await log('panel removed drawn');
  // reopen: removed found questions stay gone
  const pid = await E(() => ppm.pid);
  await E(() => go('papers')); await p.waitForTimeout(400); await E(pid => { ppm = null; go('ppmark', pid); }, pid);
  await p.waitForSelector('#ppm .ppsq', { timeout: 20000 }); await p.waitForTimeout(900); await log('reopened');
};
