// Recall: get one THSC paper for a signed-in Recall user (used by the iPad / web app, which THSC's server refuses).
// It does what THSC's own viewer does: metadata, then the gzip fragments one at a time, then unzip, and returns the PDF.
// Deploy as "thsc-paper" with "Verify JWT" left on, so only signed-in Recall users can call it.
const API = 'https://www.thsconline.net/api/v1';
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Expose-Headers': 'x-file-name' };
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
const recent = new Map<string, number[]>(); // per user, papers in the last hour (per running copy of the function)

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  try {
    // a real signed-in user, not just the public key
    const auth = req.headers.get('authorization') || '', key = req.headers.get('apikey') || Deno.env.get('SUPABASE_ANON_KEY') || '';
    const u = await fetch(`${Deno.env.get('SUPABASE_URL')}/auth/v1/user`, { headers: { authorization: auth, apikey: key } });
    if (!u.ok) return json({ error: 'Sign in to Recall to get papers' }, 401);
    const uid = (await u.json())?.id || 'x', now = Date.now(), hits = (recent.get(uid) || []).filter(t => now - t < 3600e3);
    if (hits.length >= 30) return json({ error: 'That’s 30 papers this hour. Try again later.' }, 429);
    hits.push(now); recent.set(uid, hits);

    const body = await req.json().catch(() => ({}));
    const no = String(body.no || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 12);
    const title = String(body.title || '').replace(/\(Adv\.\)/g, '__ADV__').replace(/\(Std\.\)/g, '__STD__').replace(/[^A-Za-z0-9._\- ]/g, '').replace(/__ADV__/g, '(Adv.)').replace(/__STD__/g, '(Std.)').slice(0, 160);
    if (!no || !title.trim()) return json({ error: 'Not a THSC paper' }, 400);
    const enc = encodeURIComponent, ua = 'Recall (HSC revision app; one paper when a student opens it)';
    const get = async (url: string) => { const r = await fetch(url, { headers: { 'User-Agent': ua } }); if (!r.ok) throw new Error('THSC replied ' + r.status); return r; };

    const meta = await (await get(`${API}/getmetadata/${enc(no)}/${enc(title)}`)).json();
    if (meta?.error) throw new Error(String(meta.error));
    const n = Number(meta?.fragmentCount); if (!Number.isSafeInteger(n) || n < 1 || n > 200) throw new Error('THSC sent an odd reply');
    const parts: Uint8Array[] = []; let size = 0;
    for (let i = 0; i < n; i++){ const b = new Uint8Array(await (await get(`${API}/getfragment/${enc(no)}/${enc(title)}/${i}`)).arrayBuffer()); size += b.length; if (size > 80e6) throw new Error('That paper is too big'); parts.push(b); }
    const gz = new Uint8Array(size); let o = 0; for (const p of parts){ gz.set(p, o); o += p.length; }
    const pdf = new Uint8Array(await new Response(new Blob([gz]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
    if (String.fromCharCode(...pdf.subarray(0, 5)) !== '%PDF-') throw new Error('THSC didn’t send a PDF');
    let name = String(meta.originalFileName || title + '.pdf').split(/[\\/]/).pop() || 'paper.pdf'; if (!/\.pdf$/i.test(name)) name = name.replace(/\.gz$/i, '').replace(/\.[^.]+$/, '') + '.pdf';
    return new Response(pdf, { headers: { ...CORS, 'Content-Type': 'application/pdf', 'x-file-name': enc(name) } });
  } catch (e){ return json({ error: String((e as Error)?.message || e) }, 502); }
});
