// unpick a question: click it again (list or page), click off (blank paper, grey stage, empty list space); drafts survive
module.exports = async (p, E, shot) => {
  const sel = () => E(() => ({ sel: ppm.sel, panel: !!$('#ppwhy') || !!$('.ppsave'), summary: !!$('#ppmkg'), why: $('#ppwhy')?.value ?? null, res: ppm.res }));
  const log = async n => console.log(JSON.stringify([n, await sel()]));
  // 1. list: click once picks, click again unpicks
  await p.click('#pprail .ppsq[data-i="2"]'); await p.waitForTimeout(400); await log('list pick');
  await p.click('#pprail .ppsq[data-i="2"]'); await p.waitForTimeout(400); await log('list again');
  // 2. page box: click picks, click again unpicks
  await E(() => ppmPick(1)); await p.waitForTimeout(600);
  const box = await p.$('#pppages .ppbox.sel'); const bb = await box.boundingBox();
  await p.mouse.click(bb.x + bb.width / 2, bb.y + Math.min(bb.height / 2, 40)); await p.waitForTimeout(400); await log('page box again');
  // 3. click blank paper (a spot not inside any box)
  await E(() => ppmPick(1)); await p.waitForTimeout(500);
  const spot = await E(() => { const pg = $('#pppages .pppage'), r = pg.getBoundingClientRect(), boxes = [...document.querySelectorAll('#pppages .ppbox')].map(b => b.getBoundingClientRect());
    for (let y = r.top + 5; y < Math.min(r.bottom, innerHeight) - 5; y += 6){ const x = r.left + 6; const hit = document.elementFromPoint(x, y); if (hit && !hit.closest('button') && hit.closest('#pppages') && !boxes.some(b => x >= b.left && x <= b.right && y >= b.top && y <= b.bottom)) return { x, y, tag: hit.className }; } return null; });
  console.log(JSON.stringify(['blank spot', spot]));
  await p.mouse.click(spot.x, spot.y); await p.waitForTimeout(400); await log('blank paper');
  // 4. grey stage around the page
  await E(() => ppmPick(1)); await p.waitForTimeout(400);
  const g = await E(() => { const s = $('#ppscroll').getBoundingClientRect(), pg = $('#pppages .pppage').getBoundingClientRect(); return pg.left - s.left > 12 ? { x: s.left + 5, y: s.top + 200 } : { x: s.left + s.width / 2, y: s.bottom - 4 }; });
  await p.mouse.click(g.x, g.y); await p.waitForTimeout(400); await log('grey stage');
  // 5. empty space in the questions list (below the last question)
  await E(() => ppmPick(3)); await p.waitForTimeout(400);
  const rl = await E(() => { const sa = $('#pprail .ppsa').getBoundingClientRect(), f = $('#pprail .pprfoot').getBoundingClientRect(); return { x: sa.left + 20, y: (sa.bottom + f.top) / 2, gap: f.top - sa.bottom, hit: document.elementFromPoint(sa.left + 20, (sa.bottom + f.top) / 2)?.className }; });
  console.log(JSON.stringify(['rail spot', rl]));
  await p.mouse.click(rl.x, rl.y); await p.waitForTimeout(400); await log('rail blank');
  // 6. clicking in the right panel and zoom bar keeps the pick
  await E(() => ppmPick(3)); await p.waitForTimeout(400);
  await p.keyboard.press('3'); await p.waitForTimeout(300);
  await p.click('#ppwhy'); await p.keyboard.type('forgot the sign'); await p.waitForTimeout(100);
  const pr = await E(() => { const r = $('#pppanel').getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.bottom - 10 }; });
  await p.mouse.click(pr.x, pr.y); await p.waitForTimeout(300); await log('panel blank keeps');
  await p.click('#ppzbar [data-act="pp-zoom"][data-d="1"], #ppzbar button >> nth=1').catch(() => {}); await p.waitForTimeout(400); await log('zoom bar keeps');
  // 7. draft survives click-off and comes back
  await p.mouse.click(spot.x, spot.y).catch(() => {}); await p.waitForTimeout(300);
  await E(() => { const pg = $('#pppages .pppage'); }); await log('after off');
  await p.click('#pprail .ppsq[data-i="3"]'); await p.waitForTimeout(400); await log('back to 3 (draft)');
  await shot('unpick');
  // 8. drawing mode: clicking paper doesn't unpick
  await E(() => { ppm.draw = 'q'; ppmSide(); }); await p.waitForTimeout(200);
  await E(() => { const ev = new MouseEvent('click', { bubbles: true }); $('#ppscroll').dispatchEvent(ev); }); await log('draw mode click');
  await E(() => { ppm.draw = null; ppmSide(); });
  // 9. keys still work after unpick
  await p.click('#pprail .ppsq[data-i="3"]'); await p.waitForTimeout(300); await log('unpicked via list');
  await E(() => document.activeElement?.blur()); await p.keyboard.press('ArrowDown'); await p.waitForTimeout(300); await log('arrow picks first');
};
