// an in-memory stand-in for the Supabase client, enough for the group screens
window.__deliver = (j) => { const m = JSON.parse(j); (window.__bc || []).filter(x => x.name === m.name).forEach(x => x.cb({ payload: m.payload })); };
window.__grFake = function(uid){
  const now = Date.now(), iso = t => new Date(t).toISOString(), today = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; })();
  const A = uid, B = 'bbbbbbbb-0000-4000-8000-000000000002', C = 'cccccccc-0000-4000-8000-000000000003', G = 'gggggggg-0000-4000-8000-000000000001';
  const db = window.__db = {
    profiles: [{ user_id: B, name: 'Ali' }, { user_id: C, name: 'Sophie' }],
    study_groups: [], group_members: [],
    study_status: [{ user_id: B, state: 'studying', subject: 'Physics', since: iso(now - 47 * 60e3), today_secs: 3600, day: today, room: null, updated_at: iso(now - 20e3) }, { user_id: C, state: 'paused', subject: 'Maths', since: null, today_secs: 5400, day: today, left_at: iso(now - 4 * 60e3), updated_at: iso(now - 4 * 60e3) }],
    study_days: [{ user_id: B, day: today, secs: 3600 }, { user_id: C, day: today, secs: 5400 }, { user_id: C, day: '2026-11-17', secs: 9000 }, { user_id: B, day: '2026-11-16', secs: 4000 }],
    group_rooms: [], push_subs: [], calls: []
  };
  const q = (table) => {
    const st = { table, f: [], op: 'select', one: false, row: null, order: null };
    const run = () => {
      db.calls.push(st.op + ' ' + table);
      let rows = db[table];
      const match = r => st.f.every(([k, op, v]) => op === 'eq' ? r[k] === v : op === 'in' ? v.includes(r[k]) : op === 'gte' ? String(r[k]) >= String(v) : op === 'is' ? (r[k] ?? null) === v : true);
      if (st.op === 'upsert'){ const key = table === 'study_days' ? ['user_id', 'day'] : table === 'push_subs' ? ['endpoint'] : ['user_id']; for (const row of [].concat(st.row)){ const i = rows.findIndex(r => key.every(k => r[k] === row[k])); if (i >= 0) rows[i] = { ...rows[i], ...row }; else rows.push({ ...row }); } return { data: null, error: null }; }
      if (st.op === 'insert'){ const row = { id: 'rrrrrrrr-0000-4000-8000-' + String(Math.random()).slice(2, 14), starts_at: iso(Date.now()), ended_at: null, ...st.row }; rows.push(row); return { data: st.one ? row : [row], error: null }; }
      if (st.op === 'update'){ rows.filter(match).forEach(r => Object.assign(r, st.row)); return { data: null, error: null }; }
      let out = rows.filter(match);
      return { data: st.one ? (out[0] || null) : out, error: null };
    };
    const b = {
      select(){ return b; }, eq(k, v){ st.f.push([k, 'eq', v]); return b; }, in(k, v){ st.f.push([k, 'in', v]); return b; }, gte(k, v){ st.f.push([k, 'gte', v]); return b; }, is(k, v){ st.f.push([k, 'is', v]); return b; }, order(){ return b; },
      maybeSingle(){ st.one = true; return b; }, single(){ st.one = true; return b; },
      upsert(r){ st.op = 'upsert'; st.row = r; return b; }, insert(r){ st.op = 'insert'; st.row = r; return b; }, update(r){ st.op = 'update'; st.row = r; return b; },
      then(res, rej){ return Promise.resolve(run()).then(res, rej); }
    };
    return b;
  };
  const sb = {
    from: q,
    rpc: async (fn, a) => {
      db.calls.push('rpc ' + fn);
      if (fn === 'create_group'){ const g = { id: G, name: a.p_name, code: 'K7QX2M', owner: A, created_at: iso(now) }; db.study_groups.push(g); db.group_members.push({ group_id: G, user_id: A, joined_at: iso(now) }, { group_id: G, user_id: B, joined_at: iso(now) }, { group_id: G, user_id: C, joined_at: iso(now) }); return { data: g, error: null }; }
      if (fn === 'join_group'){ if (a.p_code !== 'K7QX2M') return { data: null, error: { message: 'No group has that code' } }; return { data: db.study_groups[0], error: null }; }
      if (fn === 'leave_group'){ db.group_members = db.group_members.filter(m => m.user_id !== A); db.study_groups = []; return { data: null, error: null }; }
    },
    auth: { getSession: async () => ({ data: { session: { access_token: 'tok' } } }) },
    channel(name){ const c = { name, on(type, f, cb){ if (type === 'broadcast') (window.__bc ||= []).push({ name, cb }); return c; }, subscribe(cb){ setTimeout(() => cb && cb('SUBSCRIBED'), 50); return c; }, send(m){ window.__relay && window.__relay(JSON.stringify({ name, payload: m.payload })); return Promise.resolve('ok'); } }; return c; }, removeChannel(){}
  };
  return sb;
};
