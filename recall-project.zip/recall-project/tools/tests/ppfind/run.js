// node run.js [src.html] [papers...]: run the question finder from the source on the dumped pages
const fs = require('fs'), vm = require('vm');
const SRC = process.env.SRC || '/home/claude/w/recall-project/src/mistake-deck.html', s = fs.readFileSync(SRC, 'utf8');
const cut = (a, b) => { const i = s.indexOf(a), j = s.indexOf(b, i); if (i < 0 || j < 0) throw new Error('cut ' + a); return s.slice(i, j); };
const code = cut('const PX_STOP', '/* text inside pictures') + cut('/* the same pages, but only the lines inside', '/* render pages and cut out');
const ctx = { pdfx: null, detectMarks: () => 0, console }; vm.createContext(ctx);
const plan = process.env.PLAN ? fs.readFileSync(process.env.PLAN, 'utf8') : '';
vm.runInContext((code + '\n' + plan).replace(/^const /gm, 'var ').replace(/^let /gm, 'var ') + '\n;this.pxPlan = pxPlan; if (typeof ppMarksIn !== "undefined"){ this.ppMarksIn = ppMarksIn; this.ppNorm = ppNorm; } this.pxSplit = pxSplit; this.pxSlice = pxSlice; this.pxAt = pxAt; this.pxStarts = pxStarts; if (typeof ppPlan !== "undefined") this.ppPlan = ppPlan;', ctx);
module.exports = ctx;
if (require.main === module){
  const idx = Object.fromEntries(fs.readFileSync('/home/claude/papers/index.txt', 'utf8').trim().split('\n').map(l => l.split('|')));
  const only = process.argv.slice(2);
  for (const f of fs.readdirSync('json').sort()){
    const id = f.slice(0, 3); if (only.length && !only.includes(id)) continue;
    const R = JSON.parse(fs.readFileSync('json/' + f));
    let items;
    if (ctx.ppPlan) { const r = ctx.ppPlan(R); items = r.items; if (process.env.V) console.log('   cut', r.cut, 'multi', r.multi); }
    else { const c = R.textLines ? ctx.pxSplit(R) : null, Q = c ? ctx.pxSlice(R, 0, c) : R; items = R.textLines ? ctx.pxPlan(Q, 'question') : []; }
    console.log(`${id} ${idx[id]}\n   ${items.length} found: ${items.map(it => it.label.replace(/^Q/, '') + (it.marks ? '[' + it.marks + (it.guess ? '?' : '') + ']' : '') + (it.mc ? 'm' : '') + (process.env.V ? '@' + it.segs[0]?.p + (it.stem ? 's' : '') : '')).join(' ')}`);
  }
}
