// Mistakes: list + rules panel, log dialog with habit suggestions, rules on Today / Exam timer, Study (M), search, paper chips.
// node mkl_t.js W H tag [light]
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]]; const LIGHT = process.argv[5] === 'light';
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8785);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const mob = W < 700;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, colorScheme: LIGHT ? 'light' : 'dark', hasTouch: mob, isMobile: mob }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message + ' ' + (e.stack || '').split('\n')[1]));
  await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
  await p.goto('http://127.0.0.1:8785/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), shot = async n => { await p.waitForTimeout(250); await p.screenshot({ path: `/tmp/mkl_${TAG}_${n}.png` }); };
  await p.click('nav [data-nav="mistakes"]'); await p.waitForTimeout(300);
  await shot('0empty');
  // quick adds in Maths
  await p.click('.stab[data-id]:not([data-id="all"]) >> nth=0'); await p.waitForTimeout(150);
  for (const t of ['Integrated by parts the wrong way round', 'Ran out of time on Q16, spent too long on Q13']){ await p.click('#mklnew'); await p.keyboard.type(t); await p.keyboard.press('Enter'); }
  // a full log with a new habit
  await E(() => mklDialog()); await p.waitForTimeout(150);
  await p.fill('#mkdt', 'Wrote √(x²) = x and lost the negative root'); await p.click('[data-act="mkl-h"][data-v="new"]'); await p.fill('#mkdhn', 'Dropped the ±');
  await p.fill('#mkdw', '2024 Ext 2 trial · Q14(b)'); await p.fill('#mkdm', '2'); await p.fill('#mkdr', 'Square-root both sides, write ± straight away');
  await p.click('[data-act="mkl-save"]'); await p.waitForTimeout(200);
  // a second one: the habit should be suggested first and its rule filled in
  await E(() => mklDialog()); await p.fill('#mkdt', 'Solved z² = −4 as z = 2i, lost the negative root again'); await p.waitForTimeout(400);
  console.log('suggested:', await E(() => [...document.querySelectorAll('#mkdh .mklchip')].map(x => x.textContent)));
  await p.click('#mkdh .mklchip >> nth=0'); console.log('rule filled:', await E(() => $('#mkdr').value));
  await p.fill('#mkdw', '2023 Ext 2 trial · Q12(a)'); await p.fill('#mkdm', '3'); await shot('1dialog'); await p.keyboard.press('Meta+Enter'); await p.waitForTimeout(200);
  // physics one with rule but no habit → becomes a habit
  await E(() => mklDialog({ s: kids(null)[1].id })); await p.fill('#mkdt', 'Gave km/h when it asked for m/s'); await p.fill('#mkdm', '1'); await p.fill('#mkdr', 'Write the unit in the final line'); await p.click('[data-act="mkl-save"]'); await p.waitForTimeout(200);
  console.log('finding:', await E(() => $('.mklfind')?.textContent));
  console.log('rows:', await E(() => [...document.querySelectorAll('.mklr')].map(x => x.innerText.replace(/\n/g, ' | ')).slice(0, 4)));
  console.log('rules:', await E(() => [...document.querySelectorAll('.mklrules li')].map(x => x.innerText.replace(/\n/g, ' | '))));
  await shot('2list');
  // All tab
  await p.click('.stab[data-id="all"]'); await p.waitForTimeout(200); console.log('all tab rows:', await E(() => document.querySelectorAll('.mklr').length), 'rules:', await E(() => document.querySelectorAll('.mklrules li').length));
  // exam tomorrow for Maths: rules panel + Today
  await E(() => { const m = kids(null)[0]; const d = dayKey(Date.now() + 864e5); put('nodes', { ...m, exam: { date: d, name: 'Ext 2 trial' } }); }); await p.waitForTimeout(200);
  await E(() => renderMistakes()); console.log('exam tabs:', await E(() => [...document.querySelectorAll('.mkle button')].map(x => x.textContent)), 'head:', await E(() => $('.mklside h2').textContent));
  await p.click('.mklck >> nth=0'); console.log('ticked saved:', await E(() => JSON.stringify(ls.get('md-mkl-tick', {}))));
  await shot('3exam');
  await E(() => { ls.set('md-subj', kids(null)[0].id); go('decks'); }); await p.waitForTimeout(400);
  console.log('Today card:', await E(() => $('.mkltoday')?.innerText.replace(/\n/g, ' | ')));
  await shot('4today');
  await E(() => go('exam')); await p.waitForTimeout(200); console.log('Exam timer rules:', await E(() => $('.mklexr')?.innerText.replace(/\n/g, ' | ')));
  // edit and delete from the list
  await E(() => go('mistakes')); await p.click('.stab[data-id]:not([data-id="all"]) >> nth=0'); await p.waitForTimeout(150);
  await p.click('.mklr >> nth=0'); await p.waitForTimeout(150); console.log('edit dialog title:', await E(() => $('#mklh').textContent), await E(() => $('#mkdt').value));
  await p.click('[data-act="mkl-del"]'); await p.click('[data-act="mkl-del"]'); await p.waitForTimeout(150); console.log('after delete:', await E(() => mklEntries('all').length));
  if (!mob){ await p.keyboard.press('Meta+z'); await p.waitForTimeout(250); console.log('after undo:', await E(() => mklEntries('all').length)); }
  // habits: mark fixed
  await E(() => mklHabitsDialog(kids(null)[0].id)); await p.waitForTimeout(150); await shot('5habits');
  await p.click('.mklhr [data-hf] >> nth=0'); await p.click('[data-act="mkl-hsave"]'); await p.waitForTimeout(150);
  console.log('rules after fixed:', await E(() => mklRules(kids(null)[0].id).length), 'habit kept:', await E(() => mhabAll().length));
  await E(() => { const h = mhabAll()[0]; S.settings = { ...S.settings, mhab: mhabAll().map(x => x.id === h.id ? (({ fx, ...y }) => y)(x) : x) }; saveSettings(); });
  // search
  if (!mob){ await E(() => { const q = $('#sidesq'); q.value = 'negative root'; sideSearch(q.value); }); await p.waitForTimeout(150); console.log('search:', await E(() => [[...document.querySelectorAll('#sidesres .sidelabel')].map(x => x.textContent), $('#sidesres [data-act="mkl-find"]')?.innerText]));
    await p.click('#sidesres [data-act="mkl-find"]'); await p.waitForTimeout(250); console.log('opened from search:', await E(() => [view.name, $('#mkdt')?.value])); await E(() => { closeDialog(); $('#sidesq').value = ''; sideSearch(''); }); }
  // study: M logs the card as a mistake
  await E(() => { const m = kids(null)[0]; startStudy(m.id, true); }); await p.waitForTimeout(400); await E(() => showAnswer()); await p.waitForTimeout(300);
  console.log('dock link:', await E(() => !!$('[data-act="mkl-from-card"]'))); await p.keyboard.press('m'); await p.waitForTimeout(200);
  console.log('from card:', await E(() => [$('#mklh')?.textContent, $('#mkds')?.selectedOptions[0]?.textContent, $('#mkdw')?.value, !!mkd?.c]));
  await E(() => closeDialog());
  // paper chips
  console.log('paper chips:', await E(() => { ppm = { why: 'lost the negative root', items: [], sel: 0 }; const h = mklPPChips({ id: 'p1', c: 'x2' }, { key: 'q12a', label: 'Q12(a)' }, 0, 3); ppm = null; return h.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }));
  await E(() => go('mistakes')); await p.waitForTimeout(200);
  console.log('h-scroll:', await E(() => document.documentElement.scrollWidth > innerWidth + 1), 'errors:', errs.length ? errs : 'none');
  await shot('6final');
  await b.close(); srv.close();
})();
