// The 8 Nov repair: the desktop app's settings win once; a stale cloud copy without to-dos can't wipe them.
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); let disk = null;
  await p.exposeFunction('diskSave', s => { disk = s; });
  await p.addInitScript(lib => { const db = JSON.parse(lib); db.settings = { ...db.settings, newPerDay: 999, todos: [{ id: 't1', t: 'Dr Du Polynomials', done: 0, at: 1, l: 'hw' }, { id: 't2', t: 'Physics trial', done: 0, at: 2 }] }; window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async s => { window.diskSave(JSON.parse(JSON.stringify(s))); }, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.28.0', build: '1', updated: true }), checkUpdate: async () => {}, onUpdate() {}, saveFile: async () => true, hasImage: async () => true, readImage: async () => new Uint8Array() }; window.supabase = { createClient() { return { auth: { async getSession() { return { data: { session: null } }; }, onAuthStateChange() {} } }; } }; }, lib);
  await p.goto('file://' + path.resolve(__dirname, '../../app/app/index.html')); await p.waitForTimeout(1300);
  const out = await p.evaluate(() => {
    const a = { flag: !!ls.get('set-repair-1', 0), stamped: Object.keys(S.settings._t || {}).length, dirty: cloud.dirty.has('$settings/me') };
    cloudSettingsIn({ data: { newPerDay: 20, theme: S.settings.theme }, updated_at: Date.now() + 1e7 });   // the stale copy the iPad pushed
    return { ...a, todos: (S.settings.todos || []).length, newPerDay: S.settings.newPerDay };
  });
  out.disk = disk ? { todos: (disk.todos || []).length, _t: !!disk._t } : null;
  console.log(JSON.stringify(out), 'ERRORS', errs.length ? errs : 'none'); await b.close();
})();
