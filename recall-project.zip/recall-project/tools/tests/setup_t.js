const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG, EMPTY] = [+process.argv[2], +process.argv[3], process.argv[4], process.argv[5] === 'empty'];
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8772);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ua = W > 700 ? 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: true, deviceScaleFactor: 2, userAgent: ua }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  const V = path.resolve(__dirname, '../../app/app/vendor') + '/';
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)/, route => { const u = route.request().url(); if (u.includes('supabase')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(V + 'supabase.js') }); route.fulfill({ status: 200, body: '' }); });
  if (!EMPTY){ const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib); }
  await p.goto('http://127.0.0.1:8772/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a); const ck = s => p.click(s);
  await E(() => { try { closeLayer?.(); } catch(e){} document.querySelector('#layer').innerHTML=''; go('home'); }); await p.waitForTimeout(300); await p.screenshot({ path: `/tmp/st_${TAG}_home.png` });
  await p.screenshot({ path: `/tmp/st_${TAG}_home.png` }); console.log('tabrow setup:', await E(() => !!document.querySelector('.stabsetup')));
  console.log('setup buttons on home:', await E(() => document.querySelectorAll('[data-act="sy-open"]').length));
  await ck('[data-act="sy-open"]'); await p.waitForTimeout(300);
  console.log('decks before:', await E(() => kids(null).map(n => n.name)));
  await ck('[data-act="sy-m"][data-v="x2"]');
  for (const v of ['phys','eco','eng-adv','leg']){ if (await E(v => document.querySelector(`[data-act="sy-s"][data-v="${v}"]`).getAttribute('aria-pressed'), v) !== 'true') await ck(`[data-act="sy-s"][data-v="${v}"]`); }
  if (!(await E(() => !!document.querySelector('[data-act="sy-t"][data-v="phys|Module 1 – Kinematics"]')))) await ck('[data-act="sy-o"][data-v="phys"]');
  await ck('[data-act="sy-t"][data-v="phys|Module 1 – Kinematics"]');
  await p.waitForTimeout(200); await p.screenshot({ path: `/tmp/st_${TAG}_setup.png`, fullPage: false });
  await E(() => scrollTo(0, 99999)); await p.waitForTimeout(150); await p.screenshot({ path: `/tmp/st_${TAG}_setup2.png` });
  console.log('count:', await E(() => document.querySelector('.sycount').textContent), '| hscroll', await E(() => document.documentElement.scrollWidth > innerWidth + 1));
  await ck('[data-act="sy-go"]'); await p.waitForTimeout(600);
  const tree = await E(() => { const t = n => kids(n?.id ?? null).map(k => k.name + (kids(k.id).length ? '{' + t(k).join(',') + '}' : '')); return t(null); });
  console.log('view', await E(() => view.name), 'tree:', JSON.stringify(tree).slice(0, 1500));
  // run again: must add nothing
  await E(() => { sy = null; go('setup'); }); await p.waitForTimeout(200);
  console.log('second run count:', await E(() => document.querySelector('.sycount').textContent));
  // subject switch scroll
  await E(() => go('decks')); await p.waitForTimeout(200); await E(() => scrollTo(0, 3000)); await p.waitForTimeout(100);
  const sw = await E(() => { const b = document.querySelector('[data-act="subj-tab"],[data-act="side-subj"]'); if (!b) return 'no subj btn'; b.click(); return scrollY; });
  console.log('scrollY after subj switch:', sw);
  // phone bar
  console.log('nav:', await E(() => { const n = document.querySelector('.toolbar nav'); if (!n || getComputedStyle(n).display === 'none') return 'hidden'; return [...n.querySelectorAll('button')].filter(x => getComputedStyle(x).display !== 'none').map(x => x.dataset.nav || x.className).join(',') + ' sw=' + n.scrollWidth + ' cw=' + n.clientWidth; }));
  await p.screenshot({ path: `/tmp/st_${TAG}_decks.png` });
  console.log(TAG, 'errors:', errs); await b.close(); srv.close();
})();
