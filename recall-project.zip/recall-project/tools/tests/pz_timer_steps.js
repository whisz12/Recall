module.exports = async (p, E, shot) => {
  const bar = () => E(() => [$('#pptm').className.trim(), $('#pptm').innerText.trim(), $('#toast').hidden ? '' : $('#toast').innerText]);
  const shift = ms => E(ms => { const a = JSON.parse(localStorage.getItem('md-pp-tm')); for (const k in a) a[k].t0 -= ms; localStorage.setItem('md-pp-tm', JSON.stringify(a)); ppTmTick(); }, ms);
  console.log('idle', await bar());
  await p.click('#pptm'); await p.waitForTimeout(300); await shot('pop');
  console.log('pop', await E(() => $('#tpop').innerText.replace(/\n+/g, ' | ')));
  for (let i = 0; i < 3; i++) await p.click('[data-act="pp-tm-step"][data-d="-5"]'); for (let i = 0; i < 5; i++) await p.click('[data-act="pp-tm-rstep"][data-d="1"]');
  console.log('draft', await E(() => [$('#pptmh').value + 'h ' + $('#pptmm').value, JSON.stringify(ppTmDraft)]));
  await p.click('[data-act="pp-tm-start"]'); await p.waitForTimeout(1200); console.log('start', await bar()); await shot('run');
  await shift(10 * 60000 + 2000); await p.waitForTimeout(300); console.log('after reading', await bar());
  await shift(140 * 60000); await p.waitForTimeout(300); console.log('-30', await bar());
  await shift(22 * 60000); await p.waitForTimeout(300); console.log("-5", await bar()); await shot('warn');
  await shift(10 * 60000); await p.waitForTimeout(300); console.log('over', await bar()); await shot('over');
  await p.keyboard.press('t'); await p.waitForTimeout(1300); console.log('paused T', await bar());
  await p.click('#pptm'); await p.waitForTimeout(300); console.log('pop run', await E(() => $('#tpop').innerText.replace(/\n+/g, ' | '))); await shot('poprun');
  await p.click('#pptm'); await p.waitForTimeout(200); console.log('toggle closed', await E(() => !!$('#tpop')));
  await p.click('#pptm'); await p.click('[data-act="pp-tm-stop"]'); await p.waitForTimeout(500);
  console.log('stopped', await bar(), await E(() => { const pp = Object.values(S.settings.papers)[0]; return [pp.took, pp.lim, $('.ppsum')?.innerText.replace(/\n+/g, ' | ')]; }));
  await shot('took');
  // finish marking stops a running timer
  await p.click('#pptm'); await p.click('[data-act="pp-tm-start"]'); await shift(30 * 60000); await p.click('[data-act="pp-finish"]'); await p.waitForTimeout(500);
  console.log('finish', await E(() => { const pp = Object.values(S.settings.papers)[0]; return [view.name, pp.took, localStorage.getItem('md-pp-tm')]; }));
  // full screen shows the timer
};
