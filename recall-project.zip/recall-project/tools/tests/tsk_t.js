// Progress › Tasks (ticked-off tasks per day and week) and the "your study timer stopped" notification.
// node tsk_t.js W H tag          (web build; add DESK=1 for the desktop page with a mocked window.desktop)
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]]; const DESK = !!process.env.DESK;
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8775);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const mob = W <= 700;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, hasTouch: mob, isMobile: mob, userAgent: mob ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1' : undefined }); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message + ' @ ' + (e.stack || '').split('\n').slice(1, 3).join(' ')));
  const V = path.resolve(__dirname, '../../app/app/vendor') + '/';
  await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)|supabase\.co/, route => { const u = route.request().url(); if (u.includes('supabase.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(V + 'supabase.js') }); route.fulfill({ status: 200, body: '' }); });
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(([lib, desk]) => {
    // record notifications instead of showing them
    window.__notes = []; window.Notification = function(t, o){ __notes.push(['page', t, o?.body, o?.tag]); this.close = () => __notes.push(['closed']); }; Notification.permission = 'granted'; Notification.requestPermission = async () => 'granted';
    if (desk){ const db = JSON.parse(lib); window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.27.0', build: '1', updated: false }), checkUpdate: async () => ({}), onUpdate() {} }; }
    else if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib);
  }, [lib, DESK]);
  await p.goto(DESK ? 'file://' + path.resolve(__dirname, '../../app/app/index.html') : 'http://127.0.0.1:8775/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), shot = async n => { await p.waitForTimeout(250); await p.screenshot({ path: `/tmp/tsk_${TAG}_${n}.png`, fullPage: false }); };
  // three weeks of ticked tasks in the log, a couple of ticked tasks only on the list, one ticked then unticked
  await E(() => {
    const subs = kids(null).map(n => n.id), now = Date.now(), log = [], todos = [];
    for (let d = 20; d >= 0; d--){ if (d % 5 === 4) continue; const n = (d * 7) % 5 + 1; for (let i = 0; i < n; i++){ const t = new Date(now - d * 864e5); t.setHours(9 + i * 2, 15, 0, 0); if (t > now) continue; log.push({ id: 'tl' + d + '_' + i, s: i % 3 === 2 ? null : subs[(d + i) % subs.length], t: +t, l: 'today', n: ['Finish Ext 2 integration set', 'Read Module 7 notes', 'Eco essay plan', 'Redo 2023 HSC Q14', 'Physics depth study log'][i % 5] }); } }
    const t1 = new Date(); t1.setHours(Math.max(5, new Date().getHours() - 1), 5, 0, 0);
    todos.push({ id: 'tdA', t: 'Marked paper (no log entry)', s: subs[0], l: 'today', done: +t1 }, { id: 'tdB', t: 'Open task', s: subs[1], l: 'today', done: 0 }, { id: 'tdC', t: 'Unticked again', s: subs[1], l: 'today', done: 0 });
    log.push({ id: 'tdC', s: subs[1], t: now - 60e3, l: 'today' });
    S.settings = { ...S.settings, todos: [...todoAll().filter(x => !/^td[ABC]$/.test(x.id)), ...todos], todoDone: log }; saveSettings();
    document.querySelector('#layer').innerHTML = ''; go('todo');
  });
  await shot('0plan');
  console.log('plan line:', await E(() => document.querySelector('.tskline')?.textContent));
  await p.click('.tskline'); await p.waitForTimeout(250);
  console.log('view:', await E(() => [view.name, document.querySelector('.hrsswitch [aria-selected="true"]')?.textContent, tsk.mode]));
  await shot('1week');
  const wk = () => E(() => [document.querySelector('.hrsstep h1').textContent, document.querySelector('.hrsbig b').textContent, document.querySelector('.hdelta')?.textContent, [...document.querySelectorAll('.hrsfacts dd')].map(x => x.textContent).join(' | '), [...document.querySelectorAll('.hwd .hwv')].map(x => x.textContent || '0').join(','), document.querySelectorAll('.hrsalloc li').length]);
  console.log('week:', await wk());
  console.log('check today count:', await E(() => { const t = fDay(); return [tskAll().filter(x => fDay(x.t) === t).length, tskAll().some(x => x.id === 'tdC'), tskAll().some(x => x.id === 'tdA')]; }));
  await p.click('[data-act="tsk-step"][data-v="-1"]'); console.log('prev week:', await wk());
  console.log('next enabled:', await E(() => !document.querySelector('[data-act="tsk-step"][data-v="1"]').disabled), 'this week btn:', await E(() => !!document.querySelector('[data-act="tsk-today"]')));
  await p.click('.hwd:not(.future) >> nth=2'); await p.waitForTimeout(200);
  console.log('clicked day ->', await E(() => [tsk.mode, tsk.at, document.querySelector('.hrsbig b').textContent, document.querySelectorAll('.tskl li').length, document.querySelector('.tskl li')?.textContent]));
  await shot('2day');
  await p.click('[data-act="tsk-today"]'); console.log('today:', await E(() => [document.querySelector('.hrsstep h1').textContent, document.querySelector('.hrsbig b').textContent, [...document.querySelectorAll('.hrsfacts dt')].map(x => x.textContent).join(' | '), [...document.querySelectorAll('.tskl li .hnm')].map(x => x.textContent).join(' / ')]));
  await shot('3today');
  // switch tabs both ways
  await p.click('[data-act="hrs-open"]'); console.log('-> study time:', await E(() => view.name));
  await p.click('[data-act="tsk-open"]'); await p.click('[data-act="hrs-cards"]'); console.log('-> cards:', await E(() => [view.name, !!document.querySelector('[data-act="tsk-open"]')]));
  // ticking a task logs its title
  await E(() => { todoDone('tdB'); }); console.log('log entry:', await E(() => JSON.stringify(todoDoneLog().at(-1))));
  // horizontal overflow
  await E(() => go('tasks')); console.log('h-scroll:', await E(() => document.documentElement.scrollWidth > innerWidth + 1));
  // ---- timer notification ----
  await E(() => { focus = { ...focus, state: 'studying', subj: 'Maths', since: Date.now() - 42 * 60e3 - 7e3, acc: 0, dev: FDEV }; fSave(); });
  const hide = h => E(h => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => h }); Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => h ? 'hidden' : 'visible' }); document.dispatchEvent(new Event('visibilitychange')); }, h);
  if (DESK){
    await E(() => { window.dispatchEvent(new Event('blur')); document.hasFocus = () => false; }); await p.waitForTimeout(10600);
  } else await hide(true);
  await p.waitForTimeout(300);
  console.log('after leaving:', await E(() => [focus.state, focus.by, JSON.stringify(__notes)]));
  await hide(false); if (DESK) await E(() => { document.hasFocus = () => true; window.dispatchEvent(new Event('focus')); });
  await p.waitForTimeout(300);
  console.log('back:', await E(() => [JSON.stringify(__notes.slice(-1)), document.querySelector('#grbh')?.textContent]));
  await shot('4back');
  // turned off
  await E(() => { document.querySelector('#layer').innerHTML = ''; ls.set('md-gr-notif', { ...grPrefs(), left: false }); __notes = []; focus = { ...focus, state: 'studying', since: Date.now() - 60e3, dev: FDEV }; fSave(); fPause('left'); });
  console.log('pref off ->', await E(() => __notes.length));
  // permission is asked once when starting
  await E(() => { ls.set('md-gr-notif', { ...grPrefs(), left: true }); ls.del?.('md-f-asked'); localStorage.removeItem('md-f-asked'); Notification.permission = 'default'; window.__asked = 0; Notification.requestPermission = async () => { __asked++; return 'denied'; }; fStop(); });
  await E(() => fStart('Maths')); await E(() => fStop()); await E(() => fStart('Maths')); await E(() => fStop());
  console.log('asked times:', await E(() => __asked), DESK ? '(desktop never asks)' : '');
  console.log('errors:', errs.length ? errs : 'none');
  await b.close(); srv.close();
})();
