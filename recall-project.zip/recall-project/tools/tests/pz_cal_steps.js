module.exports = async (p, E, shot) => {
  const M = !!process.env.MOBILE, log = (...a) => console.log(...a);
  const day = n => E(n => dayKey(Date.now() + n * DAY), n);
  await E(() => { const s = { ...S.settings, todos: [{ id: 'k1', t: 'Old scheduled task', s: null, done: 0, at: 1, l: 'later', day: dayKey(Date.now() - 2 * DAY) }], events: [] }; delete s.countdown; S.settings = s; go('cal'); }); await p.waitForTimeout(500);
  const rows = () => E(() => [...document.querySelectorAll('.calg')].map(g => (g.querySelector('h2')?.innerText || 'earlier') + ': ' + [...g.querySelectorAll('.calr')].map(r => r.querySelector('.calt').innerText + ' [' + r.querySelector('.calmeta').innerText.trim() + ' | ' + r.querySelector('.calleft').innerText + ']').join('; ')).join(' || '));
  log('empty', await E(() => $('.calph').innerText.replace(/\n/g, ' | ')), '|', await rows(), '| rolled', await E(() => todoAll()[0].l));
  const add = async (t, n, k, subj) => { await p.fill('#calt', t); await p.fill('#cald', await day(n)); await p.selectOption('#calk', k); if (subj) await p.selectOption('#cals', { index: subj }); await p.focus('#calt'); await p.keyboard.press('Enter'); await p.waitForTimeout(300); };
  await add('Ext 1 assessment task', 3, 'exam', 1); await add('Depth study report', 5, 'due', 2); await add('Finish worksheet 4', 1, 'task', 1); await add('Ext 2 topic test', 20, 'exam', 1); await add('Last week thing', -3, 'event');
  await p.click('.calph h1'); await p.waitForTimeout(100);
  log('head', await E(() => $('.calph').innerText.replace(/\n/g, ' | '))); log('rows', await rows());
  log('task', JSON.stringify(await E(() => todoAll().filter(x => x.t === 'Finish worksheet 4').map(x => ({ l: x.l, day: x.day })))));
  log('countdown', JSON.stringify(await E(() => ({ on: cdOn(), auto: cdGet()?.auto, name: cdGet()?.name, n: cdGet()?.exams.length, days: cdDaysTo(cdTarget()), pill: (document.querySelector('.cdpill')?.innerText || '').replace(/\n/g, ' ') }))));
  await shot('cal');
  // mini month day pick, month arrows
  await p.click('.calmg button.now + button'); await p.waitForTimeout(200); log('pick', await E(() => [$('#cald').value === dayKey(Date.now() + DAY), !!$('.calmg .pick')]));
  const mon = () => E(() => [$('.calnav b').innerText, $('.calph h1').innerText, $('.calmh b').innerText, document.querySelectorAll('.calr').length, $('#cald').value.slice(0, 7), !!$('.calnav .btn')].join(' | '));
  log('this month', await mon());
  await p.click('.calnavb[data-d="1"]'); await p.waitForTimeout(250); log('next', await mon()); await shot('next');
  await p.click('.calnavb[data-d="1"]'); await p.waitForTimeout(250); log('next 2', await mon());
  await p.fill('#calt', 'Thing in a far month'); await p.focus('#calt'); await p.keyboard.press('Enter'); await p.waitForTimeout(300); log('added there', await mon());
  await p.click('.calnavb[data-d="-1"]'); await p.click('.calnavb[data-d="-1"]'); await p.click('.calnavb[data-d="-1"]'); await p.waitForTimeout(250); log('previous month', await mon());
  await p.click('.calnav .btn'); await p.waitForTimeout(250); log('today', await mon());
  // edit an event: move the exam later, then the countdown follows
  await p.locator('.calmain', { hasText: 'Ext 1 assessment task' }).click(); await p.waitForTimeout(300); await shot('edit');
  await p.fill('#ced', await day(30)); await p.click('[data-act="cal-save"]'); await p.waitForTimeout(400);
  log('after edit countdown', JSON.stringify(await E(() => ({ name: cdGet().name, days: cdDaysTo(cdTarget()) }))));
  // tick the task, undo with the button
  await p.click('.calck >> nth=0'); await p.waitForTimeout(300); log('ticked', await E(() => todoAll().filter(x => x.done).length), '|', await E(() => $('#toast').innerText.replace(/\n/g, ' '))); await p.click('#toast .toastundo'); await p.waitForTimeout(400); log('undo', await E(() => todoAll().filter(x => x.done).length));
  // earlier
  await p.click('[data-act="cal-past"]'); await p.waitForTimeout(200); log('earlier', (await rows()).split(' || ').pop());
  // delete event + undo
  await p.locator('.calmain', { hasText: 'Depth study report' }).click(); await p.waitForTimeout(250); await p.click('[data-act="cal-del"]'); await p.waitForTimeout(300); log('deleted', await E(() => calEvents().length)); await p.click('#toast .toastundo'); await p.waitForTimeout(300); log('undo', await E(() => calEvents().length));
  // manual countdown block: its exams show; clock counts to whichever is first
  await E(() => { S.settings = { ...S.settings, countdown: { name: 'Trials', start: '', end: '', exams: [{ id: 'x1', name: 'Physics trial', subj: '', date: dayKey(Date.now() + 10 * DAY), time: '09:00' }] } }; render(); }); await p.waitForTimeout(300);
  log('manual block', JSON.stringify(await E(() => ({ auto: !!cdGet().auto, name: cdGet().name, days: cdDaysTo(cdTarget()), inCal: calItems().some(x => x.src === 'cd') }))));
  // to-do page: chip + menu
  await E(() => { todoTab = 'later'; go('todo'); }); await p.waitForTimeout(400);
  log('todo chip', await E(() => [...document.querySelectorAll('#tdo .tdday')].map(b => b.innerText).join(',')), '| today list', await E(() => todoAll().filter(x => x.l === 'today').map(x => x.t).join(',')));
  const tid = await E(() => todoAll().find(x => x.t === 'Finish worksheet 4').id);
  await p.hover(`[data-tid="${tid}"] .tdt`); await p.click(`[data-tid="${tid}"] .tdmore2`); await p.waitForTimeout(200); log('menu', await E(() => $('#menu').innerText.split('\n')[0]));
  await p.click('#menu [data-act="cal-edit"]'); await p.waitForTimeout(300); await p.fill('#ced', await day(2)); await p.click('[data-act="cal-save"]'); await p.waitForTimeout(400);
  log('rescheduled', await E(id => todoAll().find(x => x.id === id).day === dayKey(Date.now() + 2 * DAY), tid), '| chip', await E(id => document.querySelector(`[data-tid="${id}"] .tdday`)?.innerText, tid));
  await p.click(`[data-tid="${tid}"] .tdday`); await p.waitForTimeout(300); await p.click('[data-act="cal-del"]'); await p.waitForTimeout(300); log('off calendar', await E(id => todoAll().find(x => x.id === id).day, tid));
  await shot('todo');
  // nav
  log('nav', await E(() => [...document.querySelectorAll('.toolbar nav > *, #side [data-nav]')].filter(b => b.offsetParent).map(b => b.innerText.trim()).join(' ')));
  if (!M){ await p.keyboard.press('c'); await p.waitForTimeout(300); log('C key', await E(() => view.name)); }
  await E(() => go('decks')); await p.waitForTimeout(400); log('decks card', await E(() => ($('.cdcard')?.innerText || '').replace(/\n+/g, ' | ').slice(0, 160))); await shot('decks');
};
