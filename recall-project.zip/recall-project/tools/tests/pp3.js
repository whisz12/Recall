// Web app: THSC papers through the download service, and settings that merge key by key when syncing.
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path'), http = require('http');
const FX = process.env.FX || '/tmp/thsc/fx', PDF = process.env.PDF || '/tmp/pptest/nsb2023.pdf';
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const ctx = await b.newContext({ viewport: { width: 1180, height: 820 } }); const p = await ctx.newPage(); p.setDefaultTimeout(8000);
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  const V = path.resolve(__dirname, '../../app/app/vendor') + '/', root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'application/octet-stream' }); fs.createReadStream(f).pipe(r); }).listen(8773);
  await ctx.route(/raw\.githubusercontent\.com\/thsconline/, r => { const f = path.join(FX, new URL(r.request().url()).pathname.replace(/^.*\/yr12\//, '')); r.fulfill(fs.existsSync(f) ? { status: 200, contentType: 'text/html', body: fs.readFileSync(f) } : { status: 404, body: '' }); });
  await ctx.route(/cdn\.jsdelivr\.net/, r => { const u = r.request().url(), m = u.includes('pdf.worker') ? V + 'pdf.worker.min.js' : u.includes('pdf.min') ? V + 'pdf.min.js' : null; r.fulfill(m ? { status: 200, contentType: 'text/javascript', body: fs.readFileSync(m) } : { status: 200, contentType: 'text/javascript', body: '' }); });
  let fnCalls = [];
  await ctx.route(/\/functions\/v1\/thsc-paper/, async r => { const req = r.request(); if (req.method() === 'OPTIONS') return r.fulfill({ status: 200, headers: { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*' } }); const body = JSON.parse(req.postData() || '{}'); fnCalls.push({ auth: req.headers().authorization, body }); if (body.title.includes('2019')) return r.fulfill({ status: 502, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ error: 'THSC replied 503' }) }); r.fulfill({ status: 200, contentType: 'application/pdf', headers: { 'access-control-allow-origin': '*', 'access-control-expose-headers': 'x-file-name', 'x-file-name': encodeURIComponent(body.title + '.pdf') }, body: fs.readFileSync(PDF) }); });
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
  await p.goto('http://127.0.0.1:8773/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a), out = {};
  // pretend sync is on (only the parts the download needs)
  await E(() => { cloud.sb = { auth: { getSession: async () => ({ data: { session: { access_token: 'tok' } } }) }, from: () => ({ upsert: async () => ({}), select: () => ({ maybeSingle: async () => ({ data: null }) }) }), storage: { from: () => ({ upload: async () => ({ error: new Error('no') }) }) } }; cloud.user = { id: 'u1', email: 'x' }; });
  await E(() => { pp.s = 'physics'; go('papers'); }); await p.waitForSelector('.pphome .pprow', { timeout: 8000 });
  await p.selectOption('#ppschool', 'Knox'); await p.waitForTimeout(150);
  await p.click('.pprow .ppyr >> text=2022'); await p.waitForSelector('#ppm .ppsq', { timeout: 15000 });
  out.relay = await E(() => ({ view: view.name, title: ppTitle(ppmP()), items: ppm.items.length }));
  out.calls = fnCalls.map(c => c.auth + ' ' + c.body.no + ' ' + c.body.title);
  await E(() => go('papers')); await p.waitForTimeout(200); await p.click('.pprow .ppyr >> text=2021'); await p.waitForSelector('#ppm .ppsq', { timeout: 15000 }).catch(() => {});
  await E(() => go('papers')); await p.waitForTimeout(200); await p.selectOption('#ppschool', 'James Ruse'); await p.waitForTimeout(150); await p.click('.pprow .ppyr >> text=2019'); await p.waitForTimeout(800);
  out.fail = await E(() => $('#layer .dialog .ppwarn')?.innerText);
  await E(() => closeDialog());
  // settings: a device with old settings saves something unrelated; the merge keeps the newer newPerDay
  out.merge = await E(async () => {
    S.settings.newPerDay = 20; setSnap = clone(S.settings); delete S.settings._t;
    const remote = { ...cloudSettingsOut(), newPerDay: 999 }; delete remote._t;
    S.settings.papers = { ...(S.settings.papers || {}), z: { id: 'z' } }; await saveSettings();   // local unrelated change, stamped
    cloudSettingsIn({ data: remote, updated_at: 1 });
    const a = { newPerDay: S.settings.newPerDay, keptLocalPaper: !!S.settings.papers?.z, stamped: Object.keys(S.settings._t || {}) };
    S.settings.newPerDay = 50; await saveSettings(); const t50 = S.settings._t.newPerDay;
    cloudSettingsIn({ data: { ...cloudSettingsOut(), newPerDay: 999, _t: { ...S.settings._t, newPerDay: t50 - 1000 } }, updated_at: Date.now() + 99999 });
    return { ...a, localNewerKept: S.settings.newPerDay, t50, tAfter: S.settings._t?.newPerDay, applying: cloud.applying };
  });
  console.log(JSON.stringify(out, null, 1)); console.log('ERRORS', errs.length ? errs : 'none'); await b.close(); srv.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
