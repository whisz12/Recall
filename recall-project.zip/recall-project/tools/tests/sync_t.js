const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, decodeURIComponent(new URL(q.url, 'http://x').pathname)); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8778);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const V = path.resolve(__dirname, '../../app/app/vendor') + '/', lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  const pages = {}, errs = [];
  for (const [name, W, H, ua] of [['phone', 390, 844, 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1'], ['laptop', 1280, 800, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15']]){
    const ctx = await b.newContext({ viewport: { width: W, height: H }, userAgent: ua }); const p = await ctx.newPage(); pages[name] = p;
    p.on('pageerror', e => errs.push(name + ': ' + e.message));
    await p.route(/cdn\.jsdelivr\.net|fonts\.(googleapis|gstatic)|supabase\.co/, route => { const u = route.request().url(); if (u.includes('supabase.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: fs.readFileSync(V + 'supabase.js') }); route.fulfill({ status: 200, body: '' }); });
    await p.addInitScript(lib => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', lib); }, lib);
    await p.addInitScript(fs.readFileSync(path.join(__dirname, 'grfake.js'), 'utf8'));
    await p.exposeFunction('__relay', j => { const other = pages[name === 'phone' ? 'laptop' : 'phone']; other?.evaluate(j => window.__deliver(j), j).catch(() => {}); });
  }
  for (const p of Object.values(pages)){ await p.goto('http://127.0.0.1:8778/'); }
  await pages.laptop.waitForTimeout(1800);
  for (const p of Object.values(pages)) await p.evaluate(() => { document.querySelector('#layer').innerHTML = ''; const uid = 'aaaaaaaa-0000-4000-8000-000000000001'; cloud.sb = __grFake(uid); cloud.user = { id: uid, email: 'j@x.com' }; });
  await pages.laptop.waitForTimeout(3600);
  const st = async n => pages[n].evaluate(() => ({ state: focus.state, subj: focus.subj, secs: Math.round(fSecs()), owner: focus.dev === FDEV ? 'me' : 'other', pill: document.querySelector('#fpill')?.textContent || '' }));
  // phone starts studying Physics
  await pages.phone.evaluate(() => fStart('Physics')); await pages.phone.waitForTimeout(600);
  console.log('phone started  phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  // pretend 25 minutes passed on the phone
  await pages.phone.evaluate(() => { focus.since -= 25 * 60e3; focus.t = Date.now(); fSave(); fsSend(); }); await pages.phone.waitForTimeout(400);
  console.log('25 min in      phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  // laptop in the background: must NOT pause
  await pages.laptop.evaluate(() => { Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); Object.defineProperty(document, 'hidden', { value: false, configurable: true }); });
  await pages.laptop.waitForTimeout(300);
  console.log('laptop hidden  phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  // laptop presses Take a break -> phone pauses
  await pages.laptop.evaluate(() => fPause('you')); await pages.laptop.waitForTimeout(600);
  console.log('laptop break   phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  // laptop carries on -> laptop owns it, phone mirrors
  await pages.laptop.evaluate(() => fStart('Maths')); await pages.laptop.waitForTimeout(600);
  console.log('laptop resumes phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  // phone leaves the app: it's not running the timer, so nothing pauses
  await pages.phone.evaluate(() => { Object.defineProperty(document, 'hidden', { value: true, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); Object.defineProperty(document, 'hidden', { value: false, configurable: true }); });
  await pages.phone.waitForTimeout(400);
  console.log('phone left     phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  // stop on phone -> laptop stops
  await pages.phone.evaluate(() => fStop()); await pages.phone.waitForTimeout(600);
  console.log('phone stop     phone', JSON.stringify(await st('phone')), ' laptop', JSON.stringify(await st('laptop')));
  console.log('sessions logged: phone', await pages.phone.evaluate(() => fLog.length), 'laptop', await pages.laptop.evaluate(() => fLog.length));
  // stats on the laptop show today's total
  await pages.laptop.evaluate(() => { go('hours'); }); console.log('laptop stats today:', await pages.laptop.evaluate(() => document.querySelector('.hrsbig b').textContent));
  console.log('errors', errs.filter(e => !/cloudFetchUrls|reading 'from'/.test(e)));
  await b.close(); srv.close();
})();
