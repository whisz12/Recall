// Browse → Paper mistakes: from Past papers, from a paper's menu, the chip in Browse; switching decks clears it; adding a card from there is safe
module.exports = async (p, E, shot) => {
  // make two paper cards
  await E(() => { const node = Object.values(S.nodes).find(n => !kids(n.id).length); ppm.node = node.id; });
  for (const i of [1, 3]){ await E(i => ppmPick(i), i); await p.waitForTimeout(200); await p.keyboard.press('3'); await p.waitForTimeout(200); await p.click('#ppwhy'); await p.keyboard.type('mistake ' + i); await p.click('.ppsave'); await p.waitForTimeout(2500); }
  const pid = await E(() => ppm.pid);
  console.log('paper cards', await E(() => ppCards().length));
  // from the past papers page toolbar
  await E(() => { ppm = null; go('papers'); }); await p.waitForTimeout(800);
  console.log('toolbar btn', await E(() => !!$('[data-act="pp-browse"]')));
  await p.click('[data-act="pp-browse"]'); await p.waitForTimeout(800);
  const st = () => E(() => JSON.stringify({ view: view.name, node: browse.node, rows: document.querySelectorAll('#brrows .brow').length, deck: $('#bdeckbtn')?.innerText.trim(), src: $('#brprev .ppsrcl')?.innerText.replace(/\n/g, ' ') || '', rowMeta: $('#brrows .brow .brd')?.innerText || '' }));
  console.log('browse all', await st()); await shot('browse');
  // clear → all decks, chip brings it back
  await p.click('[data-act="bnode"]'); await p.waitForTimeout(400); console.log('cleared', await st(), await E(() => !!$('[data-act="bpp"]')));
  await p.click('[data-act="bpp"]'); await p.waitForTimeout(400); console.log('chip', await st());
  // add card from here: no broken deck
  await E(() => editor(null, view.node || brRef())); await p.waitForTimeout(500); console.log('editor deck', await E(() => JSON.stringify({ nodeId: ed?.card.nodeId, ok: !!S.nodes[ed?.card.nodeId] }))); await E(() => { ed = null; closeDialog?.(); render(); });
  // a paper's menu → just that paper
  await E(pid => browsePapers(pid), pid); await p.waitForTimeout(500); console.log('one paper', await st());
  // picking a deck replaces it
  await E(() => { browse.node = Object.values(S.nodes).find(n => !n.parentId).id; renderBrowse(); }); await p.waitForTimeout(300); console.log('deck picked', await st());
};
