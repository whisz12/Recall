/* ===================== Memorise (24 Nov 2026) =====================
   Projects of text to learn word for word (essays, speeches, quotes). Each project is one settings key (mm_<id>), so it syncs
   between devices key by key and edits can be undone like other settings.
   Home: projects | the text (pick what to practise, format it) | practise panel. Ten modes in three groups, each Easy/Medium/Hard,
   modelled on Memorize by Heart. Every session records accuracy per word and per paragraph; paragraphs come back due on a schedule.
   Phone (≤700px): projects list → a project → a practise sheet, one thing per screen. */
const MM_MODES = [
  { k: 'reveal', n: 'Tap to reveal', g: 'Familiarise', d: ['The text starts hidden. Say each sentence, then reveal it and mark it.', 'Say each phrase, then reveal it and mark it.', 'Reveal one word at a time: Space if you knew it, X if you didn’t.'], w: [.3, .35, .4] },
  { k: 'slider', n: 'Slider', g: 'Familiarise', d: ['Drag to hide up to 30% of the words, then say it through. Tap a gap to peek.', 'Hide up to 60% of the words.', 'Hide every word. Tap a gap to peek.'], w: [.3, .4, .5] },
  { k: 'listen', n: 'Listen', g: 'Familiarise', d: ['Hear it read at 0.8× with the text shown.', 'Hear it at normal speed with the text shown.', 'Hear it at normal speed with the text hidden.'], w: [0, 0, 0] },
  { k: 'first', n: 'First letters', g: 'Solidify', d: ['Every word shows its first letter. Type the letters in order.', 'Only the next word’s first letter appears, once you finish the one before.', 'No letters shown. Type each word’s first letter from memory.'], w: [.5, .6, .7] },
  { k: 'blanks', n: 'Blanks', g: 'Solidify', d: ['Fill in 1 word in 5 from a word bank.', 'Type 1 word in 3, no word bank.', 'Type every other word, no word bank.'], w: [.45, .55, .65] },
  { k: 'reorder', n: 'Reorder', g: 'Solidify', d: ['Put up to 10 chunks back in order.', 'Put up to 20 chunks back in order.', 'Put up to 30 smaller chunks back in order.'], w: [.35, .45, .55] },
  { k: 'target', n: 'Target it', g: 'Solidify', d: ['A few words have been swapped. Tap the ones that are wrong.', 'One word in every sentence has been swapped.', 'Lots of swaps, including small words like “a” and “the”.'], w: [.4, .5, .6] },
  { k: 'type', n: 'Type it', g: 'Evaluate', d: ['Type just the first letter of every word.', 'First letters shown. Type every word in full.', 'Type the whole passage word for word, no hints.'], w: [.7, .9, 1] },
  { k: 'choice', n: 'Multiple choice', g: 'Evaluate', d: ['Rebuild it one word at a time from 2 choices.', 'Rebuild it from 4 choices.', 'Rebuild it from 6 choices, no skips.'], w: [.5, .6, .7] },
  { k: 'speak', n: 'Speak', g: 'Evaluate', d: ['Say it out loud with the first letter of every word shown.', 'Say it out loud with the first letter of every other word.', 'Say it out loud from memory, no hints.'], w: [.8, .9, 1] }
];
const MM_GROUPS = ['Familiarise', 'Solidify', 'Evaluate'];
const MM_DIFF = ['Easy', 'Medium', 'Hard'];
const MM_COLS = [['Amber', '#D99A2B'], ['Coral', '#E5675C'], ['Green', '#4FA85A'], ['Blue', '#4C86E0'], ['Violet', '#9B6FE0'], ['Text colour', 'var(--fg)']];
const MM_IC = {
  reveal: '<path d="M7 10V4.5a1.3 1.3 0 0 1 2.6 0V9"/><path d="M9.6 8.5V7.6a1.3 1.3 0 0 1 2.6 0v1.4"/><path d="M12.2 8.8a1.3 1.3 0 0 1 2.6 0V12a5 5 0 0 1-5 5h-.6a4.6 4.6 0 0 1-3.7-1.9L3.6 12.5a1.3 1.3 0 0 1 2-1.6L7 12.4"/>',
  slider: '<path d="M3 6h14M3 14h14"/><circle cx="7" cy="6" r="2"/><circle cx="13" cy="14" r="2"/>',
  listen: '<path d="M4 8v4h3l4 3V5L7 8z"/><path d="M14 7.5a3.5 3.5 0 0 1 0 5"/>',
  first: '<path d="M3 15l3-9 3 9M4.2 12h3.6M11.5 6h3a2 2 0 0 1 0 4h-3zM11.5 10h3.4a2.5 2.5 0 0 1 0 5h-3.4z"/>',
  blanks: '<rect x="3" y="5" width="14" height="10" rx="2"/><path d="M6 10h.01M9 10h.01M12 10h2"/>',
  reorder: '<path d="M3 6h9M3 10h6M3 14h6"/><path d="M14 9v7M11.5 13.5L14 16l2.5-2.5"/>',
  target: '<circle cx="10" cy="10" r="6.5"/><circle cx="10" cy="10" r="3"/><circle cx="10" cy="10" r=".5"/>',
  type: '<rect x="2.5" y="5" width="15" height="10" rx="2"/><path d="M5.5 8h.01M8.5 8h.01M11.5 8h.01M14.5 8h.01M7 12h6"/>',
  choice: '<path d="M3 6l1.5 1.5L7 5M3 13l1.5 1.5L7 12M10 6.5h7M10 13.5h7"/>',
  speak: '<rect x="7.5" y="3" width="5" height="9" rx="2.5"/><path d="M5 10a5 5 0 0 0 10 0M10 15v2.5"/>'
};
const mmIcon = (k, s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${MM_IC[k] || ''}</svg>`;
const mmMode = k => MM_MODES.find(m => m.k === k) || MM_MODES[3];
const mm = { bank: ls.get('mm-bank', 'v'), bq: '', bf: 'all', navh: ls.get('mm-navh', false), hist: [], pid: ls.get('mm-pid', null), sel: new Set(), range: null, mode: ls.get('mm-mode', 'first'), diff: ls.get('mm-diff', 1), tab: ls.get('mm-tab', 'projects'), g: ls.get('mm-g', 'common'), screen: 'list', sheet: false, run: null, tool: 'h', selW: null, wasPhone: null };
const mmPhone = () => innerWidth <= 700 && !document.body.classList.contains('desktop');

/* ---------- projects ---------- */
const mmKey = id => 'mm_' + id;
const mmAll = () => Object.keys(S.settings || {}).filter(k => k.startsWith('mm_') && S.settings[k]?.id).map(k => S.settings[k]).sort((a, b) => (b.used || b.at || 0) - (a.used || a.at || 0));
const mmGet = id => (id && S.settings?.[mmKey(id)]) || null;
function mmCur(){ let p = mmGet(mm.pid); if (!p){ p = mmAll()[0] || null; if (p && mm.pid !== p.id){ mm.pid = p.id; mm.sel.clear(); mm.range = null; } } return p; }
function mmPut(p, label, raw){
  if (!raw){ undoTx = null; undoLabel = label || 'memorise'; }
  S.settings = { ...S.settings, [mmKey(p.id)]: p };
  return raw ? saveSettingsRaw() : saveSettings();
}
function mmRemove(id){ undoTx = null; undoLabel = 'delete project'; const s = { ...S.settings }; delete s[mmKey(id)]; S.settings = s; saveSettings(); }
function mmPick(id){ if (mm.pid !== id){ mm.sel.clear(); mm.range = null; } mm.pid = id; ls.set('mm-pid', id); mm.screen = 'project'; mm.sheet = false; mm.selW = null; }

/* ---------- text: paragraphs → words → sentences ---------- */
const MM_ABBR = /^(mr|mrs|ms|mx|dr|prof|st|vs|etc|e\.g|i\.e|cf|no|vol|pp?|jr|sr|fig|approx)\.$/i;
const mmNorm = t => String(t).toLowerCase().replace(/[’‘`]/g, "'").normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}']/gu, '').replace(/^'+|'+$/g, '');
const mmParseCache = new Map();
function mmParse(text){
  text = String(text || '');
  if (mmParseCache.has(text)) return mmParseCache.get(text);
  const lines = text.replace(/\r/g, '').split('\n'), paras = [], gaps = []; let blank = false;
  for (const l of lines){ const t = l.trim(); if (!t){ blank = true; continue; } paras.push(t); gaps.push(blank); blank = false; }
  const W = [], P = []; let s = 0;
  paras.forEach((pt, pi) => {
    const toks = pt.split(/\s+/).filter(Boolean), a = W.length;
    toks.forEach((t, k) => {
      const core = mmNorm(t), f = (t.match(/[\p{L}\p{N}]/u) || [''])[0].toLowerCase();
      W.push({ t, p: pi, s, core, f });
      const bare = t.replace(/["“”‘’()[\]]/g, '');
      if ((/[.!?…]["”’')\]]*$/.test(t) && !MM_ABBR.test(bare)) || k === toks.length - 1) s++;
    });
    P.push({ a, b: W.length - 1, gap: gaps[pi] });
  });
  const out = { W, P, nS: s };
  if (mmParseCache.size > 12) mmParseCache.delete(mmParseCache.keys().next().value);
  mmParseCache.set(text, out); return out;
}
const mmParsed = p => mmParse(p?.text);
/* Sections: each line of text is a paragraph; a section is one or more paragraphs with a role (intro, body, conclusion, other).
   Roles are yours if you set them (Edit sections, p.roles), otherwise guessed: a line that doesn't finish its sentence, or starts
   in lower case, carries on the paragraph above; only a last section that opens like a conclusion is called one. */
const MM_ROLES = [['intro', 'Introduction'], ['body', 'Body paragraph'], ['concl', 'Conclusion'], ['other', 'Other'], ['join', 'Part of the one above']];
const MM_CONCL = /^\W*(ultimately|in conclusion|to conclude|in summary|in sum|overall|thus|therefore|hence|in essence|in all|consequently|as such|it is clear|clearly|evidently|in the end|finally, (it|the|this|these))\b/i;
function mmAutoRoles(p){
  const { W, P } = mmParsed(p), text = i => W.slice(P[i].a, P[i].b + 1).map(w => w.t).join(' ');
  if (p.kind === 'text') return P.map(() => 'other');
  /* if blank lines separate some paragraphs, a single line break is just a wrapped line inside one */
  const blanks = P.some((pp, i) => i && pp.gap), single = P.some((pp, i) => i && !pp.gap);
  const join = P.map((pp, i) => { if (!i) return false; if (blanks && single) return !pp.gap; const prev = W[P[i - 1].b].t, first = W[pp.a].t; return !/[.!?…:]["”’')\]]*$/.test(prev) || /^[a-z,;)]/.test(first); });
  const starts = P.map((_, i) => i).filter(i => !join[i]), roles = P.map(() => 'join');
  /* the last section is a conclusion only if it opens like one, or is clearly shorter than the body paragraphs before it */
  const secWords = starts.map((i, k) => (k + 1 < starts.length ? P[starts[k + 1] - 1].b : P.at(-1).b) - P[i].a + 1);
  const mid = secWords.slice(1, -1).sort((x, y) => x - y), median = mid.length ? mid[Math.floor(mid.length / 2)] : 0;
  const lastI = starts.at(-1), firstSent = text(lastI).split(/(?<=[.!?])\s/)[0] || '';
  const concl = starts.length >= 3 && (MM_CONCL.test(text(lastI)) || /\b(ultimately|in conclusion|therefore|thus|overall|in essence)\b/i.test(firstSent) || (median && secWords.at(-1) < median * .7));
  starts.forEach((i, k) => { roles[i] = starts.length < 3 ? 'other' : k === 0 ? 'intro' : k === starts.length - 1 && concl ? 'concl' : 'body'; });
  return roles;
}
function mmRoles(p){ const n = mmParsed(p).P.length; const r = Array.isArray(p.roles) && p.roles.length === n ? [...p.roles] : mmAutoRoles(p); if (r[0] === 'join') r[0] = 'other'; return r; }
function mmSections(p){
  const roles = mmRoles(p), out = []; let nb = 0, no = 0;
  roles.forEach((r, i) => { if (r === 'join' && out.length){ out.at(-1).ps.push(i); return; } out.push({ role: r, ps: [i] }); });
  const others = out.filter(x => x.role === 'other').length;
  out.forEach(x => { x.label = x.role === 'intro' ? 'Intro' : x.role === 'concl' ? 'Conclusion' : x.role === 'body' ? 'Body ' + (++nb) : others === 1 && out.length === 1 ? 'Text' : (p.kind === 'text' ? '¶' : 'Part ') + (++no); });
  return out;
}
const mmLabels = p => mmSections(p).map(x => x.label);
function mmSecOf(p){ const m = []; mmSections(p).forEach((x, si) => x.ps.forEach(i => m[i] = si)); return m; }
/* spelling slips within one letter are forgiven for words over four letters */
function mmLev1(a, b){ if (Math.abs(a.length - b.length) > 1) return false; let i = 0, j = 0, d = 0; while (i < a.length && j < b.length){ if (a[i] === b[j]){ i++; j++; continue; } if (++d > 1) return false; if (a.length > b.length) i++; else if (b.length > a.length) j++; else { i++; j++; } } return d + (a.length - i) + (b.length - j) <= 1; }
const mmSame = (typed, core) => { const a = mmNorm(typed); return a === core || (core.length > 4 && mmLev1(a, core)); };
const mmScore = w => !!w.f;   // punctuation-only tokens (— or &) are shown, never tested
function mmRand(seed){ let x = seed >>> 0 || 1; return () => { x ^= x << 13; x >>>= 0; x ^= x >> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; }; }
function mmShuffle(a, rnd){ a = [...a]; for (let i = a.length - 1; i > 0; i--){ const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

/* ---------- formatting: highlight / bold / underline in any colour, stored as word ranges ---------- */
function mmMarkMaps(p, n){
  const M = { h: new Array(n).fill(null), b: new Array(n).fill(null), u: new Array(n).fill(null) };
  (p.marks || []).forEach(m => { if (!M[m.k]) return; for (let i = Math.max(0, m.a); i <= Math.min(n - 1, m.b); i++) M[m.k][i] = m.c; });
  return M;
}
function mmMarksFrom(M){
  const out = [];
  for (const k of ['h', 'b', 'u']){ const a = M[k]; let st = -1, c = null; for (let i = 0; i <= a.length; i++){ const v = i < a.length ? a[i] : null; if (v && v === c) continue; if (c) out.push({ a: st, b: i - 1, k, c }); c = v; st = v ? i : -1; } }
  return out;
}
const mmSafeCol = c => /^(#[0-9a-f]{3,8}|var\(--fg\))$/i.test(String(c || '')) ? c : null;
function mmWStyle(M, i){
  let s = ''; const h = mmSafeCol(M.h[i]), b = mmSafeCol(M.b[i]), u = mmSafeCol(M.u[i]);
  if (h) s += `background:color-mix(in srgb, ${h} 34%, transparent);`;
  if (b) s += `font-weight:600;color:${b};`;
  if (u) s += `text-decoration:underline;text-decoration-color:${u};text-decoration-thickness:2px;text-underline-offset:4px;`;
  return s;
}
function mmGapStyle(M, i){
  let s = ''; const h = mmSafeCol(M.h[i]), u = mmSafeCol(M.u[i]);
  if (h && M.h[i] === M.h[i + 1]) s += `background:color-mix(in srgb, ${h} 34%, transparent);`;
  if (u && M.u[i] === M.u[i + 1]) s += `text-decoration:underline;text-decoration-color:${u};text-decoration-thickness:2px;text-underline-offset:4px;`;
  return s;
}
function mmFormat(k, c){
  const p = mmCur(), r = mm.selW; if (!p || !r) return;
  const n = mmParsed(p).W.length, M = mmMarkMaps(p, n);
  if (k === 'clear'){ for (const t of ['h', 'b', 'u']) for (let i = r.a; i <= r.b; i++) M[t][i] = null; }
  else {
    let all = true; for (let i = r.a; i <= r.b; i++) if (M[k][i] !== c){ all = false; break; }
    for (let i = r.a; i <= r.b; i++) M[k][i] = all ? null : c;   // the same colour again takes it off
  }
  mmPut({ ...p, marks: mmMarksFrom(M) }, 'formatting');
  mm.selW = null; getSelection()?.removeAllRanges(); $('#mmfmt')?.remove(); renderMemo();
}

/* ---------- stats, schedule, level ---------- */
const MM_W = Object.fromEntries(MM_MODES.map(m => [m.k, m.w]));
const mmDay0 = () => new Date().setHours(0, 0, 0, 0);
function mmStats(p){
  const { P } = mmParsed(p), since = Date.now() - 60 * DAY, mast = P.map(() => 0), acc = P.map(() => null);
  for (const h of p.hist || []){
    if (h.acc == null || !h.pa) continue; const w = (MM_W[h.m] || [0, 0, 0])[h.d] || 0;
    for (const [k, a] of Object.entries(h.pa)){ const i = +k; if (!(i < P.length)) continue; if (h.at >= since) mast[i] = Math.max(mast[i], a * w); acc[i] = a; }
  }
  const words = P.map(x => x.b - x.a + 1), tot = words.reduce((a, b) => a + b, 0);
  const memo = tot ? Math.round(mast.reduce((s, m, i) => s + m * words[i], 0) / tot) : 0;
  const rec = (p.hist || []).filter(h => h.acc != null).slice(-10);
  return { mast, acc, words, tot, memo, acc10: rec.length ? Math.round(rec.reduce((s, h) => s + h.acc, 0) / rec.length) : null };
}
const mmLevel = pts => 1 + Math.floor(Math.sqrt((pts || 0) / 40));
function mmDue(p){ const now = Date.now(), n = mmParsed(p).P.length; return Object.entries(p.secs || {}).filter(([i, s]) => +i < n && s?.due && s.due <= now).map(([i]) => +i).sort((a, b) => a - b); }
const mmDueAll = () => mmAll().reduce((n, p) => n + mmDue(p).length, 0);
function mmSched(sec, acc, m, d){
  const now = Date.now(), w = (MM_W[m] || [0, 0, 0])[d] || 0; let ivl = sec?.ivl || 0;
  if (acc >= 90) ivl = Math.max(1, Math.round((ivl || 1) * (acc >= 97 ? 3 : 2.2)));
  else if (acc >= 75) ivl = Math.max(1, Math.round(ivl * 1.2));
  else ivl = 0;
  ivl = Math.min(ivl, Math.max(1, Math.round(60 * w * w)));   // an easy mode can't send a paragraph months away
  return { ...(sec || {}), ivl, due: ivl ? mmDay0() + ivl * DAY + 4 * HOUR : now + 4 * HOUR, last: now };
}
const mmWhen = t => { const d = Math.round((new Date(t).setHours(0, 0, 0, 0) - mmDay0()) / DAY); return d <= 0 ? 'later today' : d === 1 ? 'tomorrow' : `in ${d} days`; };

/* ---------- availability ---------- */
const mmSR = () => window.SpeechRecognition || window.webkitSpeechRecognition || null;
function mmBlocked(k){
  if (k === 'listen' && !('speechSynthesis' in window)) return 'Reading aloud isn’t available on this device.';
  if (k === 'speak'){
    if (window.desktop) return 'Speaking isn’t available in the Mac and Windows apps yet. It works in Safari and Chrome.';
    if (!mmSR()) return 'This browser can’t recognise speech. Safari and Chrome can.';
  }
  return '';
}

/* ---------- what to practise ---------- */
function mmSelIdx(p){
  const { W, P } = mmParsed(p);
  if (mm.range){ const a = Math.max(0, mm.range.a), b = Math.min(W.length - 1, mm.range.b); return a <= b ? Array.from({ length: b - a + 1 }, (_, i) => a + i) : []; }
  const SC = mmSections(p), ps = mm.sel.size ? [...mm.sel].filter(i => i < SC.length).sort((a, b) => a - b).flatMap(i => SC[i].ps) : P.map((_, i) => i);
  return ps.flatMap(i => Array.from({ length: P[i].b - P[i].a + 1 }, (_, k) => P[i].a + k));
}
function mmSelLabel(p){
  const L = mmLabels(p);
  if (mm.range) return 'Your selection';
  if (!mm.sel.size) return L.length === 1 ? L[0] : 'Whole text';
  const ps = [...mm.sel].filter(i => i < L.length).sort((a, b) => a - b); if (!ps.length) return 'Whole text';
  return ps.length > 3 ? `${ps.length} sections` : ps.map(i => L[i]).join(', ');
}
function mmSelAcc(p){
  const st = mmStats(p);
  if (mm.range) return null;
  if (!mm.sel.size) return st.acc10;
  const SC = mmSections(p); let sw = 0, sa = 0; [...mm.sel].forEach(i => (SC[i]?.ps || []).forEach(j => { if (st.acc[j] != null){ sw += st.words[j]; sa += st.acc[j] * st.words[j]; } })); return sw ? Math.round(sa / sw) : null;
}

/* ===================== home ===================== */
function renderMemo(){
  const key = [mm.tab, mm.pid, mm.screen, !!mm.run, mm.run?.done, mm.g, mm.bank].join('|'), keep = mm.lastKey === key ? { m: $('.mmmain')?.scrollTop, n: $('.mmnav')?.scrollTop, pn: $('.mmpanel')?.scrollTop, y: scrollY } : null;
  mm.lastKey = key;
  mmRender0();
  if (keep){ const set = (sel, v) => { const el = $(sel); if (el && v != null) el.scrollTop = v; }; set('.mmmain', keep.m); set('.mmnav', keep.n); set('.mmpanel', keep.pn); if (Math.abs(scrollY - keep.y) > 1) window.scrollTo(0, keep.y); }
  mmBackBtn();
}
function mmRender0(){
  const root = $('#root'), phone = mmPhone(); mm.wasPhone = phone; mm.wk = mmWidthKey();
  document.body.classList.toggle('mmrun', !!mm.run && !mm.run.done);
  root.classList.toggle('mmfull', !mm.run && mm.tab !== 'guide' && !phone && document.body.classList.contains('desktop') && mmAll().length > 0);
  if (mm.run) return mmRenderRun(root);
  if (mm.tab === 'guide') return mmRenderGuide(root, phone);
  if (mm.tab === 'banks') return mmRenderBanks(root, phone);
  const ps = mmAll(), p = mmCur();
  if (!ps.length) return mmRenderEmpty(root, phone);
  if (phone) return mm.screen === 'project' && p ? mmRenderPhoneProject(root, p) : mmRenderPhoneList(root, ps);
  root.innerHTML = `${document.body.classList.contains('desktop') ? '' : mmTopbar()}<div class="mmw${mm.navh ? ' navh' : ''}">
    <nav class="mmnav" aria-label="Projects">${mmNavHtml(ps, p)}</nav>
    <div class="mmmain">${mmProjectHead(p)}${mmChips(p)}<div class="mmtext" id="mmtext">${mmReaderHtml(p)}</div></div>
    <aside class="mmpanel" aria-label="Practise">${mmPanelHtml(p)}</aside></div>`;
}
function mmTopbar(){
  return `<div class="mmtop"><h1>Memorise</h1><span class="grow"></span>${mmTabs()}<button class="btn" data-act="mm-new">New project</button></div>`;
}
const mmTabs = () => `<div class="seg mmtabs" role="group" aria-label="Memorise">${[['projects', 'Projects'], ['banks', 'Banks'], ['guide', 'Rubric guide']].map(([k, n]) => `<button aria-pressed="${(mm.tab || 'projects') === k}" data-act="mm-tab" data-v="${k}">${n}</button>`).join('')}</div>`;
function mmSubCol(p){ return p.sid && S.nodes[p.sid] ? scol(p.sid) : 'var(--fg-3)'; }
function mmSubName(p){ return (p.sid && S.nodes[p.sid]?.name) || p.sub || ''; }
function mmNavHtml(ps, p){
  const due = mmDueAll();
  return `<div class="mmnavh"><span>Projects</span>${due ? `<button class="link mmduebtn" data-act="mm-due">${due} due</button>` : ''}<button class="abi mmnavx" data-act="mm-navtog" aria-label="Hide the projects list" title="Hide the projects list"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M10 3.5 5.5 8l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>`
    + ps.map(x => { const st = mmStats(x), d = mmDue(x).length; return `<button class="mmproj" data-act="mm-pick" data-id="${esc(x.id)}" aria-current="${x.id === p?.id}"><span class="nm">${esc(x.t || 'Untitled')}</span><span class="mt"><i style="background:${mmSubCol(x)}"></i>${esc(mmSubName(x) || (x.kind === 'text' ? 'Text' : 'Essay'))}<span class="grow"></span>${d ? `<b>${d} due</b>` : ''}<span class="num">${st.memo}%</span></span></button>`; }).join('');
}
function mmProjectHead(p){
  const st = mmStats(p), wc = st.tot, sub = mmSubName(p), narrow = !document.body.classList.contains('desktop') || innerWidth < 1100 || mm.navh;
  return `<div class="mmhead"><div class="mmht">
      <span class="mmmeta">${esc([sub, p.kind === 'text' ? 'Text' : 'Essay', wc.toLocaleString() + ' words'].filter(Boolean).join(' · '))}</span>
      <div class="mmtitle">${mm.navh && !(innerWidth < 1100) && document.body.classList.contains('desktop') ? `<button class="abi mmnavshow" data-act="mm-navtog" aria-label="Show the projects list" title="Show the projects list"><svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2" y="3" width="12" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M6 3v10" stroke="currentColor" stroke-width="1.4"/></svg></button>` : ''}<h1>${esc(p.t || 'Untitled')}</h1>${narrow && mmAll().length > 1 ? `<button class="btn sm" data-act="mm-switch" aria-haspopup="true">Switch</button>` : ''}${narrow ? `<button class="btn sm" data-act="mm-new">New</button>` : ''}<button class="abi mmmore" data-act="mm-pmenu" data-id="${esc(p.id)}" aria-label="Project options" title="Edit, rename or delete">${'<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="3.5" cy="8" r="1.2" fill="currentColor"/><circle cx="8" cy="8" r="1.2" fill="currentColor"/><circle cx="12.5" cy="8" r="1.2" fill="currentColor"/></svg>'}</button></div></div>
    <div class="mmkpis"><div><b>${st.memo}%</b><span>memorised</span></div><div><b>${st.acc10 == null ? '–' : st.acc10 + '%'}</b><span>accuracy, last 10</span></div><div><b>Lv ${mmLevel(p.pts)}</b><span>${(p.pts || 0).toLocaleString()} points</span></div></div></div>`;
}
function mmChips(p){
  const SC = mmSections(p), L = SC.map(x => x.label), dueP = new Set(mmDue(p)), due = new Set(SC.map((x, i) => x.ps.some(j => dueP.has(j)) ? i : -1)), all = !mm.sel.size && !mm.range;
  if (L.length < 2 && !mm.range) return `<div class="mmchips"><button class="link mmsecedit" data-act="mm-secs" data-id="${esc(p.id)}">Split into sections</button></div>`;
  return `<div class="mmchips${L.length > 9 ? ' many' : ''}" role="group" aria-label="Choose the text to practise"><button class="mmchip" data-act="mm-sec" data-v="all" aria-pressed="${all}">${L.length === 1 ? L[0] : 'Whole text'}</button>`
    + (L.length > 1 ? L.map((l, i) => `<button class="mmchip" data-act="mm-sec" data-v="${i}" aria-pressed="${!mm.range && mm.sel.has(i)}">${esc(l)}${due.has(i) ? '<i class="mmdue" title="Due"></i>' : ''}</button>`).join('') : '')
    + (mm.range ? `<span class="mmchip mmrange" aria-pressed="true">Selection · ${mm.range.b - mm.range.a + 1} words<button data-act="mm-unrange" aria-label="Clear the selection">×</button></span>` : `<span class="mmhint">${mmPhone() ? 'or select text to practise just that' : 'or drag over the text to practise just that'}</span>`) + (p.kind !== 'text' || L.length > 1 ? `<button class="link mmsecedit" data-act="mm-secs" data-id="${esc(p.id)}">Edit sections</button>` : '') + '</div>';
}
function mmReaderHtml(p){
  const { W, P } = mmParsed(p), M = mmMarkMaps(p, W.length), SC = mmSections(p), st = mmStats(p), due = new Set(mmDue(p));
  const inSel = i => mm.range ? false : mm.sel.has(i);
  return SC.map((sc, si) => {
    const words = sc.ps.map(pi => mmParaHtml(W, P[pi], M)).map(h => `<p class="mmtx">${h}</p>`).join('');
    let sw = 0, sa = 0, any = false; sc.ps.forEach(j => { if (st.acc[j] != null){ any = true; sw += st.words[j]; sa += st.acc[j] * st.words[j]; } });
    const wc = sc.ps.reduce((n, j) => n + st.words[j], 0), acc = any ? Math.round(sa / sw) : null;
    return `<section class="mmpara" data-s="${si}" aria-current="${inSel(si)}"><div class="mmgut">${SC.length > 1 || sc.role !== 'other' ? `<b>${esc(sc.label)}</b>` : ''}<span>${acc == null ? 'New' : acc + '%'} · ${wc}w</span>${sc.ps.some(j => due.has(j)) ? '<span class="mmduet">Due</span>' : ''}</div><div class="mmtxs">${words}</div></section>`;
  }).join('');
}
function mmParaHtml(W, pp, M){
    let words = '';
    for (let i = pp.a; i <= pp.b; i++){ const s = mmWStyle(M, i), g = i < pp.b ? mmGapStyle(M, i) : '', inR = mm.range && i >= mm.range.a && i <= mm.range.b; words += `<span class="mw${inR ? ' mwsel' : ''}" data-w="${i}"${s ? ` style="${s}"` : ''}>${esc(W[i].t)}</span>` + (i < pp.b ? (g ? `<span class="mwg" style="${g}"> </span>` : ' ') : ''); }
    return words;
}
function mmPanelHtml(p, sheet){
  const idx = mmSelIdx(p), a = mmSelAcc(p), last = p.ms || {}, cur = mmMode(mm.mode), blocked = mmBlocked(cur.k);
  const modes = MM_GROUPS.map(g => `<div class="mmgrp"><span class="mmgl">${g}</span><div class="${sheet ? 'mmtiles' : 'mmlist'}" ${sheet ? `data-n="${MM_MODES.filter(m => m.g === g).length}"` : ''}>${MM_MODES.filter(m => m.g === g).map(m => {
      const why = mmBlocked(m.k), acc = last[m.k] == null ? '—' : last[m.k] + '%';
      return `<button class="mmmode" data-act="mm-mode" data-v="${m.k}" aria-pressed="${m.k === mm.mode}" ${why ? `aria-disabled="true" title="${esc(why)}"` : ''}>${sheet ? mmIcon(m.k, 22) : ''}<span class="nm">${m.n}</span><span class="num">${m.k === 'listen' ? '' : acc}</span></button>`; }).join('')}</div></div>`).join('');
  return `<div class="mmph"><span class="mmgl">Practise</span><b>${esc(mmSelLabel(p))}</b><span class="num">${idx.length.toLocaleString()} words${a != null ? ` · last time ${a}%` : ''}</span></div>
    ${modes}
    <div class="seg mmdiff" role="group" aria-label="Difficulty">${MM_DIFF.map((d, i) => `<button data-act="mm-diff" data-v="${i}" aria-pressed="${i === mm.diff}">${d}</button>`).join('')}</div>
    <p class="mmdesc">${esc(blocked || cur.d[mm.diff])}</p>
    <button class="btn primary mmstart" data-act="mm-start" ${blocked || !idx.length ? 'disabled' : ''}>Start ${esc(cur.n.toLowerCase())}</button>`;
}
function mmRenderEmpty(root, phone){
  root.innerHTML = `${document.body.classList.contains('desktop') ? '' : mmTopbar()}<div class="mmempty"><h2>Learn a piece by heart</h2><p>Paste an essay, a speech or a set of quotes. Practise a paragraph or the whole thing in ten ways, from reading it with gaps to typing it from memory, and Recall brings each paragraph back when it’s due.</p>
    <div class="mmerow"><button class="btn primary" data-act="mm-new">New project</button><button class="btn" data-act="mm-tab" data-v="guide">Open the rubric guide</button></div><p class="mmhint">The rubric guide has Mod C exemplars you can memorise straight away.</p></div>`;
}
/* phone */
function mmRenderPhoneList(root, ps){
  const due = mmDueAll();
  root.innerHTML = `<div class="mmp"><div class="mmtop"><h1>Memorise</h1><span class="grow"></span><button class="abi mmplus" data-act="mm-new" aria-label="New project"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3v10M3 8h10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button></div>
    ${mmTabs()}
    ${due ? `<div class="mmpdue"><b class="num">${due}</b><span>${due === 1 ? 'paragraph' : 'paragraphs'} due</span></div><button class="btn primary mmbig" data-act="mm-due">Practise what’s due</button>` : ''}
    <div class="mmplist">${ps.map(x => { const st = mmStats(x), d = mmDue(x).length; return `<button class="mmprow" data-act="mm-pick" data-id="${esc(x.id)}"><span class="mmprt"><span class="nm">${esc(x.t || 'Untitled')}</span><span class="mt"><i style="background:${mmSubCol(x)}"></i>${esc(mmSubName(x) || (x.kind === 'text' ? 'Text' : 'Essay'))} · ${st.memo}%</span></span>${d ? `<span class="mmd">${d} due</span>` : ''}<svg class="chev" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3.5 10.5 8 6 12.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`; }).join('')}</div></div>`;
}
function mmRenderPhoneProject(root, p){
  const st = mmStats(p);
  root.innerHTML = `<div class="mmp mmpp"><div class="mmtop mmtopp"><button class="abi" data-act="mm-plist" aria-label="Back to projects"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M10 3.5 5.5 8l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><h1>${esc(p.t || 'Untitled')}</h1><button class="abi" data-act="mm-pmenu" data-id="${esc(p.id)}" aria-label="Project options"><svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="3.5" cy="8" r="1.2" fill="currentColor"/><circle cx="8" cy="8" r="1.2" fill="currentColor"/><circle cx="12.5" cy="8" r="1.2" fill="currentColor"/></svg></button></div>
    <div class="mmpk"><span><b>${st.memo}%</b> memorised</span><span><b>${st.acc10 == null ? '–' : st.acc10 + '%'}</b> accuracy</span><span><b>Lv ${mmLevel(p.pts)}</b></span></div>
    ${mmChips(p)}<div class="mmtext" id="mmtext">${mmReaderHtml(p)}</div>
    <div class="mmpbar"><button class="btn primary mmbig" data-act="mm-sheet">Practise ${esc(mmSelLabel(p) === 'Whole text' ? 'the whole text' : mmSelLabel(p))}</button></div></div>
    ${mm.sheet ? `<div class="mmscrim" data-act="mm-sheetx"></div><div class="mmsheet" role="dialog" aria-modal="true" aria-label="Practise"><span class="mmgrab" aria-hidden="true"></span>${mmPanelHtml(p, true)}</div>` : ''}`;
}

/* ---------- selecting text: format it, or practise just that ---------- */
function mmSelRange(){
  const s = getSelection(), root = $('#mmtext'); if (!s || s.isCollapsed || !s.rangeCount || !root) return null;
  const r = s.getRangeAt(0); if (!root.contains(r.commonAncestorContainer)) return null;
  const ws = [...root.querySelectorAll('.mw')].filter(el => r.intersectsNode(el) && !(el.contains(r.startContainer) && r.startOffset >= (el.textContent || '').length) && !(el.contains(r.endContainer) && r.endOffset === 0));
  return ws.length ? { a: +ws[0].dataset.w, b: +ws.at(-1).dataset.w } : null;
}
function mmFmtBar(){
  $('#mmfmt')?.remove(); if (view.name !== 'memo' || mm.run) return;
  const sel = mmSelRange(); mm.selW = sel; if (!sel) return;
  const rect = getSelection().getRangeAt(0).getBoundingClientRect();
  const sw = MM_COLS.map(([n, c]) => `<button class="mmsw" data-act="mm-fmt" data-c="${c}" aria-label="${n}" title="${n}" style="--c:${c}"></button>`).join('');
  const el = document.createElement('div'); el.id = 'mmfmt'; el.setAttribute('role', 'toolbar'); el.setAttribute('aria-label', 'Format the selection');
  el.innerHTML = `<div class="seg mmtool">${[['h', 'Highlight'], ['b', 'Bold'], ['u', 'Underline']].map(([k, n]) => `<button data-act="mm-tool" data-v="${k}" aria-pressed="${mm.tool === k}">${n}</button>`).join('')}</div>${sw}<label class="mmsw mmcustom" title="Any colour" aria-label="Any colour">+<input type="color" id="mmcol" value="#d99a2b"></label><button class="mmfx" data-act="mm-fmt" data-c="clear">Clear</button><span class="mmsep"></span><button class="mmfx" data-act="mm-vocab">Add to vocab</button><button class="mmfx mmprac" data-act="mm-prac">Practise this</button>`;
  document.body.appendChild(el);
  const w = el.offsetWidth, x = Math.max(8, Math.min(innerWidth - w - 8, rect.left + rect.width / 2 - w / 2)), above = rect.top - el.offsetHeight - 10;
  const touch = matchMedia('(pointer: coarse)').matches;   // on touch screens the system's own copy menu sits above the selection
  el.style.left = x + 'px'; el.style.top = Math.min(innerHeight - el.offsetHeight - 8, touch || above < 8 ? rect.bottom + 12 : above) + 'px';
}
let mmSelT = 0, mmBarT = 0;
document.addEventListener('selectionchange', () => {
  if (view.name !== 'memo' || mm.run) return; clearTimeout(mmSelT);
  mmSelT = setTimeout(() => { if (document.activeElement?.id === 'mmcol' || (Date.now() - mmBarT < 800 && getSelection()?.isCollapsed)) return; mmFmtBar(); }, 180);
});
document.addEventListener('pointerdown', e => { if (e.target.closest?.('#mmfmt')){ mmBarT = Date.now(); if (!e.target.closest('input, label')) e.preventDefault(); } }, true);
document.addEventListener('scroll', () => { if (!matchMedia('(pointer: coarse)').matches) $('#mmfmt')?.remove(); }, true);
document.addEventListener('change', e => { if (e.target.id === 'mmcol' && mm.selW) mmFormat(mm.tool, e.target.value); });

/* ---------- edit sections ---------- */
function mmSecDialog(id){
  const p = mmGet(id); if (!p) return; const { W, P } = mmParsed(p), roles = mmRoles(p);
  const opt = (r, i) => MM_ROLES.filter(([k]) => i || k !== 'join').map(([k, n]) => `<option value="${k}" ${k === r ? 'selected' : ''}>${n}</option>`).join('');
  openDialog(`<div class="dialog mmsecdlg" role="dialog" aria-modal="true" aria-labelledby="mmsh" style="max-width:720px"><header><h2 id="mmsh">Sections</h2></header>
    <div class="body"><p class="muted">Say what each block of text is. “Part of the one above” joins a line onto the paragraph before it, for essays pasted with line breaks inside paragraphs.</p>
    <div class="mmsecl">${P.map((pp, i) => { const t = W.slice(pp.a, pp.b + 1).map(w => w.t).join(' '); return `<div class="mmsecr"><select class="in" data-i="${i}" aria-label="What this block is">${opt(roles[i], i)}</select><span class="mmsect">${esc(t.length > 140 ? t.slice(0, 139) + '…' : t)}</span><span class="mmsecw num">${pp.b - pp.a + 1}w</span></div>`; }).join('')}</div></div>
    <footer><button class="btn" data-act="mm-secauto" data-id="${esc(p.id)}">Guess again</button><span class="grow"></span><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="mm-secsave" data-id="${esc(p.id)}">Save</button></footer></div>`);
}
function mmSecSave(id, auto){
  const p = mmGet(id); if (!p) return;
  const roles = auto ? null : [...document.querySelectorAll('.mmsecl select')].map(s => s.value);
  const np = { ...p }; if (roles) np.roles = roles; else delete np.roles;
  mmPut(np, 'sections'); mm.sel.clear(); closeDialog(); toast(auto ? 'Sections guessed again · ⌘Z to undo' : 'Sections saved · ⌘Z to undo');
}

/* ---------- new / edit project ---------- */
function mmDialog(id){
  const p = id ? mmGet(id) : null, subs = kids(null);
  const subj = p?.sid && S.nodes[p.sid] ? p.sid : p ? '' : (subs.find(s => /english/i.test(s.name))?.id || '');
  openDialog(`<div class="dialog mmdlg" role="dialog" aria-modal="true" aria-labelledby="mmdh" style="max-width:640px"><header><h2 id="mmdh">${p ? 'Edit project' : 'New project'}</h2></header>
    <div class="body">
      <div class="field"><label for="mmdt">Name</label><input class="in" id="mmdt" maxlength="80" value="${esc(p?.t || '')}" placeholder="e.g. Mod A essay, Economics extended response"></div>
      <div class="mmdrow"><div class="field"><label for="mmds">Subject</label><select class="in" id="mmds"><option value="">None</option>${subs.map(s => `<option value="${s.id}" ${s.id === subj ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}${p?.sub && !p.sid ? `<option value="__keep" selected>${esc(p.sub)}</option>` : ''}</select></div>
        <div class="field"><span class="lbl">Sections</span><div class="seg" role="group" aria-label="Sections" id="mmdk"><button data-act="mm-kind" data-v="essay" aria-pressed="${p?.kind !== 'text'}">Intro, body, conclusion</button><button data-act="mm-kind" data-v="text" aria-pressed="${p?.kind === 'text'}">Numbered paragraphs</button></div></div></div>
      <div class="field"><label for="mmdx">Text</label><textarea class="in mmdx" id="mmdx" rows="12" placeholder="Paste your essay. Each paragraph on its own line.">${esc(p?.text || '')}</textarea><span class="hint" id="mmdxh">Or <button class="link" data-act="mm-file">open a text file</button>. ${p ? 'Changing the words keeps your formatting and scores wherever the words are the same.' : ''}</span><input type="file" id="mmdf" accept=".txt,.md,text/plain" hidden></div>
    </div>
    <footer>${p ? `<button class="btn danger" data-act="mm-delask" data-id="${esc(p.id)}">Delete</button>` : ''}<span class="grow"></span><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="mm-save" data-id="${esc(p?.id || '')}">${p ? 'Save' : 'Create'}</button></footer></div>`,
    () => $('#mmdt').focus());
}
function mmMapMarks(oldText, newText, marks){
  const A = mmParse(oldText).W.map(w => w.t), B = mmParse(newText).W.map(w => w.t);
  let pre = 0; while (pre < A.length && pre < B.length && A[pre] === B[pre]) pre++;
  let suf = 0; while (suf < A.length - pre && suf < B.length - pre && A[A.length - 1 - suf] === B[B.length - 1 - suf]) suf++;
  const d = B.length - A.length, out = [];
  for (const m of marks || []){
    if (m.b < pre) out.push(m);
    else if (m.a >= A.length - suf) out.push({ ...m, a: m.a + d, b: m.b + d });
    else if (m.a < pre) out.push({ ...m, b: pre - 1 });
  }
  return out;
}
/* paragraphs whose words didn't change keep their scores and schedule, wherever they moved to */
function mmParaMap(oldText, newText){
  const A = mmParse(oldText), B = mmParse(newText), key = (X, i) => X.W.slice(X.P[i].a, X.P[i].b + 1).map(w => w.core).join(' ');
  const idx = new Map(B.P.map((_, i) => [key(B, i), i])), m = new Map();
  A.P.forEach((_, i) => { const j = idx.get(key(A, i)); if (j != null) m.set(i, j); }); return m;
}
const mmRemap = (obj, m) => { const out = {}; for (const [i, v] of Object.entries(obj || {})) if (m.has(+i)) out[m.get(+i)] = v; return out; };
async function mmSaveDialog(id){
  const t = $('#mmdt').value.trim(), text = $('#mmdx').value.replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim();
  if (!t){ $('#mmdt').focus(); return toast('Give the project a name'); }
  if (!text){ $('#mmdx').focus(); return toast('Paste the text to memorise'); }
  const sv = $('#mmds').value, kind = $('#mmdk [aria-pressed="true"]')?.dataset.v || 'essay', old = id ? mmGet(id) : null;
  const sid = sv && sv !== '__keep' ? sv : null, sub = sid ? (S.nodes[sid]?.name || '') : sv === '__keep' ? old?.sub || '' : '';
  let p;
  if (old){
    const same = old.text === text, pm = same ? null : mmParaMap(old.text, text);
    p = { ...old, t, sid, sub, kind, text, marks: same ? old.marks : mmMapMarks(old.text, text, old.marks), secs: same ? old.secs : mmRemap(old.secs, pm), roles: same || !Array.isArray(old.roles) ? old.roles : (() => { const n = mmParse(text).P.length, r = new Array(n).fill(null); pm.forEach((j, i) => { r[j] = old.roles[i]; }); return r.map((x, i) => x || (i ? 'body' : 'intro')); })(), hist: same ? old.hist : (old.hist || []).map(h => h.pa ? { ...h, pa: mmRemap(h.pa, pm) } : h), upd: Date.now() };
  } else p = { id: uid('mm'), t, sid, sub, kind, text, marks: [], secs: {}, hist: [], ms: {}, pts: 0, at: Date.now(), used: Date.now() };
  mmPut(p, old ? 'edit project' : 'new project'); mmPick(p.id); mm.tab = 'projects'; ls.set('mm-tab', 'projects');
  closeDialog(); toast(old ? 'Saved' : 'Project created');
}
function mmFromExemplar(i){
  const d = MG.DOCS.ex[+i]; if (!d) return;
  const have = mmAll().find(p => p.src === 'ex:' + d.title);
  if (have){ mmPick(have.id); mm.tab = 'projects'; ls.set('mm-tab', 'projects'); return render(); }
  const text = String(d.text || '').replace(/\r/g, '').split('\n').map(l => l.replace(/\s+$/, '')).filter(l => !/^\s*([-*_]\s*){3,}$/.test(l))
    .map(l => l.replace(/^#+\s*/, '').replace(/^>\s?/, '').replace(/\\([*_])/g, '$1').replace(/\*+/g, '').replace(/(^|[\s(])_+|_+(?=[\s.,;:!?)]|$)/g, '$1').replace(/~~/g, '').trim()).join('\n').replace(/\n{2,}/g, '\n').trim();
  const eng = kids(null).find(s => /english/i.test(s.name));
  const p = { id: uid('mm'), t: d.title, sid: eng?.id || null, sub: eng ? eng.name : 'English', kind: 'text', text, src: 'ex:' + d.title, marks: [], secs: {}, hist: [], ms: {}, pts: 0, at: Date.now(), used: Date.now() };
  mmPut(p, 'new project'); mmPick(p.id); mm.tab = 'projects'; ls.set('mm-tab', 'projects'); render(); toast('Added to your projects');
}

/* ===================== practice sessions ===================== */
function mmStart(){
  const p = mmCur(); if (!p) return;
  const m = mmMode(mm.mode), why = mmBlocked(m.k); if (why) return toast(why, 4000);
  const { W } = mmParsed(p), idx = mmSelIdx(p); if (!idx.length) return toast('Nothing to practise there');
  const words = idx.map(i => ({ ...W[i], i }));
  if (!words.some(mmScore)) return toast('There are no words to practise there');
  const r = mm.run = { pid: p.id, mode: m.k, diff: mm.diff, words, res: new Array(words.length).fill(null), t0: Date.now(), label: mmSelLabel(p), M: mmMarkMaps(p, W.length), seed: (Date.now() ^ (idx[0] * 2654435761)) >>> 0 };
  r.rnd = mmRand(r.seed); r.sc = words.map((w, k) => mmScore(w) ? k : -1).filter(k => k >= 0);
  MM_RUN[r.mode === 'type' && r.diff === 0 ? 'first' : r.mode].init(r);
  mm.sheet = false; $('#mmfmt')?.remove(); getSelection()?.removeAllRanges();
  try { if (gr.groups.length && focus.state !== 'studying' && ls.get('md-focus-auto', true)) fStart(mmSubName(p) || focus.subj || ''); } catch {}
  render(); window.scrollTo(0, 0); mmFocus();
}
const mmEng = r => MM_RUN[r.mode === 'type' && r.diff === 0 ? 'first' : r.mode];
function mmExit(){ const r = mm.run; if (r?.stop) try { r.stop(); } catch {} mm.run = null; document.body.classList.remove('mmrun'); render(); }
function mmAccNow(r){ const v = r.res.filter(x => x != null); return v.length ? Math.round(v.reduce((a, b) => a + b, 0) / v.length * 100) : null; }
function mmFinish(){
  const r = mm.run; if (!r || r.done) return; if (r.stop) try { r.stop(); } catch {}
  r.done = true; r.ms = Date.now() - r.t0;
  const p0 = mmGet(r.pid); if (!p0){ render(); return; }
  const noAcc = r.mode === 'listen', sc = r.res.filter(x => x != null);
  r.acc = noAcc || !sc.length ? null : Math.round(sc.reduce((a, b) => a + b, 0) / sc.length * 100);
  const { P } = mmParsed(p0), pa = {}, cover = {};
  r.words.forEach((w, k) => { cover[w.p] = (cover[w.p] || 0) + 1; if (r.res[k] == null) return; (pa[w.p] = pa[w.p] || []).push(r.res[k]); });
  const paAcc = Object.fromEntries(Object.entries(pa).map(([k, v]) => [k, Math.round(v.reduce((a, b) => a + b, 0) / v.length * 100)]));
  const secs = { ...(p0.secs || {}) }, sched = {};
  if (r.acc != null && !['reveal', 'slider', 'listen'].includes(r.mode))
    for (const [k, a] of Object.entries(paAcc)){ const i = +k; if (!P[i] || cover[i] < P[i].b - P[i].a + 1) continue; secs[i] = mmSched(secs[i], a, r.mode, r.diff); sched[i] = secs[i].due; }
  const gain = r.acc == null ? Math.round(r.words.length / 20) : Math.round(r.words.length * r.acc / 100 * (1 + r.diff * .5) * (mmMode(r.mode).g === 'Familiarise' ? .4 : 1) / 4);
  r.gain = gain; r.sched = sched; r.paAcc = paAcc; r.lv0 = mmLevel(p0.pts);
  const h = { at: Date.now(), m: r.mode, d: r.diff, w: r.words.length, acc: r.acc, ms: r.ms }; if (r.acc != null) h.pa = paAcc;
  const p = { ...p0, secs, hist: [...(p0.hist || []), h].slice(-300), ms: r.acc != null ? { ...(p0.ms || {}), [r.mode]: r.acc } : (p0.ms || {}), pts: (p0.pts || 0) + gain, last: { m: r.mode, d: r.diff }, used: Date.now() };
  r.lv1 = mmLevel(p.pts);
  mmPut(p, 'practice', true);
  render();
}

/* shared drawing of the passage during practice: o = fn(word, k) → null (not shown) or { c: class, h: html, t: text, a: attrs, fmt } */
function mmRunText(r, fn){
  let html = '', curP = null;
  r.words.forEach((w, k) => {
    const o = fn(w, k); if (!o) return;
    if (w.p !== curP){ if (curP !== null) html += '</p>'; html += '<p class="mmrp">'; curP = w.p; }
    const st = o.fmt ? mmWStyle(r.M, w.i) : '';
    html += `<span class="mrw ${o.c || ''}" ${o.a || ''}${st ? ` style="${st}"` : ''}>${o.h ?? esc(o.t ?? w.t)}</span> `;
  });
  return html + (curP !== null ? '</p>' : '');
}
const mmShown = (r, k, cls = '') => ({ c: (r.res[k] === 0 ? 'mrx ' : '') + cls, fmt: r.res[k] !== 0 });
const mmHidden = w => ({ c: 'mrh', t: w.t });
const mmFirstOf = w => { const m = w.t.match(/^([^\p{L}\p{N}]*)([\p{L}\p{N}])[\p{L}\p{N}'’-]*(.*)$/u); return m ? m[1] + m[2] + m[3] : w.t; };
/* a hint word: its first letter, then a faint line as long as the rest of the word */
const mmHintH = w => { const m = w.t.match(/^([^\p{L}\p{N}]*)([\p{L}\p{N}])([\p{L}\p{N}'’-]*)(.*)$/u); return m ? esc(m[1] + m[2]) + (m[3] ? `<i class="mrrest">${esc(m[3])}</i>` : '') + esc(m[4]) : esc(w.t); };
function mmNextSc(r, k){ while (k < r.words.length && !mmScore(r.words[k])) k++; return k; }

const MM_RUN = {
  /* ---- Tap to reveal: sentence / phrase / word units, self-marked ---- */
  reveal: {
    init(r){
      const U = []; let cur = [];
      r.words.forEach((w, k) => {
        cur.push(k);
        const end = k === r.words.length - 1 || r.words[k + 1].s !== w.s || r.words[k + 1].p !== w.p;
        const cut = r.diff === 2 || end || (r.diff === 1 && (/[,;:—–]$/.test(w.t) || cur.length >= 7));
        if (cut){ U.push(cur); cur = []; }
      });
      r.units = U.filter(u => u.some(k => mmScore(r.words[k]))); r.unitOf = new Array(r.words.length).fill(-1); r.units.forEach((u, i) => u.forEach(k => r.unitOf[k] = i)); r.u = 0; r.shown = false;
    },
    body(r){ return mmRunText(r, (w, k) => { const u = r.unitOf[k]; if (u < 0) return { t: w.t }; if (u < r.u) return mmShown(r, k); if (u === r.u && r.shown) return { c: 'mrcur', fmt: true }; return mmHidden(w); }); },
    foot(r){
      if (r.diff === 2) return `<button class="btn mmx" data-act="mm-r-no">Didn’t know<kbd>X</kbd></button><button class="btn primary" data-act="mm-r-yes">Knew it<kbd>Space</kbd></button>`;
      return r.shown ? `<button class="btn mmx" data-act="mm-r-no">Missed some<kbd>X</kbd></button><button class="btn primary" data-act="mm-r-yes">Got it<kbd>Space</kbd></button>` : `<span class="mmfhint">Say the next ${r.diff ? 'phrase' : 'sentence'}, then reveal it</span><button class="btn primary" data-act="mm-r-show">Reveal<kbd>Space</kbd></button>`;
    },
    mark(r, ok){ r.units[r.u].forEach(k => { if (mmScore(r.words[k])) r.res[k] = ok ? 1 : 0; }); r.u++; r.shown = false; if (r.u >= r.units.length) return mmFinish(); mmPaint(true); },
    act(r, a){ if (a === 'mm-r-show'){ r.shown = true; return mmPaint(true); } if (a === 'mm-r-yes'){ if (r.diff < 2 && !r.shown){ r.shown = true; return mmPaint(true); } return this.mark(r, true); } if (a === 'mm-r-no') return this.mark(r, false); if (a === 'mm-tap') return this.act(r, r.diff === 2 || r.shown ? 'mm-r-yes' : 'mm-r-show'); },
    key(r, e){ if (e.key === ' ' || e.key === 'Enter'){ this.act(r, r.diff === 2 || r.shown ? 'mm-r-yes' : 'mm-r-show'); return true; } if ((e.key === 'x' || e.key === 'X') && (r.shown || r.diff === 2)){ this.mark(r, false); return true; } return false; },
    prog(r){ return [Math.min(r.u, r.units.length), r.units.length, r.diff ? (r.diff === 1 ? 'phrases' : 'words') : 'sentences']; }
  },
  /* ---- Slider: hide a share of the words, peek costs a slip ---- */
  slider: {
    init(r){ r.max = [30, 60, 100][r.diff]; r.order = mmShuffle(r.sc, r.rnd); r.v = Math.min(r.max, [20, 40, 60][r.diff]); r.peek = new Set(); },
    hidden(r){ return new Set(r.order.slice(0, Math.round(r.order.length * r.v / 100))); },
    body(r){ const H = this.hidden(r); return mmRunText(r, (w, k) => r.peek.has(k) && H.has(k) ? { c: 'mrpeek', fmt: true } : H.has(k) ? { c: 'mrh mrtap', a: `data-act="mm-peek" data-k="${k}" role="button" tabindex="0" aria-label="Hidden word, tap to peek"`, t: w.t } : { fmt: true }); },
    foot(r){ return `<label class="mmsl"><span>Hide</span><input type="range" id="mmsl" min="0" max="${r.max}" step="5" value="${r.v}" aria-label="How many words to hide"><b class="num" id="mmslv">${r.v}%</b></label><button class="btn primary" data-act="mm-done">Done<kbd>↵</kbd></button>`; },
    act(r, a, el){ if (a === 'mm-peek'){ r.peek.add(+el.dataset.k); return mmPaint(); } if (a === 'mm-done') return this.done(r); },
    done(r){ const H = this.hidden(r); if (!H.size) return toast('Slide to hide some words first'); r.res = r.res.map((_, k) => H.has(k) ? (r.peek.has(k) ? 0 : 1) : null); mmFinish(); },
    input(r, el){ if (el.id !== 'mmsl') return; r.v = +el.value; $('#mmslv').textContent = r.v + '%'; mmPaint(); },
    key(r, e){ if (e.key === 'Enter'){ this.done(r); return true; } if (e.key === 'ArrowRight' || e.key === 'ArrowLeft'){ r.v = Math.max(0, Math.min(r.max, r.v + (e.key === 'ArrowRight' ? 5 : -5))); const s = $('#mmsl'); if (s) s.value = r.v; $('#mmslv') && ($('#mmslv').textContent = r.v + '%'); mmPaint(); return true; } return false; },
    prog(r){ const H = this.hidden(r); return [r.peek.size, H.size, 'peeked']; }
  },
  /* ---- Listen: the device reads it, sentence by sentence ---- */
  listen: {
    init(r){
      r.sents = []; r.words.forEach((w, k) => { const last = r.sents.at(-1); if (last && last.s === w.s && last.p === w.p) last.ks.push(k); else r.sents.push({ s: w.s, p: w.p, ks: [k] }); });
      r.si = 0; r.wk = -1; r.playing = false; r.ended = false; r.gen = 0;
      r.stop = () => { r.gen++; r.playing = false; try { speechSynthesis.cancel(); } catch {} };
    },
    voice(){ const vs = speechSynthesis.getVoices(); return vs.find(v => /en[-_]AU/i.test(v.lang)) || vs.find(v => /en[-_]GB/i.test(v.lang)) || vs.find(v => /^en/i.test(v.lang)) || null; },
    speak(r){
      if (r.si >= r.sents.length){ r.playing = false; r.ended = true; r.wk = -1; return mmPaint(true); }
      const gen = ++r.gen, s = r.sents[r.si], text = s.ks.map(k => r.words[k].t).join(' '), offs = []; let o = 0; s.ks.forEach(k => { offs.push(o); o += r.words[k].t.length + 1; });
      const u = new SpeechSynthesisUtterance(text); u.rate = r.diff === 0 ? .8 : 1; const v = this.voice(); if (v){ u.voice = v; u.lang = v.lang; } else u.lang = 'en-AU';
      u.onboundary = e => { if (gen !== r.gen || (e.name && e.name !== 'word')) return; let j = 0; while (j + 1 < offs.length && offs[j + 1] <= e.charIndex) j++; r.wk = s.ks[j]; mmPaint(); };
      u.onend = () => { if (gen !== r.gen || !r.playing || mm.run !== r) return; r.si++; r.wk = -1; this.speak(r); };
      u.onerror = e => { if (gen !== r.gen || e.error === 'interrupted' || e.error === 'canceled') return; r.playing = false; toast('Couldn’t read that aloud on this device'); mmPaint(true); };
      speechSynthesis.speak(u); mmPaint();
    },
    body(r){ const cs = r.playing ? r.sents[r.si] : null, inS = new Set(cs?.ks || []); return mmRunText(r, (w, k) => r.diff === 2 && !r.ended ? (k === r.wk ? { c: 'mrcur' } : mmHidden(w)) : { c: k === r.wk ? 'mrcur' : inS.has(k) ? 'mrsent' : '', fmt: true }); },
    foot(r){ return `<button class="btn" data-act="mm-l-restart">From the start</button><button class="btn ${r.ended ? '' : 'primary'}" data-act="mm-l-play">${r.playing ? 'Pause' : r.si ? 'Carry on' : 'Play'}<kbd>Space</kbd></button>${r.ended ? '<button class="btn primary" data-act="mm-done">Done<kbd>↵</kbd></button>' : ''}`; },
    act(r, a){
      if (a === 'mm-l-play'){ if (r.playing){ r.gen++; r.playing = false; speechSynthesis.cancel(); return mmPaint(true); } r.gen++; speechSynthesis.cancel(); r.playing = true; r.ended = false; if (r.si >= r.sents.length) r.si = 0; this.speak(r); return mmPaint(true); }
      if (a === 'mm-l-restart'){ r.gen++; speechSynthesis.cancel(); r.si = 0; r.wk = -1; r.playing = true; r.ended = false; this.speak(r); return mmPaint(true); }
      if (a === 'mm-done') return mmFinish();
    },
    key(r, e){ if (e.key === ' '){ this.act(r, 'mm-l-play'); return true; } if (e.key === 'Enter' && r.ended){ mmFinish(); return true; } return false; },
    prog(r){ return [Math.min(r.si, r.sents.length), r.sents.length, 'sentences']; }
  },
  /* ---- First letters (and Type it on Easy): type each word's first letter ---- */
  first: {
    init(r){ r.pos = mmNextSc(r, 0); r.wrong = 0; r.hint = r.mode === 'type' ? 'none' : ['all', 'next', 'none'][r.diff]; },
    body(r){
      return mmRunText(r, (w, k) => {
        if (!mmScore(w)) return k < r.pos || r.hint === 'all' ? { t: w.t } : null;
        if (k < r.pos) return mmShown(r, k);
        if (k === r.pos) return { c: 'mrnext' + (r.wrong ? ' mrbad' : ''), t: r.hint === 'none' ? '' : mmFirstOf(w), h: r.hint === 'none' ? '<i class="mrcaret"></i>' : null };
        return r.hint === 'all' ? { c: 'mrfl', h: mmHintH(w) } : null;
      });
    },
    foot(r){ return `<input class="in mmkey" id="mmin" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="next" placeholder="Type the first letter of each word" aria-label="First letter of the next word"><button class="btn" data-act="mm-f-reveal">Show word</button><button class="btn" data-act="mm-done">Finish</button>`; },
    letter(r, ch){
      if (r.pos >= r.words.length) return; ch = mmNorm(ch).slice(-1); if (!ch) return;
      const w = r.words[r.pos];
      if (ch === w.f){ if (r.res[r.pos] == null) r.res[r.pos] = 1; return this.adv(r); }
      r.res[r.pos] = 0; r.wrong++; if (r.wrong >= 3) return this.adv(r); mmPaint(); mmShake();
    },
    adv(r){ r.pos = mmNextSc(r, r.pos + 1); r.wrong = 0; if (r.pos >= r.words.length) return mmFinish(); mmPaint(); },
    act(r, a){ if (a === 'mm-f-reveal'){ r.res[r.pos] = 0; return this.adv(r); } if (a === 'mm-done') return this.done(r); },
    done(r){ for (let k = r.pos; k < r.words.length; k++) if (mmScore(r.words[k]) && r.res[k] == null) r.res[k] = 0; mmFinish(); },
    input(r, el){ if (el.id !== 'mmin') return; const v = el.value; el.value = ''; for (const ch of v) if (mm.run === r && !r.done) this.letter(r, ch); },
    key(r, e){ if (document.activeElement?.id === 'mmin') return false; if (e.key.length === 1 && /[\p{L}\p{N}]/u.test(e.key)){ this.letter(r, e.key); $('#mmin')?.focus(); return true; } return false; },
    prog(r){ const done = r.sc.filter(k => k < r.pos).length; return [done, r.sc.length, 'words']; }
  },
  /* ---- Blanks: word bank on Easy, typed on Medium and Hard ---- */
  blanks: {
    init(r){
      const step = [5, 3, 2][r.diff], content = k => { const w = r.words[k]; return w.core.length >= 4 || /^[A-Z]/.test(w.t.replace(/^[^\p{L}]+/u, '')); };
      const pool = r.diff === 2 ? r.sc : r.sc.filter(content), off = Math.floor(r.rnd() * step);
      r.blanks = pool.filter((_, j) => (j + off) % step === 0); if (!r.blanks.length) r.blanks = [r.sc[0]];
      r.isB = new Set(r.blanks); r.bi = 0; r.got = new Map();
      r.bank = r.diff === 0 ? mmShuffle(r.blanks.map(k => ({ k, t: r.words[k].t.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’]+$/gu, '') })), r.rnd) : null;
    },
    body(r){
      const cur = r.blanks[r.bi];
      return mmRunText(r, (w, k) => {
        if (!r.isB.has(k)) return { fmt: true };
        if (r.got.has(k)) return r.res[k] ? { c: 'mrok', fmt: true } : { c: 'mrx', h: `${esc(w.t)}` };
        if (k === cur) return r.diff === 0 ? { c: 'mrh mrslot mrcurb', t: w.t } : { c: 'mrinl', h: `<input class="mmbl" id="mmin" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="next" aria-label="Missing word" style="width:${Math.max(4, w.t.length + 1)}ch">` };
        return { c: 'mrh mrslot', t: w.t };
      });
    },
    foot(r){
      if (r.diff === 0) return `<div class="mmbank">${r.bank.filter(b => !r.got.has(b.k)).map(b => `<button class="mmbw" data-act="mm-bank" data-k="${b.k}">${esc(b.t)}</button>`).join('')}</div>`;
      return `<span class="mmfhint">Type the missing word, then Enter or Space</span><button class="btn" data-act="mm-b-skip">Show it</button><button class="btn" data-act="mm-done">Finish</button>`;
    },
    answer(r, ok){ const k = r.blanks[r.bi]; if (r.res[k] == null) r.res[k] = ok ? 1 : 0; if (!ok && r.diff === 0) return mmShake(); r.got.set(k, true); r.bi++; if (r.bi >= r.blanks.length) return mmFinish(); mmPaint(true); },
    act(r, a, el){
      if (a === 'mm-bank'){ const k = +el.dataset.k, cur = r.blanks[r.bi]; const ok = r.words[k].core === r.words[cur].core; if (!ok){ r.res[cur] = 0; el.classList.remove('mmshk'); void el.offsetWidth; el.classList.add('mmshk'); return mmPaint(); } return this.answer(r, true); }
      if (a === 'mm-b-skip') return this.answer(r, false);
      if (a === 'mm-done'){ r.blanks.forEach(k => { if (r.res[k] == null) r.res[k] = 0; }); return mmFinish(); }
    },
    submit(r){ const el = $('#mmin'); if (!el) return; const v = el.value.trim(); if (!v) return; this.answer(r, mmSame(v, r.words[r.blanks[r.bi]].core)); },
    key(r, e){ if (document.activeElement?.id === 'mmin' && (e.key === 'Enter' || e.key === ' ')){ e.preventDefault(); this.submit(r); return true; } return false; },
    prog(r){ return [r.bi, r.blanks.length, 'blanks']; }
  },
  /* ---- Reorder: chunks back in order ---- */
  reorder: {
    init(r){
      const C = [10, 20, 30][r.diff], N = r.words.length, size = Math.max(2, Math.ceil(N / C)), ch = []; let a = 0;
      while (a < N){
        let b = Math.min(N - 1, a + size - 1);
        for (let j = a; j <= b; j++) if (j + 1 < N && r.words[j + 1].p !== r.words[j].p){ b = j; break; }
        for (let j = b; j > a + Math.floor(size / 2) && j <= b; j--) if (/[,.;:!?]["”’)]*$/.test(r.words[j].t) && j < b){ b = j; break; }
        if (b === N - 2 && r.words[N - 1].p === r.words[b].p && !mmScore(r.words[N - 1])) b = N - 1;
        ch.push({ a, b }); a = b + 1;
      }
      r.ch = ch; r.ci = 0; r.cr = new Array(ch.length).fill(null); r.pool = mmShuffle(ch.map((_, j) => j), r.rnd);
      if (r.pool.length > 1 && r.pool.every((j, i) => j === i)) r.pool.reverse();
    },
    body(r){
      const lim = r.ci ? r.ch[r.ci - 1].b : -1;
      const txt = mmRunText(r, (w, k) => k <= lim ? { c: r.cr[r.ch.findIndex(c => c.a <= k && k <= c.b)] === 0 ? 'mrx' : '', fmt: true } : null);
      return (r.ci ? txt : '') + `<p class="mmrp mmnext">${r.ci < r.ch.length ? '<span class="mrnext"><i class="mrcaret"></i></span>' : ''}</p>`;
    },
    foot(r){ return `<div class="mmbank mmchunks">${r.pool.filter(j => j >= r.ci).map(j => `<button class="mmbw" data-act="mm-chunk" data-j="${j}">${esc(r.words.slice(r.ch[j].a, r.ch[j].b + 1).map(w => w.t).join(' '))}</button>`).join('')}</div>`; },
    act(r, a, el){
      if (a !== 'mm-chunk') return; const j = +el.dataset.j;
      if (j !== r.ci){ r.cr[r.ci] = 0; el.classList.remove('mmshk'); void el.offsetWidth; el.classList.add('mmshk'); return mmPaint(); }
      if (r.cr[r.ci] == null) r.cr[r.ci] = 1;
      const c = r.ch[r.ci]; for (let k = c.a; k <= c.b; k++) if (mmScore(r.words[k])) r.res[k] = r.cr[r.ci];
      r.ci++; if (r.ci >= r.ch.length) return mmFinish(); mmPaint(true);
    },
    key(){ return false; },
    prog(r){ return [r.ci, r.ch.length, 'chunks']; }
  },
  /* ---- Target it: find the swapped words ---- */
  target: {
    SMALL: { a: 'the', an: 'the', the: 'a', in: 'on', on: 'in', of: 'for', for: 'of', to: 'for', and: 'but', but: 'and', is: 'was', was: 'is', are: 'were', were: 'are', his: 'her', her: 'his', their: 'its', its: 'their', this: 'that', that: 'this', which: 'that', with: 'by', by: 'with', as: 'so', so: 'as', from: 'to', not: 'now', it: 'he', he: 'it', she: 'he', we: 'they', they: 'we', at: 'in', or: 'and', be: 'is', has: 'had', had: 'has', will: 'would', would: 'will', can: 'could', could: 'can', more: 'most', most: 'more' },
    init(r){
      const content = k => r.words[k].core.length >= 4 && !this.SMALL[r.words[k].core];
      const N = r.sc.length; let picks = [];
      if (r.diff === 1){ const bySent = new Map(); r.sc.filter(content).forEach(k => { const s = r.words[k].s; if (!bySent.has(s)) bySent.set(s, []); bySent.get(s).push(k); }); for (const ks of bySent.values()) picks.push(ks[Math.floor(r.rnd() * ks.length)]); }
      else {
        const want = r.diff === 0 ? Math.max(1, Math.round(N / 40)) : Math.max(2, Math.round(N / 8)), cand = r.diff === 0 ? r.sc.filter(content) : r.sc;
        const step = cand.length / want; for (let i = 0; i < want && cand.length; i++) picks.push(cand[Math.min(cand.length - 1, Math.floor(i * step + r.rnd() * step))]);
      }
      picks = [...new Set(picks.filter(k => k != null))];
      const pool = [...new Set(mmParse(mmGet(r.pid)?.text).W.map(w => w.core).filter(c => c.length >= 4 && !/\d/.test(c)))];
      r.swap = new Map();
      for (const k of picks){
        const w = r.words[k]; let rep = this.SMALL[w.core];
        if (!rep || r.diff < 2){ const near = pool.filter(c => c !== w.core && Math.abs(c.length - w.core.length) <= 3 && !mmLev1(c, w.core)); rep = near.length ? near[Math.floor(r.rnd() * near.length)] : rep; }
        if (!rep) continue;
        const m = w.t.match(/^([^\p{L}\p{N}]*)([\s\S]*?)([^\p{L}\p{N}]*)$/u), core0 = m ? m[2] : w.t;
        if (/^\p{Lu}/u.test(core0)) rep = rep[0].toUpperCase() + rep.slice(1);
        r.swap.set(k, (m ? m[1] : '') + rep + (m ? m[3] : ''));
      }
      if (!r.swap.size){ const k = r.sc[0]; r.swap.set(k, r.words[k].t.split('').reverse().join('')); }
      r.flag = new Set(); r.checked = false;
    },
    body(r){
      return mmRunText(r, (w, k) => {
        const sw = r.swap.has(k), fl = r.flag.has(k);
        if (!r.checked) return { c: 'mrtap' + (fl ? ' mrflag' : ''), t: sw ? r.swap.get(k) : w.t, a: mmScore(w) ? `data-act="mm-flag" data-k="${k}" role="button" tabindex="0" aria-pressed="${fl}"` : '' };
        if (sw) return fl ? { c: 'mrfound', h: `<s>${esc(r.swap.get(k))}</s> ${esc(w.t)}` } : { c: 'mrx', h: `<s>${esc(r.swap.get(k))}</s> ${esc(w.t)}` };
        return fl ? { c: 'mrfalse', t: w.t } : { fmt: true };
      });
    },
    foot(r){ return r.checked ? `<span class="mmfhint">Found ${[...r.swap.keys()].filter(k => r.flag.has(k)).length} of ${r.swap.size}${[...r.flag].filter(k => !r.swap.has(k)).length ? `, ${[...r.flag].filter(k => !r.swap.has(k)).length} wrongly tapped` : ''}</span><button class="btn primary" data-act="mm-done">See results<kbd>↵</kbd></button>` : `<span class="mmfhint">${r.swap.size} ${r.swap.size === 1 ? 'word has' : 'words have'} been swapped. Tap ${r.swap.size === 1 ? 'it' : 'them'}.</span><button class="btn primary" data-act="mm-t-check">Check<kbd>↵</kbd></button>`; },
    act(r, a, el){
      if (a === 'mm-flag' && !r.checked){ const k = +el.dataset.k; r.flag.has(k) ? r.flag.delete(k) : r.flag.add(k); return mmPaint(true); }
      if (a === 'mm-t-check'){ r.checked = true; r.res = r.res.map((_, k) => r.swap.has(k) ? (r.flag.has(k) ? 1 : 0) : r.flag.has(k) ? 0 : null); return mmPaint(true); }
      if (a === 'mm-done') return r.checked ? mmFinish() : this.act(r, 'mm-t-check');
    },
    key(r, e){ if (e.key === 'Enter'){ this.act(r, r.checked ? 'mm-done' : 'mm-t-check'); return true; } return false; },
    prog(r){ return [r.flag.size, r.swap.size, 'tapped']; }
  },
  /* ---- Type it (Medium, Hard): type every word ---- */
  type: {
    init(r){ r.typed = ''; r.n = 0; r.partial = ''; },
    calc(r){
      const toks = r.typed.split(/\s+/).filter(Boolean), done = /\s$/.test(r.typed) ? toks.length : Math.max(0, toks.length - 1);
      r.n = Math.min(done, r.sc.length); r.res = r.res.map(() => null);
      for (let j = 0; j < r.n; j++) r.res[r.sc[j]] = mmSame(toks[j], r.words[r.sc[j]].core) ? 1 : 0;
      r.typedTok = toks; r.partial = /\s$/.test(r.typed) || !toks.length || r.n >= r.sc.length ? '' : toks[toks.length - 1];
    },
    body(r){
      const curK = r.sc[r.n] ?? r.words.length;
      return mmRunText(r, (w, k) => {
        if (!mmScore(w)) return k < curK ? { t: w.t } : null;
        if (k < curK) return r.res[k] === 0 ? { c: 'mrx', h: esc(w.t) } : { fmt: true };
        if (k === curK){
          if (r.partial){ const ok = w.core.startsWith(mmNorm(r.partial)) || mmSame(r.partial, w.core); return { c: 'mrnext mrtyping' + (ok ? '' : ' mrbad'), t: r.partial }; }
          return { c: 'mrnext', t: r.diff === 1 ? mmFirstOf(w) : '', h: r.diff === 1 ? null : '<i class="mrcaret"></i>' };
        }
        return r.diff === 1 ? { c: 'mrfl', h: mmHintH(w) } : null;
      });
    },
    foot(r){ return `<textarea class="in mmta" id="mmta" rows="3" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="Type it from memory…" aria-label="Type the passage">${esc(r.typed)}</textarea><div class="mmfrow"><span class="mmfhint">Spelling slips of one letter are forgiven</span><button class="btn" data-act="mm-done">Finish</button></div>`; },
    input(r, el){ if (el.id !== 'mmta') return; r.typed = el.value; this.calc(r); if (r.n >= r.sc.length) return mmFinish(); mmPaint(); },
    act(r, a){ if (a === 'mm-done'){ this.calc(r); r.sc.forEach(k => { if (r.res[k] == null) r.res[k] = 0; }); return mmFinish(); } },
    key(){ return false; },
    prog(r){ return [r.n, r.sc.length, 'words']; }
  },
  /* ---- Multiple choice: pick the next word ---- */
  choice: {
    init(r){ r.pos = mmNextSc(r, 0); r.n = [2, 4, 6][r.diff]; r.bad = new Set(); this.opts(r); },
    opts(r){
      if (r.pos >= r.words.length) return; const w = r.words[r.pos], clean = t => t.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’]+$/gu, '');
      const seen = new Set([w.core]), cand = [];
      const add = list => { for (const k of mmShuffle(list, r.rnd)){ const x = r.words[k] || null; const c = x ? x.core : null; if (!c || seen.has(c)) continue; seen.add(c); cand.push(clean(x.t)); if (cand.length >= r.n - 1) return; } };
      add(r.sc.filter(k => Math.abs(r.words[k].core.length - w.core.length) <= 3)); if (cand.length < r.n - 1) add(r.sc);
      for (const extra of ['the', 'and', 'which', 'reveals', 'their', 'through', 'within', 'shows', 'between', 'while']){ if (cand.length >= r.n - 1) break; if (!seen.has(extra)){ seen.add(extra); cand.push(extra); } }
      const pos = Math.floor(r.rnd() * r.n); cand.splice(pos, 0, clean(w.t)); r.ok = pos; r.o = cand; r.bad = new Set();
    },
    body(r){ return mmRunText(r, (w, k) => { if (!mmScore(w)) return k < r.pos ? { t: w.t } : null; if (k < r.pos) return mmShown(r, k); if (k === r.pos) return { c: 'mrnext', h: '<i class="mrcaret"></i>' }; return null; }); },
    foot(r){ return `<div class="mmopts" data-n="${r.n}">${(r.o || []).map((t, j) => `<button class="mmopt ${r.bad.has(j) ? 'bad' : ''}" data-act="mm-opt" data-j="${j}" ${r.bad.has(j) ? 'disabled' : ''}><kbd>${j + 1}</kbd>${esc(t)}</button>`).join('')}</div>${r.diff < 2 ? '<button class="btn" data-act="mm-c-skip">Skip<kbd>S</kbd></button>' : ''}`; },
    pick(r, j){
      if (j >= r.o.length || r.bad.has(j)) return;
      if (j !== r.ok){ r.res[r.pos] = 0; r.bad.add(j); return mmPaint(true); }
      if (r.res[r.pos] == null) r.res[r.pos] = 1; this.adv(r);
    },
    adv(r){ r.pos = mmNextSc(r, r.pos + 1); if (r.pos >= r.words.length) return mmFinish(); this.opts(r); mmPaint(true); },
    act(r, a, el){ if (a === 'mm-opt') return this.pick(r, +el.dataset.j); if (a === 'mm-c-skip' && r.diff < 2){ r.res[r.pos] = 0; return this.adv(r); } },
    key(r, e){ const n = +e.key; if (n >= 1 && n <= r.n){ this.pick(r, n - 1); return true; } if ((e.key === 's' || e.key === 'S') && r.diff < 2){ this.act(r, 'mm-c-skip'); return true; } return false; },
    prog(r){ return [r.sc.filter(k => k < r.pos).length, r.sc.length, 'words']; }
  },
  /* ---- Speak: say it, it follows along ---- */
  speak: {
    init(r){ r.fin = ''; r.live = ''; r.prev = ''; r.on = false; r.err = ''; r.stuck = new Set(); r.pos = 0; r.stop = () => { r.on = false; try { r.rec?.abort(); } catch {} }; },
    align(r){
      const said = (r.prev + ' ' + r.live).split(/\s+/).map(mmNorm).filter(Boolean); let pos = 0; const res = r.res.map(() => null);
      const skipStuck = () => { while (pos < r.sc.length && r.stuck.has(r.sc[pos])){ res[r.sc[pos]] = 0; pos++; } };
      for (const t of said){
        skipStuck();
        for (let j = pos; j < Math.min(r.sc.length, pos + 6); j++){ const c = r.words[r.sc[j]].core; if (t === c || (c.length > 3 && mmLev1(t, c)) || (t.length > 2 && c.startsWith(t) && c.length - t.length <= 2)){ for (let q = pos; q < j; q++) res[r.sc[q]] = 0; res[r.sc[j]] = 1; pos = j + 1; break; } }
      }
      skipStuck(); r.res = res; r.pos = pos;
    },
    listen(r){
      const SR = mmSR(); if (!SR) return; const rec = r.rec = new SR(); rec.lang = 'en-AU'; rec.continuous = true; rec.interimResults = true;
      let fin = '';
      rec.onresult = e => { fin = ''; let live = ''; for (let i = 0; i < e.results.length; i++){ const t = e.results[i][0].transcript; if (e.results[i].isFinal) fin += t + ' '; else live += t + ' '; } r.live = fin + live; this.align(r); r.heard = live || fin.split(' ').slice(-8).join(' '); if (r.pos >= r.sc.length) return mmFinish(); mmPaint(); };
      rec.onerror = e => { if (e.error === 'no-speech' || e.error === 'aborted') return; r.on = false; r.err = e.error === 'not-allowed' || e.error === 'service-not-allowed' ? 'Recall isn’t allowed to use the microphone or speech recognition here. Allow it in Settings, or open Recall in Safari instead of from the Home Screen.' : e.error === 'network' ? 'Speech recognition needs an internet connection here.' : 'Speech recognition stopped (' + e.error + ').'; mmPaint(true); };
      rec.onend = () => { r.prev += ' ' + fin; r.live = ''; fin = ''; if (r.on && mm.run === r && !r.done) try { rec.start(); } catch { r.on = false; mmPaint(true); } };
      try { rec.start(); r.on = true; r.err = ''; } catch (e) { r.on = false; r.err = 'Couldn’t start listening.'; }
      mmPaint(true);
    },
    body(r){
      const curK = r.sc[r.pos] ?? r.words.length;
      return mmRunText(r, (w, k) => {
        if (!mmScore(w)) return k < curK ? { t: w.t } : null;
        if (k < curK) return mmShown(r, k);
        const j = r.sc.indexOf(k), hint = r.diff === 0 || (r.diff === 1 && (j - r.pos) % 2 === 0);
        if (k === curK) return { c: 'mrnext', t: hint ? mmFirstOf(w) : '', h: hint ? null : '<i class="mrcaret"></i>' };
        return r.diff < 2 ? (hint ? { c: 'mrfl', h: mmHintH(w) } : { c: 'mrfl mrh', t: w.t }) : null;
      }) + (r.heard ? `<p class="mmheard">“${esc(r.heard.trim())}”</p>` : '');
    },
    foot(r){ return (r.err ? `<span class="mmfhint mmerr">${esc(r.err)}</span>` : '') + `<button class="btn ${r.on ? '' : 'primary'}" data-act="mm-s-mic">${r.on ? 'Pause' : r.prev || r.live ? 'Keep going' : 'Start speaking'}</button><button class="btn" data-act="mm-s-stuck">I’m stuck</button><button class="btn" data-act="mm-done">Finish</button>`; },
    act(r, a){
      if (a === 'mm-s-mic'){ if (r.on){ r.on = false; try { r.rec?.stop(); } catch {} return mmPaint(true); } return this.listen(r); }
      if (a === 'mm-s-stuck'){ if (r.pos < r.sc.length){ r.stuck.add(r.sc[r.pos]); this.align(r); if (r.pos >= r.sc.length) return mmFinish(); } return mmPaint(); }
      if (a === 'mm-done'){ r.sc.forEach(k => { if (r.res[k] == null) r.res[k] = 0; }); return mmFinish(); }
    },
    key(){ return false; },
    prog(r){ return [r.pos, r.sc.length, 'words']; }
  }
};

/* ---------- practice screen ---------- */
function mmRunHead(r){
  const m = mmMode(r.mode), acc = mmAccNow(r), [a, b, unit] = mmEng(r).prog(r);
  return `<span class="mmrmode">${mmIcon(r.mode, 16)}<b>${m.n}</b><span>${MM_DIFF[r.diff]} · ${esc(r.label)}</span></span><span class="grow"></span><span class="mmracc num" id="mmracc">${r.mode === 'listen' ? '' : acc == null ? 'Accuracy –' : `Accuracy ${acc}%`}</span><span class="mmrprog num" id="mmrprog">${a} of ${b} ${unit}</span>`;
}
function mmRenderRun(root){
  const r = mm.run;
  if (r.done) return mmRenderResult(root, r);
  const p = mmGet(r.pid);
  root.innerHTML = `<div class="mmrun mode-${r.mode}">
    <div class="mmrtop"><button class="abi" data-act="mm-exit" aria-label="Stop practising" title="Stop (Esc)"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><span class="mmrtt">${esc(p?.t || '')}</span>${mmRunHead(r)}</div>
    <div class="mmrbar"><i id="mmrbar" style="width:${mmBarPct(r)}%"></i></div>
    <div class="mmrbody" id="mmbody" ${r.mode === 'reveal' ? 'data-act="mm-tap"' : ''}>${mmEng(r).body(r)}</div>
    <div class="mmrfoot" id="mmfoot">${mmEng(r).foot(r)}</div></div>`;
}
function mmBarPct(r){ const [a, b] = mmEng(r).prog(r); return b ? Math.min(100, a / b * 100) : 0; }
/* repaint the passage (and the controls if asked) without rebuilding inputs the student is typing in */
function mmPaint(foot){
  const r = mm.run; if (!r || view.name !== 'memo' || r.done) return;
  const b = $('#mmbody'); if (!b) return render();
  const hadFocus = document.activeElement?.id;
  b.innerHTML = mmEng(r).body(r);
  if (foot){ const f = $('#mmfoot'); if (f) f.innerHTML = mmEng(r).foot(r); }
  const hd = $('.mmrtop'); if (hd){ const acc = mmAccNow(r), [a, c, unit] = mmEng(r).prog(r); const ae = $('#mmracc'); if (ae && r.mode !== 'listen') ae.textContent = acc == null ? 'Accuracy –' : `Accuracy ${acc}%`; const pe = $('#mmrprog'); if (pe) pe.textContent = `${a} of ${c} ${unit}`; }
  const bar = $('#mmrbar'); if (bar) bar.style.width = mmBarPct(r) + '%';
  if (hadFocus === 'mmin' || foot || r.mode === 'blanks') mmFocus();
  mmBackBtn();
  const cur = b.querySelector('.mrnext, .mrcur, .mrinl'); if (cur && !mmInView(cur)) cur.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
}
function mmInView(el){ const r = el.getBoundingClientRect(), f = $('#mmfoot')?.getBoundingClientRect(); return r.top >= 60 && r.bottom <= (f ? f.top : innerHeight) - 8; }
function mmFocus(){ const el = $('#mmin') || $('#mmta'); if (el && document.activeElement !== el){ el.focus({ preventScroll: true }); if (el.id === 'mmta') el.setSelectionRange(el.value.length, el.value.length); } }
function mmShake(){ const el = $('#mmbody .mrnext') || $('#mmin'); if (!el) return; el.classList.remove('mmshk'); void el.offsetWidth; el.classList.add('mmshk'); }
function mmRenderResult(root, r){
  const m = mmMode(r.mode), p = mmGet(r.pid), mins = Math.floor(r.ms / 60000), secs = Math.round(r.ms / 1000) % 60;
  const missed = []; let nMiss = 0; r.words.forEach((w, k) => { if (r.res[k] !== 0) return; nMiss++; if (missed.length < 30) missed.push(w.t.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’]+$/gu, '')); });
  const nextDiff = r.diff < 2 ? { m: r.mode, d: r.diff + 1 } : (() => { const order = ['reveal', 'slider', 'first', 'blanks', 'reorder', 'target', 'choice', 'type', 'speak']; let i = order.indexOf(r.mode) + 1; while (i < order.length && mmBlocked(order[i])) i++; return i < order.length ? { m: order[i], d: 1 } : null; })();
  const SC = p ? mmSections(p) : [], secOf = p ? mmSecOf(p) : [], bySec = new Map();
  r.words.forEach((w, k) => { if (r.res[k] == null) return; const si = secOf[w.p] ?? -1; const o = bySec.get(si) || [0, 0]; o[0] += r.res[k]; o[1]++; bySec.set(si, o); });
  const secRows = [...bySec.entries()].sort((a, b) => a[0] - b[0]).map(([si, [x, n]]) => [SC[si]?.label || '', Math.round(x / n * 100)]);
  const sched = Object.entries(r.sched || {}), schedSecs = [...new Set(sched.map(([i]) => secOf[+i]))];
  const good = r.acc == null || r.acc >= 90;
  root.innerHTML = `<div class="mmres">
    <div class="mmresh">${r.acc == null ? `<b class="num">Done</b><span>Listened to ${r.words.length.toLocaleString()} words</span>` : `<b class="num">${r.acc}%</b><span>accuracy</span>`}</div>
    <p class="mmresm">${esc(m.n)} · ${MM_DIFF[r.diff]} · ${esc(r.label)} · ${r.words.length.toLocaleString()} words · ${mins}:${String(secs).padStart(2, '0')}</p>
    ${secRows.length > 1 ? `<div class="mmresp">${secRows.map(([l, a]) => `<div><span>${esc(l)}</span><div class="mmbar"><i style="width:${a}%"></i></div><b class="num">${a}%</b></div>`).join('')}</div>` : ''}
    ${missed.length ? `<div class="mmmiss"><span class="mmgl">${r.mode === 'target' ? 'Swaps you missed or wrong taps' : 'Words you missed'}</span><div>${missed.map(t => `<span>${esc(t)}</span>`).join('')}${nMiss > missed.length ? `<em>and ${nMiss - missed.length} more</em>` : ''}</div></div>` : ''}
    <p class="mmresn">+${r.gain} points${r.lv1 > r.lv0 ? ` · Level ${r.lv1}` : ''}${sched.length ? ` · ${schedSecs.length === 1 ? esc(SC[schedSecs[0]]?.label || 'This section') : 'These sections'} come${schedSecs.length === 1 ? 's' : ''} back ${mmWhen(Math.min(...sched.map(x => x[1])))}` : ''}</p>
    <div class="mmresb"><button class="btn" data-act="mm-home">Back to ${esc(p?.t || 'project')}</button><button class="btn ${good && nextDiff ? '' : 'primary'}" data-act="mm-again">Try again</button>${nextDiff ? `<button class="btn ${good ? 'primary' : ''}" data-act="mm-next" data-m="${nextDiff.m}" data-d="${nextDiff.d}">${nextDiff.m === r.mode ? 'Harder: ' + MM_DIFF[nextDiff.d] : 'Next: ' + esc(mmMode(nextDiff.m).n)}</button>` : ''}</div></div>`;
}

/* ===================== banks: vocabulary, techniques, notes ===================== */
/* each entry is its own settings key (mmb_<id>) so entries added on two devices both survive a sync */
const MB_KINDS = { v: ['Vocabulary', 'word', 'Add word'], t: ['Techniques', 'technique', 'Add technique'], n: ['Notes', 'note', 'Add note'] };
const MB_FORMS = ['Any form', 'Poetry', 'Prose fiction', 'Drama', 'Film', 'Nonfiction', 'Speech', 'Visual', 'Creative writing'];
const mbAll = k => Object.keys(S.settings || {}).filter(x => x.startsWith('mmb_') && S.settings[x]?.id && (!k || S.settings[x].k === k)).map(x => S.settings[x]).sort((a, b) => (b.upd || b.at || 0) - (a.upd || a.at || 0));
function mbPut(it, label){ undoTx = null; undoLabel = label; S.settings = { ...S.settings, ['mmb_' + it.id]: it }; saveSettings(); }
function mbDel(id){ undoTx = null; undoLabel = 'delete entry'; const s = { ...S.settings }; delete s['mmb_' + id]; S.settings = s; saveSettings(); }
const mbText = it => [it.w, it.m, it.e, it.n, it.f, it.d, it.x, it.h, it.b, it.g].filter(Boolean).join(' ').toLowerCase();
function mbListHtml(){
  const q = mm.bq.trim().toLowerCase(), words = q.split(/\s+/).filter(Boolean);
  let items = mbAll(mm.bank).filter(it => words.every(w => mbText(it).includes(w)));
  if (mm.bank === 't' && mm.bf !== 'all') items = items.filter(it => (it.f || 'Any form') === mm.bf);
  if (mm.bank === 'v') items.sort((a, b) => (a.w || '').localeCompare(b.w || '', undefined, { sensitivity: 'base' }));
  const tags = it => it.g ? `<span class="mbtags">${String(it.g).split(/[,;]/).map(t => t.trim()).filter(Boolean).map(t => `<span>${esc(t)}</span>`).join('')}</span>` : '';
  if (!items.length) return `<p class="mbempty">${q || mm.bf !== 'all' ? 'Nothing matches.' : mm.bank === 'v' ? 'No words yet. Add one, or select a word in one of your projects and press Add to vocab.' : mm.bank === 't' ? 'No techniques yet. Add the ones you use, with the form they suit and an example.' : 'No notes yet.'}</p>`;
  if (mm.bank === 'n') return `<div class="mbnotes">${items.map(it => `<button class="mbnote" data-act="mb-edit" data-id="${esc(it.id)}"><b>${esc(it.h || 'Untitled')}</b><span>${esc((it.b || '').slice(0, 400))}</span>${tags(it)}</button>`).join('')}</div>`;
  return `<div class="mblist">${items.map(it => mm.bank === 'v'
    ? `<button class="mbrow" data-act="mb-edit" data-id="${esc(it.id)}"><span class="mbword">${esc(it.w || '')}</span><span class="mbm">${esc(it.m || '')}${it.e ? `<i>${esc(it.e)}</i>` : ''}</span>${tags(it)}</button>`
    : `<button class="mbrow" data-act="mb-edit" data-id="${esc(it.id)}"><span class="mbword">${esc(it.n || '')}<small>${esc(it.f || 'Any form')}</small></span><span class="mbm">${esc(it.d || '')}${it.x ? `<i>${esc(it.x)}</i>` : ''}</span>${tags(it)}</button>`).join('')}</div>`;
}
function mmRenderBanks(root, phone){
  const n = k => mbAll(k).length, K = MB_KINDS[mm.bank] || MB_KINDS.v;
  const forms = mm.bank === 't' ? `<div class="mmchips mbforms">${['all', ...MB_FORMS].map(f => `<button class="mmchip" data-act="mb-form" data-v="${esc(f)}" aria-pressed="${mm.bf === f}">${f === 'all' ? 'All' : esc(f)}</button>`).join('')}</div>` : '';
  root.innerHTML = `${document.body.classList.contains('desktop') ? '' : `<div class="mmp mmpg"><div class="mmtop"><h1>Memorise</h1><span class="grow"></span>${phone ? '' : mmTabs()}</div>${phone ? mmTabs() : ''}</div>`}<div class="mbw">
    <div class="mbhead"><div class="seg mbtabs" role="group" aria-label="Bank">${Object.entries(MB_KINDS).map(([k, [nm]]) => `<button data-act="mm-bank-tab" data-v="${k}" aria-pressed="${mm.bank === k}">${nm} <span class="num">${n(k)}</span></button>`).join('')}</div>
      <label class="mbsearch"><svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="4.6" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M10.5 10.5 14 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><input id="mbq" type="search" placeholder="Search ${esc(K[0].toLowerCase())}" value="${esc(mm.bq)}" autocomplete="off" aria-label="Search"></label>
      <button class="btn primary" data-act="mb-new">${K[2]}</button></div>
    ${forms}<div id="mblist">${mbListHtml()}</div></div>`;
}
function mbDialog(kind, id, pre){
  const it = id ? S.settings['mmb_' + id] : { k: kind, ...(pre || {}) }; if (!it) return; const k = it.k;
  const f = (lab, idn, val, ph, area) => `<div class="field"><label for="${idn}">${lab}</label>${area ? `<textarea class="in" id="${idn}" rows="${area}" placeholder="${esc(ph)}">${esc(val || '')}</textarea>` : `<input class="in" id="${idn}" value="${esc(val || '')}" placeholder="${esc(ph)}" maxlength="200">`}</div>`;
  const body = k === 'v' ? f('Word or phrase', 'mbw', it.w, 'e.g. ephemeral') + f('Meaning', 'mbm', it.m, 'What it means, in your words', 2) + f('Example', 'mbe', it.e, 'A sentence you could use it in', 2) + f('Tags', 'mbg', it.g, 'e.g. Mod A, verbs for analysis')
    : k === 't' ? f('Technique', 'mbn', it.n, 'e.g. enjambment') + `<div class="field"><label for="mbf">Form</label><select class="in" id="mbf">${MB_FORMS.map(x => `<option ${x === (it.f || 'Any form') ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></div>` + f('What it does', 'mbd', it.d, 'The effect it creates, and how to write about it', 3) + f('Example', 'mbx', it.x, 'A quote from your text, with the effect', 2) + f('Tags', 'mbg', it.g, 'e.g. Mod B, imagery')
    : f('Title', 'mbh', it.h, 'e.g. Thesis ideas for Mod B') + f('Note', 'mbb', it.b, 'Anything worth keeping', 10) + f('Tags', 'mbg', it.g, 'optional');
  openDialog(`<div class="dialog mbdlg" role="dialog" aria-modal="true" aria-labelledby="mbdh" style="max-width:560px"><header><h2 id="mbdh">${id ? 'Edit ' : 'New '}${MB_KINDS[k][1]}</h2></header><div class="body">${body}</div>
    <footer>${id ? `<button class="btn danger" data-act="mb-del" data-id="${esc(id)}">Delete</button>` : ''}<span class="grow"></span><button class="btn" data-act="close">Cancel</button><button class="btn primary" data-act="mb-save" data-k="${k}" data-id="${esc(id || '')}">Save</button></footer></div>`, d => d.querySelector('input, textarea')?.focus());
}
function mbSave(k, id){
  const v = sel => ($(sel)?.value || '').trim(), old = id ? S.settings['mmb_' + id] : null;
  const it = { ...(old || {}), id: id || uid('mb'), k, at: old?.at || Date.now(), upd: Date.now(), g: v('#mbg') };
  if (k === 'v'){ it.w = v('#mbw'); it.m = v('#mbm'); it.e = v('#mbe'); if (!it.w) return $('#mbw').focus(); }
  if (k === 't'){ it.n = v('#mbn'); it.f = v('#mbf'); it.d = v('#mbd'); it.x = v('#mbx'); if (!it.n) return $('#mbn').focus(); }
  if (k === 'n'){ it.h = v('#mbh'); it.b = v('#mbb'); if (!it.h && !it.b) return $('#mbh').focus(); }
  mbPut(it, old ? 'edit ' + MB_KINDS[k][1] : 'add ' + MB_KINDS[k][1]); closeDialog(); toast(old ? 'Saved' : 'Added to ' + MB_KINDS[k][0].toLowerCase());
}
function mbFromSelection(){
  const p = mmCur(), r = mm.selW; if (!p || !r) return;
  const { W } = mmParsed(p), w = W.slice(r.a, r.b + 1).map(x => x.t).join(' ').replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’]+$/gu, '');
  const s0 = W[r.a].s, sent = W.filter(x => x.s === s0).map(x => x.t).join(' ');
  getSelection()?.removeAllRanges(); $('#mmfmt')?.remove(); mm.selW = null;
  mbDialog('v', null, { w, e: sent, g: mmSubName(p) || '' });
}
document.addEventListener('input', e => { if (e.target.id === 'mbq'){ mm.bq = e.target.value; const l = $('#mblist'); if (l) l.innerHTML = mbListHtml(); } });

/* ===================== rubric guide ===================== */
function mmRenderGuide(root, phone){
  const nb = ([id, a, b]) => `<button class="mgnb" data-act="mg-sec" data-v="${id}" aria-current="${mm.g === id}"><span>${a}</span><small>${b}</small></button>`;
  const nav = phone ? `<div class="mgchips">${MG.GNAV.map(([id, a]) => `<button class="mmchip" data-act="mg-sec" data-v="${id}" aria-pressed="${mm.g === id}">${a}</button>`).join('')}</div>`
    : `<nav class="mgnav" aria-label="Guide"><div class="mgnh">Modules</div>${MG.GNAV.slice(0, 4).map(nb).join('')}<div class="mgnh">Toolkit</div>${MG.GNAV.slice(4).map(nb).join('')}</nav>`;
  root.innerHTML = `${document.body.classList.contains('desktop') ? '' : `<div class="mmp mmpg"><div class="mmtop"><h1>Memorise</h1><span class="grow"></span>${phone ? '' : mmTabs()}</div>${phone ? mmTabs() : ''}</div>`}<div class="mgw">${nav}<div class="mgd" id="mgd">${MG.html(mm.g)}<p class="g-src mgcred">Rubric guide compiled by Tim Lin from North Sydney Boys resources, used with permission.</p></div></div>`;
}

/* ===================== back and undo ===================== */
const MM_NOSNAP = new Set(['words', 'M', 'rnd', 'stop', 'sc', 'units', 'unitOf', 'order', 'blanks', 'isB', 'bank', 'ch', 'pool', 'swap', 'sents', 'rec', 't0', 'seed', 'label', 'pid', 'mode', 'diff', 'max', 'hint', 'undo', 'done', 'ms']);
function mmSnapR(r){ const o = {}; for (const [k, v] of Object.entries(r)) if (!MM_NOSNAP.has(k) && typeof v !== 'function') o[k] = structuredClone(v); return o; }
const mmSigR = o => JSON.stringify(o, (k, v) => v instanceof Set ? [...v] : v instanceof Map ? [...v.entries()] : v);
/* run something that may change the session; if it did, remember how it was so ⌘Z / Backspace / Back can undo it */
function mmStep(r, fn){
  if (r.mode === 'listen' || r.mode === 'type') return fn();
  const before = mmSnapR(r), sig = mmSigR(before), out = fn();
  if (mm.run === r && !r.done && mmSigR(mmSnapR(r)) !== sig){ (r.undo = r.undo || []).push(before); if (r.undo.length > 300) r.undo.shift(); mmBackBtn(); }
  return out;
}
function mmUndoStep(){
  const r = mm.run; if (!r || r.done || !r.undo?.length) return false;
  Object.assign(r, r.undo.pop()); if (r.mode === 'speak'){ r.prev = ''; r.live = ''; }
  mmPaint(true); toast('Stepped back', 1200); return true;
}
/* Memorise pages: what you had open before (project, section picked, guide page…) */
function mmSnapNav(){ return { tab: mm.tab, pid: mm.pid, g: mm.g, bank: mm.bank, screen: mm.screen, sheet: mm.sheet, sel: [...mm.sel], range: mm.range ? { ...mm.range } : null, mode: mm.mode, diff: mm.diff }; }
function mmNav(){ const s = mmSnapNav(), last = mm.hist.at(-1); if (!last || JSON.stringify(last) !== JSON.stringify(s)){ mm.hist.push(s); if (mm.hist.length > 80) mm.hist.shift(); } }
function mmCanBack(){ return view.name === 'memo' && (!!mm.run || mm.hist.length > 0); }
function mmBack(){
  if (view.name !== 'memo') return false;
  const r = mm.run;
  if (r && !r.done){ if (mmUndoStep()) return true; mmExit(); return true; }
  if (r?.done){ mm.run = null; document.body.classList.remove('mmrun'); render(); return true; }
  const s = mm.hist.pop(); if (!s) return false;
  Object.assign(mm, { tab: s.tab, pid: s.pid, g: s.g, bank: s.bank, screen: s.screen, sheet: s.sheet, sel: new Set(s.sel), range: s.range, mode: s.mode, diff: s.diff });
  ls.set('mm-tab', mm.tab); render(); return true;
}
function mmBackBtn(){ const b = $('#navcl [data-act="hist-back"]'); if (b && view.name === 'memo') b.disabled = !(mmCanBack() || navH.back.length); }

/* ===================== events ===================== */
document.addEventListener('click', async e => {
  const a = e.target.closest?.('[data-act]'); if (!a) return; const act = a.dataset.act;
  if (!/^(mm|mg|mb)-/.test(act)) return;
  if (a.getAttribute('aria-disabled') === 'true' && act === 'mm-mode') return toast(a.title || 'Not available here', 4000);
  const r = mm.run;
  if (r && !r.done && view.name === 'memo'){
    if (act === 'mm-exit') return mmExit();
    const eng = mmEng(r); if (eng.act){ e.preventDefault(); return mmStep(r, () => eng.act(r, act, a)); }
    return;
  }
  if (['mm-tab', 'mm-pick', 'mm-open', 'mm-plist', 'mm-sec', 'mm-unrange', 'mm-prac', 'mm-sheet', 'mm-due', 'mm-mode', 'mm-diff', 'mg-sec', 'mm-bank-tab'].includes(act) && view.name === 'memo') mmNav();
  switch (act){
    case 'mm-tab': mm.tab = a.dataset.v; ls.set('mm-tab', mm.tab); if (view.name !== 'memo') return go('memo'); render(); window.scrollTo(0, 0); return;
    case 'mm-new': closeMenu(); return mmDialog(null);
    case 'mm-pick': mmPick(a.dataset.id); return render();
    case 'mm-plist': mm.screen = 'list'; mm.sheet = false; return render();
    case 'mm-switch': { const rc = a.getBoundingClientRect(); return menuAt(mmAll().map(x => `<button data-act="mm-open" data-id="${esc(x.id)}">${esc(x.t || 'Untitled')}</button>`).join(''), { x: rc.left, y: rc.bottom + 4 }); }
    case 'mm-pmenu': { const rc = a.getBoundingClientRect(); return menuAt(mmMenuHtml(a.dataset.id, false), { x: Math.min(rc.left, innerWidth - 230), y: rc.bottom + 4 }); }
    case 'mm-open': closeMenu(); mmNav(); mmPick(a.dataset.id); return render();
    case 'mm-secs': closeMenu(); return mmSecDialog(a.dataset.id);
    case 'mm-secsave': return mmSecSave(a.dataset.id, false);
    case 'mm-secauto': return mmSecSave(a.dataset.id, true);
    case 'mm-navtog': mm.navh = !mm.navh; ls.set('mm-navh', mm.navh); return render();
    case 'mm-edit': closeMenu(); return mmDialog(a.dataset.id);
    case 'mm-clearfmt': { closeMenu(); const p = mmGet(a.dataset.id); if (p){ mmPut({ ...p, marks: [] }, 'remove formatting'); renderMemo(); toast('Formatting removed · ⌘Z to undo'); } return; }
    case 'mm-resetp': { closeMenu(); const p = mmGet(a.dataset.id); if (p){ mmPut({ ...p, secs: {}, hist: [], ms: {}, pts: 0 }, 'reset progress'); render(); toast('Progress reset · ⌘Z to undo'); } return; }
    case 'mm-delask': { closeMenu(); const p = mmGet(a.dataset.id); if (!p) return;
      return openDialog(`<div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="mmdelh" style="max-width:420px"><header><h2 id="mmdelh">Delete “${esc(p.t)}”?</h2></header><div class="body"><p class="muted">The text, its formatting and its practice history go. ⌘Z brings it back.</p></div><footer><span class="grow"></span><button class="btn" data-act="close">Cancel</button><button class="btn danger" data-act="mm-del" data-id="${esc(p.id)}">Delete</button></footer></div>`); }
    case 'mm-del': mmRemove(a.dataset.id); if (mm.pid === a.dataset.id){ mm.pid = null; mm.screen = 'list'; } closeDialog(); toast('Project deleted · ⌘Z to undo'); return;
    case 'mm-save': return mmSaveDialog(a.dataset.id || null);
    case 'mm-kind': a.parentElement.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b === a))); return;
    case 'mm-file': return $('#mmdf')?.click();
    case 'mm-sec': {
      const v = a.dataset.v; mm.range = null;
      if (v === 'all') mm.sel.clear(); else { const i = +v; mm.sel.has(i) ? mm.sel.delete(i) : mm.sel.add(i); if (mm.sel.size === mmSections(mmCur()).length) mm.sel.clear(); }
      return render();
    }
    case 'mm-unrange': mm.range = null; return render();
    case 'mm-mode': mm.mode = a.dataset.v; ls.set('mm-mode', mm.mode); return render();
    case 'mm-diff': mm.diff = +a.dataset.v; ls.set('mm-diff', mm.diff); return render();
    case 'mm-start': return mmStart();
    case 'mm-sheet': mm.sheet = true; return render();
    case 'mm-sheetx': mm.sheet = false; return render();
    case 'mm-due': {
      const ps = mmAll().map(p => ({ p, d: mmDue(p) })).filter(x => x.d.length).sort((x, y) => y.d.length - x.d.length); if (!ps.length) return toast('Nothing due');
      mmPick(ps[0].p.id); { const so = mmSecOf(ps[0].p); mm.sel = new Set(ps[0].d.map(i => so[i])); } mm.range = null; if (ps[0].p.last){ mm.mode = ps[0].p.last.m; mm.diff = ps[0].p.last.d; } mm.tab = 'projects'; if (mmPhone()) mm.sheet = true; if (view.name !== 'memo') return go('memo'); return render();
    }
    case 'mm-tool': mm.tool = a.dataset.v; a.parentElement.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b === a))); return;
    case 'mm-fmt': return mmFormat(a.dataset.c === 'clear' ? 'clear' : mm.tool, a.dataset.c);
    case 'mm-prac': { const s = mm.selW; if (!s) return; mm.range = { a: s.a, b: s.b }; mm.sel.clear(); getSelection()?.removeAllRanges(); $('#mmfmt')?.remove(); mm.selW = null; if (mmPhone()) mm.sheet = true; return render(); }
    case 'mm-home': mm.run = null; document.body.classList.remove('mmrun'); return render();
    case 'mm-again': { const o = mm.run; if (!o) return; mm.mode = o.mode; mm.diff = o.diff; mm.run = null; return mmRestart(o); }
    case 'mm-next': { const o = mm.run; if (!o) return; mm.mode = a.dataset.m; mm.diff = +a.dataset.d; ls.set('mm-mode', mm.mode); ls.set('mm-diff', mm.diff); mm.run = null; return mmRestart(o); }
    case 'mm-bank-tab': mm.bank = a.dataset.v; mm.bf = 'all'; ls.set('mm-bank', mm.bank); return render();
    case 'mb-form': mm.bf = a.dataset.v; return render();
    case 'mb-new': return mbDialog(mm.bank, null);
    case 'mb-edit': return mbDialog(null, a.dataset.id);
    case 'mb-save': return mbSave(a.dataset.k, a.dataset.id || null);
    case 'mb-del': mbDel(a.dataset.id); closeDialog(); return toast('Deleted · ⌘Z to undo');
    case 'mm-vocab': return mbFromSelection();
    case 'mg-sec': mm.g = a.dataset.v; ls.set('mm-g', mm.g); render(); window.scrollTo(0, 0); $('#mgd')?.scrollTo?.(0, 0); return;
    case 'mg-toc': { const t = document.getElementById(a.dataset.id); t?.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    case 'mg-mem': e.preventDefault(); e.stopPropagation(); return mmFromExemplar(a.dataset.i);
  }
});
function mmMenuHtml(id, open){
  const i = esc(id);
  return `${open ? `<button data-act="mm-open" data-id="${i}">Open</button>` : ''}<button data-act="mm-edit" data-id="${i}">Edit text and details…</button><button data-act="mm-secs" data-id="${i}">Edit sections…</button><button data-act="mm-clearfmt" data-id="${i}">Remove all formatting</button><button data-act="mm-resetp" data-id="${i}">Reset progress</button><hr><button class="danger" data-act="mm-delask" data-id="${i}">Delete project…</button>`;
}
/* right-click a project for its options; right-click the empty part of the list for a new one */
document.addEventListener('contextmenu', e => {
  if (view.name !== 'memo' || mm.run) return;
  const row = e.target.closest?.('.mmproj, .mmprow'), list = e.target.closest?.('.mmnav, .mmplist');
  if (!row && !list) return;
  e.preventDefault(); e.stopPropagation();
  const html = row ? mmMenuHtml(row.dataset.id, true) : `<button data-act="mm-new">New project…</button>`;
  menuAt(html, { x: Math.min(e.clientX, innerWidth - 230), y: Math.min(e.clientY, innerHeight - (row ? 230 : 50)) });
}, true);
/* "Try again" keeps exactly the same words, even if the selection on the home page has changed since */
function mmRestart(o){
  const p = mmGet(o.pid); if (!p) return render();
  const save = { sel: new Set(mm.sel), range: mm.range, pid: mm.pid }; mm.pid = o.pid;
  mm.range = { a: o.words[0].i, b: o.words.at(-1).i }; mm.sel.clear();
  const contiguous = o.words.every((w, k) => !k || w.i === o.words[k - 1].i + 1);
  if (!contiguous){ mm.range = null; const so = mmSecOf(p); mm.sel = new Set(o.words.map(w => so[w.p])); }
  mmStart(); if (mm.run) mm.run.label = o.label;
  if (save.pid === o.pid){ mm.sel = save.sel; mm.range = save.range; } else { mm.sel = new Set(); mm.range = null; } render();
}
document.addEventListener('click', async e => {
  if (e.target.id === 'bDl' || e.target.id === 'bOpen'){
    let blob; const w = e.target.id === 'bOpen' ? window.open('', '_blank') : null;
    try { blob = await MG.bookletBlob(); } catch { w?.close(); return toast('Couldn’t load the booklet'); }
    const url = URL.createObjectURL(blob);
    if (w){ w.opener = null; w.location = url; return; }
    const l = document.createElement('a'); l.href = url; l.download = 'English-Advanced-Writing-Booklet.pdf'; document.body.appendChild(l); l.click(); setTimeout(() => { URL.revokeObjectURL(url); l.remove(); }, 1000);
  }
});
document.addEventListener('change', e => {
  if (e.target.id !== 'mmdf') return; const f = e.target.files?.[0]; if (!f) return;
  const rd = new FileReader(); rd.onload = () => { const x = $('#mmdx'); if (x){ x.value = String(rd.result || '').replace(/\r/g, ''); if (!$('#mmdt').value.trim()) $('#mmdt').value = f.name.replace(/\.[^.]+$/, ''); } }; rd.readAsText(f);
});
document.addEventListener('input', e => { const r = mm.run; if (!r || r.done || view.name !== 'memo') return; const eng = mmEng(r); if (eng.input) mmStep(r, () => eng.input(r, e.target)); });
document.addEventListener('keydown', e => {
  if (view.name !== 'memo' || dialogOpen()) return;
  const r = mm.run, ae = document.activeElement, fieldEmpty = !isTyping(ae) || ((ae.id === 'mmin') && !ae.value);
  if (r && !r.done && (e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === 'z' && ae?.id !== 'mmta'){ e.preventDefault(); e.stopImmediatePropagation(); if (!mmUndoStep()) toast('Nothing to step back to', 1400); return; }
  if (e.key === 'Backspace' && !e.metaKey && !e.ctrlKey && !e.altKey && fieldEmpty && !$('#menu')){
    if (r && !r.done){ e.preventDefault(); e.stopImmediatePropagation(); if (!mmUndoStep()) toast('Nothing to step back to', 1400); return; }
    if (!isTyping(ae) && mmBack()){ e.preventDefault(); e.stopImmediatePropagation(); return; }
  }
  if (!r){ if (e.key === 'Escape' && $('#mmfmt')){ e.preventDefault(); e.stopImmediatePropagation(); $('#mmfmt').remove(); getSelection()?.removeAllRanges(); } if (e.key === 'Escape' && mm.sheet){ e.preventDefault(); e.stopImmediatePropagation(); mm.sheet = false; render(); } return; }
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  if (r.done){
    if (e.key === 'Escape' || e.key === 'Enter'){ e.preventDefault(); e.stopImmediatePropagation(); (e.key === 'Enter' ? $('.mmresb .btn.primary') : $('[data-act="mm-home"]'))?.click(); }
    return;
  }
  if (e.key === 'Escape'){ e.preventDefault(); e.stopImmediatePropagation(); return mmExit(); }
  const typingIn = isTyping(document.activeElement) && !['mmin', 'mmta', 'mmsl'].includes(document.activeElement.id);
  if (typingIn) return;
  if (mmStep(r, () => mmEng(r).key(r, e))){ e.preventDefault(); e.stopImmediatePropagation(); return; }
  if (!isTyping(document.activeElement) && e.key.length === 1){ e.stopImmediatePropagation(); }   // keep app shortcuts (D, B, T…) from leaving mid-session
}, true);
const mmWidthKey = () => mmPhone() ? 'p' : innerWidth < 1100 ? 'n' : 'w';
addEventListener('resize', () => { const k = mmWidthKey(); if (view.name === 'memo' && !mm.run && mm.wk !== k) render(); mm.wk = k; if (!matchMedia('(pointer: coarse)').matches) $('#mmfmt')?.remove(); });

/* called from render(): stop reading aloud or listening when you leave the page mid-session */
function mmRenderHook(){
  if (view.name !== 'memo' && mm.run?.stop && !mm.run.done) try { mm.run.stop(); } catch {}
  document.body.classList.toggle('mmrun', view.name === 'memo' && !!mm.run && !mm.run.done);
  if (view.name !== 'memo') $('#mmfmt')?.remove();
  /* phones have no top bar any more, so sync lives at the top of Settings */
  setTimeout(() => { try { const h = view.name === 'themes' && !document.body.classList.contains('desktop') && matchMedia('(max-width: 700px)').matches && $('.h7set > h1'); if (h && !$('.h7set .setsync')) h.insertAdjacentHTML('afterend', `<div class="setsync">${cloudPill().replace('id="cloudpill"', '')}</div>`); } catch {} }, 0);
}
function mmAppbar(){
  const r = mm.run;
  if (r && !r.done){ const p = mmGet(r.pid); return { title: `<b>${esc(mmMode(r.mode).n)}</b><span class="abmeta">${MM_DIFF[r.diff]} · ${esc(p?.t || '')} › ${esc(r.label)}</span>`, act: `<button class="btn" data-act="mm-exit">Stop<kbd>Esc</kbd></button>` }; }
  if (r?.done) return { title: `<b>Memorise</b><span class="abmeta">Results</span>`, act: '' };
  const due = mmDueAll();
  return { title: `<b>Memorise</b>${due && mm.tab === 'projects' ? `<span class="abmeta">${due} ${due === 1 ? 'paragraph' : 'paragraphs'} due</span>` : ''}`, act: mmTabs() + (mm.tab === 'projects' || !mm.tab ? `<button class="btn" data-act="mm-new">New project</button>` : '') };
}
