// Recall: send push notifications for study groups.
// Deploy as "notify" with "Verify JWT" turned OFF (the function checks who is calling itself).
// Secrets it needs (Edge Functions -> Secrets): VAPID_PRIVATE_JWK, VAPID_PUBLIC, PUSH_SECRET (all in recall-push-secrets.txt).
//  - From the app: { kind: 'start' | 'room', group } with the user's sign-in token. Tells their group mates.
//  - From the app: { kind: 'left', endpoint, clock } with the user's sign-in token. Tells that one device its timer stopped.
//  - From the hourly cron job: { kind: 'cron' } with the x-recall-cron header. Sends the daily study reminders.
// Web push is done by hand with WebCrypto (RFC 8291 encryption + RFC 8292 VAPID), so there's nothing to install.

const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
const env = (k: string) => (globalThis as any).Deno?.env.get(k) ?? (globalThis as any).process?.env[k] ?? '';

const enc = new TextEncoder();
const b64u = (b: Uint8Array) => btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s: string) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - s.length % 4) % 4)), c => c.charCodeAt(0));
const cat = (...a: Uint8Array[]) => { const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let i = 0; for (const x of a){ o.set(x, i); i += x.length; } return o; };
async function hkdf(salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, len: number){
  const k = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info }, k, len * 8));
}

// RFC 8291: encrypt the payload for one subscription (aes128gcm, one record)
export async function encryptPush(sub: { keys: { p256dh: string, auth: string } }, payload: Uint8Array){
  const uaPub = unb64u(sub.keys.p256dh), authSecret = unb64u(sub.keys.auth);
  const as = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const asPub = new Uint8Array(await crypto.subtle.exportKey('raw', as.publicKey));
  const uaKey = await crypto.subtle.importKey('raw', uaPub, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: uaKey }, as.privateKey, 256));
  const ikm = await hkdf(authSecret, shared, cat(enc.encode('WebPush: info\0'), uaPub, asPub), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode('Content-Encoding: aes128gcm\0'), 16);
  const nonce = await hkdf(salt, ikm, enc.encode('Content-Encoding: nonce\0'), 12);
  const key = await crypto.subtle.importKey('raw', cek, 'AES-GCM', false, ['encrypt']);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, key, cat(payload, new Uint8Array([2]))));
  const rs = new Uint8Array(4); new DataView(rs.buffer).setUint32(0, 4096);
  return cat(salt, rs, new Uint8Array([asPub.length]), asPub, ct);
}

// RFC 8292: the VAPID header for one push service
let vapidKey: CryptoKey | null = null;
export async function vapidAuth(endpoint: string, subject = 'mailto:recall-app@users.noreply.github.com'){
  vapidKey ||= await crypto.subtle.importKey('jwk', JSON.parse(env('VAPID_PRIVATE_JWK')), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const head = b64u(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const body = b64u(enc.encode(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject })));
  const sig = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, vapidKey, enc.encode(head + '.' + body)));
  return `vapid t=${head}.${body}.${b64u(sig)}, k=${env('VAPID_PUBLIC')}`;
}

async function send(endpoint: string, sub: any, msg: Record<string, unknown>){
  if (!/^https:\/\//.test(endpoint)) return 400;
  const body = await encryptPush(sub, enc.encode(JSON.stringify(msg)));
  const r = await fetch(endpoint, { method: 'POST', headers: { Authorization: await vapidAuth(endpoint), 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', TTL: msg.kind === 'remind' ? '3600' : msg.kind === 'left' ? '300' : '900', Urgency: msg.kind === 'left' ? 'high' : 'normal' }, body });
  return r.status;
}

async function rpc(fn: string, args: Record<string, unknown>, auth?: string){
  const base = env('SUPABASE_URL'), key = env('SUPABASE_ANON_KEY');
  const r = await fetch(`${base}/rest/v1/rpc/${fn}`, { method: 'POST', headers: { apikey: key, Authorization: auth || `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify(args) });
  if (!r.ok) throw new Error(fn + ' ' + r.status + ' ' + await r.text());
  return r.json();
}

async function fanOut(rows: { endpoint: string, sub: any }[], msg: (r: any) => Record<string, unknown>){
  let sent = 0;
  await Promise.all(rows.map(async r => {
    try {
      const st = await send(r.endpoint, r.sub, msg(r));
      if (st === 404 || st === 410) await rpc('drop_push', { p_secret: env('PUSH_SECRET'), p_endpoint: r.endpoint });   // the device unsubscribed
      else if (st < 300) sent++;
    } catch { /* one bad subscription doesn't stop the rest */ }
  }));
  return sent;
}

export async function handle(req: Request){
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  try {
    const body = await req.json().catch(() => ({}));
    if (body.kind === 'cron'){
      if (!env('PUSH_SECRET') || req.headers.get('x-recall-cron') !== env('PUSH_SECRET')) return json({ error: 'no' }, 401);
      const rows = await rpc('due_reminders', { p_secret: env('PUSH_SECRET') });
      return json({ sent: await fanOut(rows, () => ({ kind: 'remind', title: 'Recall', body: 'You haven’t studied yet today. Even 20 minutes keeps your streak going.', url: './?go=decks' })) });
    }
    // a signed-in user telling their group
    const auth = req.headers.get('authorization') || '';
    const u = await fetch(`${env('SUPABASE_URL')}/auth/v1/user`, { headers: { authorization: auth, apikey: env('SUPABASE_ANON_KEY') } });
    if (!u.ok) return json({ error: 'Sign in first' }, 401);
    const uid = (await u.json())?.id;
    if (body.kind === 'left'){
      // "your timer stopped": only to the device that sent it, looked up with the user's own token (row-level security: own rows only)
      const ep = String(body.endpoint || ''); if (!/^https:\/\//.test(ep)) return json({ error: 'No device' }, 400);
      const q = await fetch(`${env('SUPABASE_URL')}/rest/v1/push_subs?select=endpoint,sub&endpoint=eq.${encodeURIComponent(ep)}`, { headers: { apikey: env('SUPABASE_ANON_KEY'), Authorization: auth } });
      const rows = q.ok ? await q.json() : [];
      const clock = String(body.clock || '').replace(/[^0-9:]/g, '').slice(0, 9);
      return json({ sent: await fanOut(rows, () => ({ kind: 'left', tag: 'f-left', go: 'stay', title: 'Your study timer stopped', body: clock ? `It stopped at ${clock} because you left Recall. Come back to carry on.` : 'It stopped because you left Recall. Come back to carry on.', url: './' })) });
    }
    const group = String(body.group || ''), kind = body.kind === 'room' ? 'room' : 'start';
    if (!/^[0-9a-f-]{36}$/i.test(group)) return json({ error: 'No group' }, 400);
    const subj = String(body.subject || '').slice(0, 60), mins = Math.max(5, Math.min(300, Math.round(+body.minutes || 0)));
    const rows = await rpc('push_targets', { p_secret: env('PUSH_SECRET'), p_sender: uid, p_group: group, p_kind: kind });
    const sent = await fanOut(rows, r => kind === 'room'
      ? { kind, group, title: r.group_name, body: `${r.sender_name} started a ${mins} minute group session. Join in?`, url: `./?go=group&g=${group}` }
      : { kind, group, title: r.group_name, body: `${r.sender_name} started studying${subj ? ' ' + subj : ''}.`, url: `./?go=group&g=${group}` });
    return json({ sent });
  } catch (e){ return json({ error: String((e as Error)?.message || e) }, 500); }
}

(globalThis as any).Deno?.serve(handle);
