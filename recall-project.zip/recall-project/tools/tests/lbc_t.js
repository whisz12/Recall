// Image viewer: right-click / hold / ⌘C copies the picture. node lbc_t.js W H tag [touch]
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]]; const TOUCH = process.argv[5] === 'touch';
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8777);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, hasTouch: TOUCH, isMobile: TOUCH });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'http://127.0.0.1:8777' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
  await p.goto('http://127.0.0.1:8777/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a);
  await E(() => { const c = document.createElement('canvas'); c.width = 600; c.height = 160; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 600, 160); x.fillStyle = '#000'; x.font = '28px serif'; x.fillText('(b) Four couples, each consisting of a male and a female', 20, 80);
    openGallery([{ src: c.toDataURL('image/jpeg', .9), label: 'Q1 · Question' }, { src: c.toDataURL('image/png'), label: 'Q1 · Solution' }], 0); });
  await p.waitForTimeout(300);
  const box = await p.locator('.lightbox figure img').boundingBox(), cx = box.x + box.width / 2, cy = box.y + box.height / 2;
  const clip = () => E(async () => { const it = (await navigator.clipboard.read())[0]; const bl = await it.getType('image/png'); const bm = await createImageBitmap(bl); return [it.types.join(','), bm.width, bm.height]; });
  if (TOUCH){
    await p.evaluate(([x, y]) => { const t = document.elementFromPoint(x, y); const o = { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 7, pointerType: 'touch', isPrimary: true }; t.dispatchEvent(new PointerEvent('pointerdown', o)); window.__up = () => { t.dispatchEvent(new PointerEvent('pointerup', o)); t.dispatchEvent(new MouseEvent('click', o)); }; }, [cx, cy]);
    await p.waitForTimeout(700); await E(() => __up()); await p.waitForTimeout(150);
  } else await p.mouse.click(cx, cy, { button: 'right' });
  console.log('menu:', await E(() => [!!document.querySelector('#menu.lbmenu'), [...document.querySelectorAll('#menu button')].map(b => b.textContent), getComputedStyle(document.querySelector('#menu')).zIndex]));
  await p.screenshot({ path: `/tmp/lbc_${TAG}_menu.png` });
  await p.click('#menu [data-lbm="copy"]'); await p.waitForTimeout(1500);
  console.log('after copy:', await E(() => [!!document.querySelector('.lightbox'), !!document.querySelector('#menu'), document.querySelector('#toast')?.textContent]), 'clipboard:', await clip().catch(e => 'ERR ' + e.message));
  // click away from the menu closes only the menu
  if (!TOUCH){ await p.mouse.click(cx, cy, { button: 'right' }); await p.mouse.click(30, H - 30); await p.waitForTimeout(150);
    console.log('click away:', await E(() => [!!document.querySelector('.lightbox'), !!document.querySelector('#menu')]));
    await p.mouse.click(cx, cy, { button: 'right' }); await p.keyboard.press('Escape'); console.log('esc:', await E(() => [!!document.querySelector('.lightbox'), !!document.querySelector('#menu')]));
    await E(() => navigator.clipboard.writeText('x')); await p.keyboard.press('ArrowRight'); await p.waitForTimeout(200); await p.keyboard.press('Control+c'); await p.waitForTimeout(600);
    console.log('ctrl+c on 2nd:', await E(() => gallery.i), await clip().catch(e => 'ERR ' + e.message));
    await p.mouse.click(30, H - 30); console.log('bg click closes viewer:', await E(() => !document.querySelector('.lightbox'))); }
  console.log('errors:', errs.length ? errs : 'none'); await b.close(); srv.close();
})();
