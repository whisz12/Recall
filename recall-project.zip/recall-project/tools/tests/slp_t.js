// Study timer: the screen turning itself off keeps it running; swiping out pauses it. node slp_t.js W H tag [touch]
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
const [W, H, TAG] = [+process.argv[2], +process.argv[3], process.argv[4]]; const TOUCH = process.argv[5] === 'touch';
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8778);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport: { width: W, height: H }, hasTouch: TOUCH, isMobile: TOUCH });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
  const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8');
  await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l);
    window.__notes = []; window.Notification = function(t){ __notes.push(t); this.close = () => {}; }; Notification.permission = 'granted'; Notification.requestPermission = async () => 'granted'; }, lib);
  await p.goto('http://127.0.0.1:8778/'); await p.waitForTimeout(1800);
  const E = (f, a) => p.evaluate(f, a);
  const vis = h => E(h => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => h }); Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => h ? 'hidden' : 'visible' }); document.dispatchEvent(new Event('visibilitychange')); }, h);
  const st = () => E(() => [focus.state, focus.by, !!focus.asleep, fClock(fSecs()), __notes.length, document.querySelector('#layer h2')?.textContent || '']);
  const start = mins => E(m => { closeDialog?.(); document.querySelector('#layer').innerHTML = ''; fStop(); focus = { ...focus, state: 'studying', subj: 'Maths', since: Date.now() - m * 60e3, acc: 0, subjAcc: {}, by: '', leftAt: 0, ack: true, asleep: 0, dev: FDEV }; fSave(); __notes = []; }, mins);
  console.log('touch device:', await E(() => fTouchDev()));
  await start(10); await E(() => { fTouchAt = Date.now() - 3e3; }); await vis(true);
  console.log('1 swipe out (touched 3 s ago):', await st()); await vis(false); await p.waitForTimeout(200); console.log('  back:', await st());
  await start(10); await E(() => { fTouchAt = Date.now() - 40e3; }); await vis(true);
  console.log('2 screen off (untouched 40 s):', await st());
  await E(() => dispatchEvent(new Event('pagehide'))); console.log('  pagehide while off:', await st());
  await vis(false); await p.waitForTimeout(200); console.log('  screen on:', await st());
  // swipe signs win over a long untouched spell
  await start(10); await E(() => { fTouchAt = Date.now() - 40e3; fEv.cancelAt = Date.now() - 300; }); await vis(true);
  console.log('2b untouched 40 s but a touch was cancelled just now:', await st()); await vis(false); await E(() => { fEv.cancelAt = 0; });
  await start(10); await E(() => { fTouchAt = Date.now() - 40e3; fEv.edgeAt = Date.now() - 500; }); await vis(true);
  console.log('2c untouched 40 s, touch at the bottom edge just now:', await st()); await vis(false); await E(() => { fEv.edgeAt = 0; });
  // the phone test
  await E(() => { document.querySelector('#layer').innerHTML = ''; optionsDialog(); }); console.log('options has test:', await E(() => !!document.querySelector('[data-act="ltest"]')));
  await p.click('[data-act="ltest"]'); await p.click('[data-lt="on"]');
  await start(10); await E(() => { fTouchAt = Date.now() - 2e3; }); await vis(true); await p.waitForTimeout(300); await vis(false); await p.waitForTimeout(300);
  console.log('test asks:', await E(() => document.querySelector('#lth')?.textContent)); await p.screenshot({ path: `/tmp/slp_${TAG}_lt.png` });
  await p.click('[data-lt="swipe"]');
  await E(() => { fTouchAt = Date.now() - 40e3; }); await vis(true); await vis(false); await p.waitForTimeout(150); await p.click('[data-lt="auto"]');
  await E(() => optionsDialog()); await p.click('[data-act="ltest"]'); console.log('test dialog:', await E(() => document.querySelector('#ltd').closest('.dialog').querySelector('.body p:last-child').textContent));
  await p.screenshot({ path: `/tmp/slp_${TAG}_ltd.png` });
  console.log('sample:', await E(() => JSON.stringify(ltGet().s.map(x => [x.did, x.rule, x.ran > 200, x.ev.length]))));
  await p.click('[data-lt="off"]'); await E(() => { document.querySelector('#layer').innerHTML = ''; });
  // off for two hours
  await start(10); await E(() => { fTouchAt = Date.now() - 40e3; }); await vis(true); await E(() => { focus.asleep = Date.now() - 2 * 3600e3; focus.since = Date.now() - 2 * 3600e3 - 10 * 60e3; fSave(); }); await vis(false); await p.waitForTimeout(300);
  console.log('3 off 2 h, back:', await st()); await p.screenshot({ path: `/tmp/slp_${TAG}_ask.png` });
  await p.click('[data-fslept="drop"]'); await p.waitForTimeout(200); console.log('  don’t count:', await st(), await E(() => document.querySelector('#toast')?.textContent));
  await start(10); await E(() => { fTouchAt = Date.now() - 40e3; }); await vis(true); await E(() => { focus.asleep = Date.now() - 2 * 3600e3; fSave(); }); await vis(false); await p.waitForTimeout(300);
  await p.click('[data-fslept="keep"]'); console.log('  count it:', await st());
  // iOS closed Recall while the screen was off
  await start(10); await E(() => { focus.asleep = Date.now() - 5 * 60e3; fSave(); }); await p.reload(); await p.waitForTimeout(2500); console.log('4 reopened after being closed while off:', await st());
  console.log('errors:', errs.length ? errs : 'none'); await b.close(); srv.close();
})();
