module.exports = async (p, E, shot) => {
  const M = !!process.env.MOBILE, log = (...a) => console.log(...a);
  const c = await E(() => Object.values(S.cards).find(c => (c.solImgs || []).length >= 1 && qImgsOf(c).length >= 1)?.id);
  await E(id => openGallery(cardImages(S.cards[id]), 0), c); await p.waitForTimeout(400);
  const st = () => E(() => ({ open: !!$('.lightbox'), s: +lbz.s.toFixed(2), x: Math.round(lbz.x), y: Math.round(lbz.y), lab: $('.lbzv')?.innerText, i: gallery?.i, n: gallery?.items.length }));
  log('open', JSON.stringify(await st()));
  const r = await p.locator('.lightbox figure img').boundingBox(); const cx = r.x + r.width * .3, cy = r.y + r.height * .3;
  await p.mouse.click(cx, cy); await p.waitForTimeout(200); log('click image keeps it open', JSON.stringify(await st()));
  if (!M){
    await p.mouse.dblclick(cx, cy); await p.waitForTimeout(300);
    log('dblclick', JSON.stringify(await st()), 'point under cursor kept', await E(([x, y, r0]) => { const r = $('.lightbox figure img').getBoundingClientRect(); return [+((x - r.left) / r.width).toFixed(3), +((y - r.top) / r.height).toFixed(3)]; }, [cx, cy, r]));
    await shot('zoomed');
    await p.mouse.move(cx, cy); await p.mouse.down(); await p.mouse.move(cx + 150, cy + 80, { steps: 6 }); await p.mouse.up(); await p.waitForTimeout(150);
    log('drag', JSON.stringify(await st()));
    await p.mouse.wheel(0, 120); await p.waitForTimeout(150); log('scroll pans', JSON.stringify(await st()));
    await p.keyboard.down('Meta'); await p.mouse.wheel(0, -200); await p.keyboard.up('Meta'); await p.waitForTimeout(150); log('cmd wheel', JSON.stringify(await st()));
    await p.keyboard.press('ArrowRight'); await p.waitForTimeout(150); log('arrow pans when zoomed', JSON.stringify(await st()));
    await p.keyboard.press('0'); await p.waitForTimeout(250); log('0 fits', JSON.stringify(await st()));
    await p.keyboard.press('ArrowRight'); await p.waitForTimeout(250); log('arrow steps at 100%', JSON.stringify(await st()));
    await p.keyboard.press('='); await p.keyboard.press('='); await p.waitForTimeout(250); log('+ +', JSON.stringify(await st()));
  }
  await p.click('[data-lbz="in"]'); await p.waitForTimeout(250); log('button +', JSON.stringify(await st()));
  await p.click('[data-lbz="out"]'); await p.waitForTimeout(250); log('button −', JSON.stringify(await st()));
  await p.click('.lbzv'); await p.waitForTimeout(250); log('fit', JSON.stringify(await st()));
  // pinch with two touch points via CDP
  const cdp = await p.context().newCDPSession(p); const r2 = await p.locator('.lightbox figure img').boundingBox(), mx = r2.x + r2.width / 2, my = r2.y + r2.height / 2;
  const tp = (d) => [{ x: mx - d, y: my, id: 1 }, { x: mx + d, y: my, id: 2 }];
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: tp(40) });
  for (let d = 40; d <= 120; d += 10) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: tp(d) });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await p.waitForTimeout(250);
  log('pinch', JSON.stringify(await st()));
  await shot('pinch');
  // background click closes
  await p.mouse.click(8, 300); await p.waitForTimeout(200); log('background closes', JSON.stringify(await st()));
  // data-zoom images in a card step through their neighbours
  log('data-zoom groups', await E(() => { const d = document.createElement('div'); d.innerHTML = '<img data-zoom src="a.png" alt="Worked solution 1"><img data-zoom src="b.png" alt="Worked solution 2">'; document.body.appendChild(d); d.children[1].click(); const r = [gallery?.i, gallery?.items.length].join('/'); d.remove(); $('.lightbox')?.remove(); return r; }));
};
