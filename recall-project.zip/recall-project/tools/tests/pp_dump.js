// dump pxRead lines for each paper into JSON (run from tools/tests for node_modules)
const { chromium } = require('playwright'); const fs = require('fs');
const R = '/home/claude/w/recall-project', P = '/home/claude/papers', OUT = '/home/claude/qd/json';
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); const ctx = await b.newContext();
  const p = await ctx.newPage(); p.setDefaultTimeout(120000);
  await ctx.route(/raw\.githubusercontent\.com|api\.github\.com/, r => r.fulfill({ status: 404, body: '' }));
  const T = '/tmp/tess/';
  await ctx.route(/cdn\.jsdelivr\.net|fonts\./, r => { const u = r.request().url(); let f = null;
    if (u.includes('tesseract.js@5.1.1/dist/')) f = T + 'tesseract.js-5.1.1/package/dist/' + u.split('/dist/')[1];
    else if (u.includes('tesseract.js-core@5.1.1')) f = T + 'tesseract.js-core-5.1.1/package/' + u.split('tesseract.js-core@5.1.1/')[1];
    else if (u.includes('@tesseract.js-data/eng')) f = T + 'tesseract.js-data-eng-1.0.0/package/' + u.split('eng@1.0.0/')[1];
    if (f && fs.existsSync(f)) return r.fulfill({ status: 200, contentType: f.endsWith('.wasm') ? 'application/wasm' : f.endsWith('.gz') ? 'application/gzip' : 'text/javascript', body: fs.readFileSync(f) });
    if (f) console.log('missing', u);
    r.fulfill({ status: 200, contentType: 'text/javascript', body: '' }); });
  await ctx.route(/^http:\/\/paper\.local\//, r => { const f = P + '/' + r.request().url().split('/').pop(); r.fulfill({ status: 200, contentType: 'application/pdf', body: fs.readFileSync(f) }); });
  const lib = fs.readFileSync(R + '/tools/tests/lib20.json', 'utf8');
  await p.addInitScript(lib => { const db = JSON.parse(lib); window.desktop = { platform: 'darwin', load: async () => db, put: async () => true, del: async () => {}, settings: async () => {}, saveImage: async () => ({ file: 'x.png' }), deleteImage: async () => {}, onToggleSidebar() {}, onLibraryChanged() {}, appInfo: async () => ({ shell: '1.29.0', build: '1' }), checkUpdate: async () => {}, onUpdate() {} }; }, lib);
  await p.goto('file://' + R + '/app/app/index.html'); await p.waitForTimeout(1500);
  const only = process.argv.slice(2);
  for (const f of fs.readdirSync(P).filter(f => /^p\d+\.pdf$/.test(f)).filter(f => !only.length || only.includes(f.slice(0, 3)))){
    const t0 = Date.now();
    const b64 = fs.readFileSync(P + '/' + f).toString('base64');
    const j = await p.evaluate(async ([f, b64, OCR]) => {
      const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); const buf = u.buffer;
      const R = await pxRead(new File([buf], f, { type: 'application/pdf' }), null, { noOcr: !OCR });
      return { total: R.total, bodyH: R.bodyH, textLines: R.textLines, pages: R.pages.map(pg => ({ n: pg.n, w: pg.w, h: pg.h, margin: pg.margin, imgs: (pg.imgs || []).map(b => ({ x: b.x, y: b.y, r: b.r, b: b.b })), art: (pg.art || []).map(b => ({ x: b.x, y: b.y, r: b.r, b: b.b })), lines: pg.lines.map(l => ({ x: +l.x.toFixed(1), y: +l.y.toFixed(1), b: +l.b.toFixed(1), r: +l.r.toFixed(1), h: +l.h.toFixed(1), text: l.text, items: l.items.map(i => ({ s: i.s, x: +i.x.toFixed(1), r: +i.r.toFixed(1), h: +i.h.toFixed(1) })) })) })) };
    }, [f, b64, !!process.env.OCR]);
    fs.writeFileSync(OUT + '/' + f.replace('.pdf', '.json'), JSON.stringify(j));
    console.log(f, j.total, 'pages', j.textLines, 'lines', ((Date.now() - t0) / 1000).toFixed(1) + 's');
  }
  await b.close();
})();
