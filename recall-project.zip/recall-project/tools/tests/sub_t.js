// Deleting topics and subtopics: "Rename or delete subtopics" links, and press-and-hold menus on iPad. node sub_t.js
const { chromium } = require('playwright'); const fs = require('fs'), http = require('http'), path = require('path');
(async () => {
  const root = path.resolve(__dirname, '../../web');
  const srv = http.createServer((q, r) => { let f = path.join(root, new URL(q.url, 'http://x').pathname); if (f.endsWith('/')) f += 'index.html'; if (!fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/javascript' }); fs.createReadStream(f).pipe(r); }).listen(8781);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const errs = [];
  for (const MOB of [false, true]){
    const ctx = await b.newContext(MOB ? { viewport: { width: 820, height: 1180 }, hasTouch: true, isMobile: true } : { viewport: { width: 1400, height: 900 } }); const p = await ctx.newPage(); p.on('pageerror', e => errs.push(e.message));
    await p.route(/supabase\.co|cdn\.jsdelivr|fonts\./, r => r.fulfill({ status: 200, body: '' }));
    const lib = fs.readFileSync(path.join(__dirname, 'lib20.json'), 'utf8'); await p.addInitScript(l => { if (!localStorage.getItem('mistake-deck-v2')) localStorage.setItem('mistake-deck-v2', l); }, lib);
    await p.goto('http://127.0.0.1:8781/'); await p.waitForTimeout(1800);
    const tag = MOB ? 'ipad' : 'mac';
    await p.click('text=Show 5 subtopics'); await p.waitForTimeout(300);
    const hold = async sel => { const bx = await p.locator(sel).first().boundingBox(); await p.evaluate(([x, y]) => { const t = document.elementFromPoint(x, y); t.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: x, clientY: y, pointerType: 'touch', isPrimary: true })); window.__t = t; }, [bx.x + 20, bx.y + 10]); await p.waitForTimeout(650); await p.evaluate(() => { __t.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerType: 'touch' })); __t.click(); }); await p.waitForTimeout(150); };
    if (MOB){ await hold('.h7s[data-id="ma-y11-poly"]'); console.log(tag, 'hold subtopic on Today -> menu has Delete:', await p.evaluate(() => !!document.querySelector('#menu [data-act="del-deck"]')), 'still on Today:', await p.evaluate(() => view.name)); await p.keyboard.press('Escape'); await p.evaluate(() => closeMenu()); }
    console.log(tag, 'links on Today:', await p.evaluate(() => [...document.querySelectorAll('[data-act="manage"]')].map(x => x.textContent)));
    await p.click('[data-act="manage"]:has-text("subtopics")'); await p.waitForTimeout(200);
    const before = await p.evaluate(() => [...document.querySelectorAll('[data-mname]')].map(x => x.value));
    await p.click('[data-act="msub-del"] >> nth=0'); await p.click('[data-act="msub-del"] >> nth=0'); await p.waitForTimeout(300);
    const after = await p.evaluate(() => [...document.querySelectorAll('[data-mname]')].map(x => x.value));
    console.log(tag, 'deleted:', before.filter(x => !after.includes(x)), 'toast:', await p.evaluate(() => document.querySelector('#toast')?.textContent));
    await p.screenshot({ path: `/tmp/sub_${tag}_manage.png` });
    await p.click('[data-act="msub-done"]'); await p.waitForTimeout(200);
    // a topic's own page
    await p.evaluate(() => go('overview', 'ma-y11')); await p.waitForTimeout(300).catch(() => {});
    const tid = await p.evaluate(() => view.node && nodeOf(view.node) ? view.node : (go('overview', kids(kids(null)[0].id)[0].id), view.node)); await p.waitForTimeout(300);
    console.log(tag, 'topic page link:', await p.evaluate(() => document.querySelector('.h7ov [data-act="manage"]')?.textContent));
    if (MOB){ await hold('.h7ovr'); console.log(tag, 'hold subtopic on topic page -> menu:', await p.evaluate(() => !!document.querySelector('#menu [data-act="del-deck"]')), 'stayed:', await p.evaluate(() => view.node)); }
    await p.screenshot({ path: `/tmp/sub_${tag}_ov.png` });
    await ctx.close();
  }
  console.log('errors:', errs.length ? errs : 'none'); await b.close(); srv.close();
})();
